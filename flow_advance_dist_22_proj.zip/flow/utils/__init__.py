"""empty init file to ensure documentation for utils is created."""

from flow.utils.exceptions import FatalFlowError

__all__ = ['FatalFlowError']
