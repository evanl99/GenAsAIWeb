"""Empty init file to ensure documentation for Aimsun is created."""
