"""Empty init file to ensure documentation for benchmarks is created."""
