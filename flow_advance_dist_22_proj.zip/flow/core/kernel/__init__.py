"""Empty init file to ensure documentation for kernel is created."""

from flow.core.kernel.kernel import Kernel

__all__ = ["Kernel"]
