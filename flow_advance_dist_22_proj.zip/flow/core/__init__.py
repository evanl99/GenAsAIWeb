"""Empty init file to ensure documentation for core is created."""
