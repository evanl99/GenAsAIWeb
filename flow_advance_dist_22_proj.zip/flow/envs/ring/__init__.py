"""Empty init file to ensure documentation for the ring env is created."""
