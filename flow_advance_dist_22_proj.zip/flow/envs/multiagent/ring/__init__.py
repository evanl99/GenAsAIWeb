"""Empty init file to ensure documentation for multi-agent envs is created."""
