"""Empty init file to ensure nose tests can be run from front page."""
