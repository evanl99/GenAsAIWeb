# Import required packages
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import cm
import matplotlib.font_manager as fm
from matplotlib.ticker import MaxNLocator
import argparse
# Rebuild the matplotlib font cache
fm._rebuild()
# # Collect all the font names available to matplotlib
# font_names = [f.name for f in fm.fontManager.ttflist]
# print(font_names)

ROLLING_AVG = 300


def plot(normalize, scenario, trip_scenario_timestep, regular_scenario_timestep, tot_timestep):
        
    # load CSV files
    time_arr_3, speed_arr_3, is_ai_arr_3 = np.loadtxt('switch-mode3.csv', unpack=True, delimiter=',', skiprows=1)
    # time_arr_2, speed_arr_2, is_ai_arr_2 = np.loadtxt('switch-mode2.csv', unpack=True, delimiter=',', skiprows=1)
    time_arr_1, speed_arr_1, is_ai_arr_1 = np.loadtxt('switch-mode1.csv', unpack=True, delimiter=',', skiprows=1)
    time_arr_safe, speed_arr_safe, is_ai_arr_safe = np.loadtxt('safe.csv', unpack=True, delimiter=',', skiprows=1)
    time_arr_ai, speed_arr_ai, is_ai_arr_ai = np.loadtxt('switch-mode0.csv', unpack=True, delimiter=',', skiprows=1)
    
    # create data frames 
    df_1 = pd.DataFrame({"step": time_arr_1, "speed" : speed_arr_1, "ai": is_ai_arr_1})
    # df_2 = pd.DataFrame({"step": time_arr_2, "speed" : speed_arr_2, "ai": is_ai_arr_2})
    df_3 = pd.DataFrame({"step": time_arr_3, "speed" : speed_arr_3, "ai": is_ai_arr_3})
    df_safe = pd.DataFrame({"speed" : speed_arr_safe})
    df_ai = pd.DataFrame({"speed" : speed_arr_ai})

    # AI_mean = df_ai["speed"].mean()
    # safe_mean = df_safe["speed"].mean()


    if not normalize:
        print("safe average speed: {:.2f}".format(df_safe["speed"].mean()))
        print("ai average speed: {:.2f}".format(df_ai["speed"].mean()))
        print("Blackbox average speed: {:.2f}".format(df_1["speed"].mean()))
        # print("switch-mode 2 average speed: ",  df_2["speed"].mean())
        print("RADICS average speed: {:.2f}".format(df_3["speed"].mean()))

    if normalize: 
        # normalization
        df_1["speed"] = df_1["speed"] / df_safe["speed"]
        # df_2["speed"] = df_2["speed"] / df_safe["speed"]
        df_3["speed"] = df_3["speed"] / df_safe["speed"]
        df_ai["speed"] = df_ai["speed"] / df_safe["speed"]


    # calculate average speed before, during, and after bad scenarios
    before_safe_mean = df_safe["speed"][:trip_scenario_timestep].mean()
    during_safe_mean = df_safe["speed"][trip_scenario_timestep:regular_scenario_timestep].mean()
    after_safe_mean = df_safe["speed"][regular_scenario_timestep:].mean()

    before_ai_mean = df_ai["speed"][:trip_scenario_timestep].mean()
    during_ai_mean = df_ai["speed"][trip_scenario_timestep:regular_scenario_timestep].mean()
    after_ai_mean = df_ai["speed"][regular_scenario_timestep:].mean()
    
    before_sm1_mean = df_1["speed"][:trip_scenario_timestep].mean()
    during_sm1_mean = df_1["speed"][trip_scenario_timestep:regular_scenario_timestep].mean()
    after_sm1_mean = df_1["speed"][regular_scenario_timestep:].mean()

    # before_sm2_mean = df_2["speed"][:trip_scenario_timestep].mean()
    # during_sm2_mean = df_2["speed"][trip_scenario_timestep:regular_scenario_timestep].mean()
    # after_sm2_mean = df_2["speed"][regular_scenario_timestep:].mean()
    
    before_sm3_mean = df_3["speed"][:trip_scenario_timestep].mean()
    during_sm3_mean = df_3["speed"][trip_scenario_timestep:regular_scenario_timestep].mean()
    after_sm3_mean = df_3["speed"][regular_scenario_timestep:].mean()

    if not normalize:
        print("Safe [segment1] average speed: {:.2f}".format(before_safe_mean))
        print("Safe [segment2] average speed: {:.2f}".format(during_safe_mean))
        print("Safe [segment3] average speed: {:.2f}".format(after_safe_mean))

        print("AI [segment1] average speed: {:.2f}".format(before_ai_mean))
        print("AI [segment2] average speed: {:.2f}".format(during_ai_mean))
        print("AI [segment3] average speed: {:.2f}".format(after_ai_mean))

        print("Blackbox [segment1] average speed: {:.2f}".format(before_sm1_mean))
        print("Blackbox [segment2] average speed: {:.2f}".format(during_sm1_mean))
        print("Blackbox [segment3] average speed: {:.2f}".format(after_sm1_mean))

        print("RADICS [segment1] average speed: {:.2f}".format(before_sm3_mean))
        print("RADICS [segment2] average speed: {:.2f}".format(during_sm3_mean))
        print("RADICS [segment3] average speed: {:.2f}".format(after_sm3_mean))

    # apply rolling average
    df_1["speed"] = df_1["speed"].rolling(window=ROLLING_AVG).mean()
    # df_2["speed"] = df_2["speed"].rolling(window=ROLLING_AVG).mean()
    df_3["speed"] = df_3["speed"].rolling(window=ROLLING_AVG).mean()
    df_safe["speed"] = df_safe["speed"].rolling(window=ROLLING_AVG).mean()
    df_ai["speed"] = df_ai["speed"].rolling(window=ROLLING_AVG).mean()


    # label data based on whether it's AI controller
    df_1_ai = df_1[df_1['ai'] != 0]
    df_1_safe = df_1[df_1['ai'] == 0]
    # df_2_ai = df_2[df_2['ai'] != 0]
    # df_2_safe = df_2[df_2['ai'] == 0]
    df_3_ai = df_3[df_3['ai'] != 0]
    df_3_safe = df_3[df_3['ai'] == 0]
    df_1['label'] = np.where(df_1['ai'] != 0, -1, 1)
    # df_2['label'] = np.where(df_2['ai'] != 0, -1, 1)
    df_3['label'] = np.where(df_3['ai'] != 0, -1, 1)


    # Create figure object and store it in a variable called 'fig' # figsize=(3, 3)
    fig = plt.figure(figsize=(20,10))
    # Generate 10 colors from the 'tab10' colormap
    colors = cm.get_cmap('tab10', 10)

    # assign colors 
    c_safe = "blue"
    c_ai = "red"
    c_sm1 = "black"
    # c_sm2 = colors(2)
    c_sm3 = "green"
    # c_safe = colors(4)
    # c_ai = colors(3)
    # c_sm1 = colors(1)
    # # c_sm2 = colors(2)
    # c_sm3 = colors(2)

    mpl.rcParams['font.family'] = 'Times New Roman'
    plt.rcParams['font.size'] = 32
    plt.rcParams['axes.linewidth'] = 3
    # Add axes object to our figure that takes up entire figure
    ax = fig.add_axes([0, 0, 1, 1])
    # Edit the major and minor ticks of the x and y axes
    ax.xaxis.set_tick_params(which='major', size=10, width=2, direction='in', top=True)
    # ax.xaxis.set_tick_params(which='minor', size=7, width=2, direction='in', top=True)
    ax.yaxis.set_tick_params(which='major', size=10, width=2, direction='in', right=False)
    # ax.yaxis.set_tick_params(which='minor', size=7, width=2, direction='in', right=False)

    # Hide the top and right spines of the axis
    # ax.spines['right'].set_visible(False)
    # ax.spines['top'].set_visible(False)

    # Set the axis limits
    ax.set_xlim(0, tot_timestep)
    # Add the x axis label
    ax.set_xlabel('Timestep', labelpad=10)
    if normalize:
        ax.set_ylim(0.2, 1.4)
        # Add the y axis label
        ax.set_ylabel('Normalized Speed', labelpad=10)
        # add line for safe controller
        ax.axhline(y=1, color='blue', linestyle='dotted')
    else: 
        ax.set_ylim(0, 8)
           # Add the y axis label
        ax.set_ylabel('Speed (m/s)', labelpad=10)

    # get rid of duplicated 0 at origin
    plt.gca().xaxis.set_major_locator(MaxNLocator(prune='lower'))

    # mark regular cases and tripping cases
    ax.axvline(x=trip_scenario_timestep, linestyle='solid', color='purple')
    ax.axvline(x=regular_scenario_timestep, linestyle='solid', color='purple')

    # mark average speeds
    before_xmax = trip_scenario_timestep/tot_timestep
    during_xmin = trip_scenario_timestep/tot_timestep
    during_xmax = regular_scenario_timestep/tot_timestep
    after_xmin = regular_scenario_timestep/tot_timestep

    # ax.axhline(y=AI_mean, xmin=0, color=c_ai, linestyle='dashed')
    # ax.axhline(y=safe_mean, xmin=0, color=c_safe, linestyle='dashed')

    if not normalize: 
        ax.axhline(y=before_safe_mean, xmin=0, xmax=before_xmax, color=c_safe, linestyle='dashed')
        ax.axhline(y=during_safe_mean, xmin=during_xmin, xmax=during_xmax, color=c_safe, linestyle='dashed')
        ax.axhline(y=after_safe_mean, xmin=after_xmin, color=c_safe, linestyle='dashed')

    ax.axhline(y=before_ai_mean, xmin=0, xmax=before_xmax, color=c_ai, linestyle='dashed')
    ax.axhline(y=during_ai_mean, xmin=during_xmin, xmax=during_xmax, color=c_ai, linestyle='dashed')
    ax.axhline(y=after_ai_mean, xmin=after_xmin, color=c_ai, linestyle='dashed')
    

    ax.axhline(y=before_sm1_mean, xmin=0, xmax=before_xmax, color=c_sm1, linestyle='dashed')
    ax.axhline(y=during_sm1_mean, xmin=during_xmin, xmax=during_xmax, color=c_sm1, linestyle='dashed')
    ax.axhline(y=after_sm1_mean, xmin=after_xmin, color=c_sm1, linestyle='dashed')

    # ax.axhline(y=before_sm2_mean, xmin=0, xmax=before_xmax, color=c_sm2, linestyle='dashed')
    # ax.axhline(y=during_sm2_mean, xmin=during_xmin, xmax=during_xmax, color=c_sm2, linestyle='dashed')
    # ax.axhline(y=after_sm2_mean, xmin=after_xmin, color=c_sm2, linestyle='dashed')

    ax.axhline(y=before_sm3_mean, xmin=0, xmax=before_xmax, color=c_sm3, linestyle='dashed')
    ax.axhline(y=during_sm3_mean, xmin=during_xmin, xmax=during_xmax, color=c_sm3, linestyle='dashed')
    ax.axhline(y=after_sm3_mean, xmin=after_xmin, color=c_sm3, linestyle='dashed')


    
    # add safe to the plot
    if not normalize:
        ax.plot(time_arr_safe, df_safe["speed"], linewidth=3, color=c_safe, label='Safe', linestyle='dotted')
        
    ax.plot(time_arr_ai, df_ai["speed"], linewidth=3, color=c_ai, label='AI', linestyle='solid')


    def plot_func_mode_1(group):
        style = 'solid' if (group['label'] < 0).all() else 'dashed'
        ax.plot(group.step, group.speed, linewidth=3, color=c_sm1 , label='', linestyle=style)

    # def plot_func_mode_2(group):
    #     style = 'dashed' if (group['label'] < 0).all() else 'solid'
    #     ax.plot(group.step, group.speed, linewidth=2, color=c_sm2 , label='', linestyle=style)

    def plot_func_mode_3(group):
        style = 'solid' if (group['label'] < 0).all() else 'dashed'
        ax.plot(group.step, group.speed, linewidth=3, color=c_sm3, label='', linestyle=style)

    df_1 = df_1.dropna(axis=0, how='any')
    # df_2 = df_2.dropna(axis=0, how='any')
    df_3= df_3.dropna(axis=0, how='any')

    df_1.groupby((df_1['label'].shift() * df_1['label'] < 0).cumsum()).apply(plot_func_mode_1)
    # df_2.groupby((df_2['label'].shift() * df_2['label'] < 0).cumsum()).apply(plot_func_mode_2)
    df_3.groupby((df_3['label'].shift() * df_3['label'] < 0).cumsum()).apply(plot_func_mode_3)

    # create customized legends
    handles, labels = ax.get_legend_handles_labels()
    ## Create custom artists
    switch_mode_1_ai = plt.Line2D((0,1),(0,0), color=c_sm1, linewidth=3, linestyle="solid")
    switch_mode_1_safe = plt.Line2D((0,1),(0,0), color=c_sm1,linewidth=3, linestyle="dashed")
    # switch_mode_2_ai = plt.Line2D((0,1),(0,0), color=c_sm2, linestyle="dashed")
    # switch_mode_2_safe = plt.Line2D((0,1),(0,0), color=c_sm2, linestyle="solid")
    switch_mode_3_ai = plt.Line2D((0,1),(0,0), color=c_sm3, linewidth=3, linestyle="solid")
    switch_mode_3_safe = plt.Line2D((0,1),(0,0), color=c_sm3, linewidth=3, linestyle="dashed")

    # Create legend from custom artist/label lists
    legend_objs = handles + [switch_mode_1_ai, switch_mode_1_safe, switch_mode_3_ai, switch_mode_3_safe]
    ax.legend(
        legend_objs,
        labels + [
            'Black-box AI',
            'Black-box Safe',
            'RADICS AI',
            'RADICS Safe',
        ],
        loc='best',
        frameon=False, 
        fontsize=32
    )

    # title_str = '80M rl_model, scenario {:d}{}'.format(scenario, ", normalized" if normalize else "")
    title_str = 'RADICS{}'.format(" Normalized" if normalize else "")
    # figure title
    plt.title(title_str)
    # Save figure
    plt.savefig('{}.png'.format(title_str), dpi=300, transparent=False, bbox_inches='tight')

    # switch mode 1
    # AI 
    # ax.plot(df_1_ai["step"].to_numpy(), df_1_ai["speed"].to_numpy(), linewidth=2, color=colors(1), label='switch mode 1 ai', linestyle='dashed')
    # safe
    # ax.plot(df_1_safe["step"].to_numpy(), df_1_safe["speed"].to_numpy(), linewidth=2, color=colors(1), label='switch mode 1 safe', linestyle='solid')
    # switch mode 2
    # AI 
    # ax.plot(df_2_ai["step"].to_numpy(), df_2_ai["speed"].to_numpy(), linewidth=2, color=colors(2), label='switch mode 2 ai', linestyle=':')
    # safe
    # ax.plot(df_2_safe["step"].to_numpy(), df_2_safe["speed"].to_numpy(), linewidth=2, color=colors(2), label='switch mode 2 safe', linestyle='solid')


    # ax.plot(time_arr_1, df_1["speed"], linewidth=2, color=colors(1), label='switch mode 1', linestyle='dashed')
    # ax.plot(time_arr_2, df_2["speed"], linewidth=2, color=colors(2), label='switch mode 2', linestyle='solid')
    # ax.plot(time_arr_safe, df_safe["speed"], linewidth=2, color=colors(0), label='safe', linestyle='solid')
    # ax.plot(time_arr_ai, df_ai["speed"], linewidth=2, color=colors(3), label='ai', linestyle='dotted')
    # ax.axhline(y=1, linestyle='dashed')
    

    # ax.legend(bbox_to_anchor=(1, 1), loc="best", frameon=False, fontsize=16)
    # ax.legend(loc="best")

    # Plot and show our data
    # ax.plot(time_arr_safe, speed_arr_safe, linewidth=2, color=colors(4), label='safe', linestyle='solid')
    # ax.plot(time_arr_1, speed_arr_1, linewidth=2, color=colors(1), label='switch mode 1', linestyle='dashed')
    # ax.plot(time_arr_2, speed_arr_2, linewidth=2, color=colors(2), label='switch mode 2', linestyle=':')

    
     # ???
    # speed_arr_2 = df_2.to_numpy()
    # speed_arr_safe = df_safe.to_numpy()

    

    # plt.show()

if __name__ == '__main__':  
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", nargs="?", help="scenario", type=int, default=0)
    parser.add_argument("--normalize", nargs="?", choices=["true", "false"], help="whether to normalize the plot", type=str, default="false")
    args = parser.parse_args()

    normalize = False
    if args.normalize == "true":
        normalize = True

    plot(normalize, args.scenario, 10000, 13000, 25000)