"""System that switches between the AI controller and the safe controller."""
from flow.core.util import emission_to_csv
from flow.utils.registry import make_create_env, env_constructor
from stable_baselines import PPO2
from stable_baselines.common.vec_env import DummyVecEnv
import copy 
import pandas as pd
import numpy as np
from helper import setup_flow, evaluate_model, get_outside_edges
import warnings
from multiprocessing import Process, freeze_support, Value, Array, Pool
import argparse
import random
import temp
import tensorflow as tf
from plot import plot
from datetime import datetime

FUZZ = True
wb_simulation_freq = 25

"""
Since processes generated from multiprocessing Pool are daemonic and multiprocessiing 
doesn't allow daemonic processes to have children processes, I start two processes at the beginning 
and use shared-memory values to communicate between processes. 

JobID 0: 
The main simulation process. 
Switch from AI to Safe controller: switch when the average speed of past 50 seconds is below 4 (m/s)
Switch from Safe to AI controller: after 60 seconds, run a test simulation of the AI controller for 1000 steps. 
If the average speed of the AI controller is above 5 (m/s), switch to the AI controller. 

JobID 1: 
The test simulation process. 
When temp.sim_running becomes True (non-zero), it runs a test simulation and put results in temp.results
"""

# whether the test simulation is running. 
temp.sim_running = Value("i", 0)
# results of the test simulation 
temp.results = Array("d", [0]*9)
# inflow array for test simulation
temp.inflow_arr = Array("d", [0]*8)
debug_inflow_arr = []


def mp_simulate(input_arr):
    job_id, flow_params, model_file, switch_mode, controller, parallel, inflow_window_size, window_size, seed = input_arr 
    n = flow_params['net'].additional_params["grid_array"]["row_num"]
    m = flow_params['net'].additional_params["grid_array"]["col_num"]
    outside_edges = get_outside_edges(n, m)

    if job_id == 0: 
        env_lambda = env_constructor(params=flow_params, version=0)()
        vec_env = DummyVecEnv([lambda: env_lambda])
        env = vec_env.envs[0]
        
        model = None
        models_list = list()
        if controller == 'ai':
            model = PPO2.load(model_file, env=vec_env, n_steps=1)
            # loading 5 models
            models_list.append(PPO2.load("rl_model1.zip", env=vec_env, n_steps=1))
            models_list.append(PPO2.load("rl_model2.zip", env=vec_env, n_steps=1))
            models_list.append(PPO2.load("rl_model3.zip", env=vec_env, n_steps=1))
            models_list.append(PPO2.load("rl_model4.zip", env=vec_env, n_steps=1))
            models_list.append(PPO2.load("rl_model5.zip", env=vec_env, n_steps=1))

        # total number of steps for a simulation
        num_steps = env.env_params.horizon

        # set a seed based on system time
        if seed == -1: # using default seed
            py_seed = 5123
            np_seed= 7370
            tf_seed = 7928
        else:  # set seed
            # random.seed(datetime.now())
            random.seed(seed)
            py_seed = random.randrange(10000)
            np_seed= random.randrange(10000)
            tf_seed = random.randrange(10000)
        
        print("python random seed is ", py_seed)
        print("np random seed is ", np_seed)
        print("tf random seed is ", tf_seed)
        # set python random, np random, and tensorflow seeds
        random.seed(py_seed)
        np.random.seed(np_seed)
        tf.set_random_seed(tf_seed)

        
        # used for stepping safe controller
        def rl_actions(*_):
            return None

        # reset environment
        state = env.reset()
        
        # an array of average velocities for each time step
        vel = []
        # a dictionary that stores accumulated waiting time for vehicles
        cartimes={}
        # total accumulated waiting time of all arrived vehicles
        total=0
        # total number of arrived vehicles
        count=0
        # total accumulated waiting time of vehicles in the last time step
        prev_total = 0
        # number of arrived vehicles in the last time step
        prev_count = 0
        # stores vehicles in the queue. 
        queued_vehs = []
        # maximum length of the queue
        max_queue_size = 0
        # number of vehicles which departed 
        inflow = 0

        # current controller
        cur_controller = controller
        # flags used to initialize safe and ai controllers
        load_safe = False
        load_ai = False

        # average speed of past <window-size> steps
        window_avg_speed = -1
        window = []
        window_count = 0

        # inflow on outside edges for the past <inflow_window-size> steps
        inflow_window = []
        # inflow of current step 
        inflow_cur = [0] * 8
        inflow_window_count = 0

        # variables for running test simulation in main thread
        sim_inflow_arr = [0] * 8
        sim_flow_params = None
        sim_env_lambda = None 
        sim_vec_env = None 
        sim_env = None
        sim_time_elapsed = 0

        # variables for whitebox monitor
        white_time_elapsed = 0
        # array of timesteps at which the system runs whitebox simulations
        white_time_arr = []
        white_time_arr.append(0)

        # array of timesteps at which the system runs test simulations
        sim_time_arr = []
        sim_time_arr.append(0)

        # array of timesteps at which the system switched to the safe controller
        switch_time_to_safe = []
        # array of timesteps at which the system switched to the AI controller
        switch_time_to_ai = []

        # array of doubles for whitebox monitors
        wb0_arr = []
        # wb0_rolling_arr = []
        wb0_time_arr = []
        wb1_arr = []
        wb1_rolling_arr = []
        wb2_arr = []
        wb2_rolling_arr = []
        wb1_time_arr = []
        wb2_time_arr = []
        # fuzz_time_arr.append(0)

        # initialize sim_running to False
        temp.sim_running.value = 0
        # check if the test simulation started 
        sim_started = False

        speed_arr = np.array([])
        time_arr = np.array([])
        is_ai_arr = np.array([])

        # display current controller on sumo-gui
        if cur_controller == 'ai':
            env.k.kernel_api.poi.add("cur-controller", 50, 250, (0,255,0))
        elif cur_controller == 'safe':
            env.k.kernel_api.poi.add("cur-controller", 50, 250, (0,0,255))

        for j in range(num_steps):
            if cur_controller == 'safe':
                # switching to safe controller
                if not load_safe: 
                    print("Initializing safe controller.")
                    # update 
                    env.k.kernel_api.poi.setColor("cur-controller", (0,0,255))
                    # reset traffic light program
                    for i in range(4):
                        env.k.kernel_api.trafficlight.setProgram("center" + str(i), "1")
                    load_safe = True
                    load_ai = False
                    # mark switch time
                    switch_time_to_safe.append(j)

                # time since last switch to safe controller 
                time_elapsed = j - switch_time_to_safe[-1]
                # time since last test simulation
                sim_time_elapsed = j - sim_time_arr[-1]

                if controller == 'ai' and switch_mode == 1: 
                    if time_elapsed > 600 and window_avg_speed > 5:
                        cur_controller = 'ai'
                elif controller == 'ai' and (switch_mode == 2 or switch_mode == 3): 
                    if parallel and sim_started: 
                        if temp.sim_running.value == 0: 
                            print("Test simulation result")
                            test_sim_avg_speed = temp.results[3]
                            print("AI controller average speed: ", test_sim_avg_speed)
                            print("window average speed: ", window_avg_speed)
                            if test_sim_avg_speed > 5 and window_avg_speed > 5:
                                print("AI controller average speed > 5 (m/s), switching to AI")
                                cur_controller = 'ai'
                            else: 
                                print("AI controller average speed <= 5 (m/s) , not switching")
                            sim_started = False
                    else: 
                        if time_elapsed > 600 and time_elapsed >= inflow_window_size:
                            if parallel and temp.sim_running.value == 0:
                                # start a simulation for the AI controller
                                # get inflow array of past 60 seconds 
                                inflow_arr = [0] * 8 
                                
                                for arr in inflow_window: 
                                    for i in range(8): 
                                        inflow_arr[i] += arr[i]
                                coeff = 36000 / inflow_window_size
                                inflow_arr = [i * coeff for i in inflow_arr]
                                # print("inflow array is ", inflow_arr)
                                # pass inflow array to test simulation
                                for i in range(8): 
                                    temp.inflow_arr[i] = inflow_arr[i]
                                temp.sim_running.value = 1
                                sim_started = True
                                debug_inflow_arr.append(inflow_arr)
                            elif not parallel:
                                # action-probability based whitebox monitor
                                action_prob = model.action_probability(np.array(state), actions=np.array(action))

                                # update action_probability rolling window
                                if len(wb1_rolling_arr) < 100:
                                    wb1_rolling_arr.append(action_prob)
                                else:
                                    wb1_rolling_arr.pop(0)
                                    wb1_rolling_arr.append(action_prob)
                                    wb1_avg_rate = np.mean(wb1_rolling_arr)
                                    wb1_arr = np.append(wb1_arr, wb1_avg_rate)
                                    # print("step: ", j, ", confidence level is", fuzz_avg_rate)
                                    wb1_time_arr = np.append(wb1_time_arr, j)

                                # agreement based whitebox monitor
                                sum = 0
                                # print("cur action: ", action)
                                # action_mask = [int(x) for x in list('{0:0b}'.format(action))]
                                # action_mask = [0] * (4 - len(action_mask)) + action_mask
                                # print(action_mask)
                                for i in range(len(models_list)):
                                    mod = models_list[i]
                                    mod_action, _mod_states = mod.predict(state)
                                    # print("mod", i, " action: ", mod_action)
                                    action_mod_mask = [int(x) for x in list('{0:0b}'.format(mod_action))]
                                    action_mod_mask = [0] * (4 - len(action_mod_mask)) + action_mod_mask
                                    # print(action_mod_mask)
                                    if mod_action == action:
                                        sum += 1

                                agreement_rate = sum / len(models_list)

                                # update agreement based rolling window
                                if len(wb2_rolling_arr) < 100:
                                    wb2_rolling_arr.append(agreement_rate)
                                else:
                                    wb2_rolling_arr.pop(0)
                                    wb2_rolling_arr.append(agreement_rate)
                                    wb2_avg_rate = np.mean(wb2_rolling_arr)
                                    wb2_arr = np.append(wb2_arr, wb2_avg_rate)
                                    # print("step: ", j, ", confidence level is", fuzz_avg_rate)
                                    wb2_time_arr = np.append(wb2_time_arr, j)
                                    
                                if sim_time_elapsed > wb_simulation_freq: 
                                    # mark test simulation time
                                    sim_time_arr.append(j)

                                    sim_inflow_arr = [0] * 8 
                                    for arr in inflow_window: 
                                        for i in range(8): 
                                            sim_inflow_arr[i] += arr[i]
                                    coeff = 36000 / inflow_window_size
                                    sim_inflow_arr = [i * coeff for i in sim_inflow_arr]
                                    print("starting test simulation: ", controller)
                                    print("inflow array is ", sim_inflow_arr)
                                    sim_flow_params = setup_flow(500, None, {"yellow": 3, "straight": 26, "left": 5}, 6, None, 0, 0, 1000, render=False, inflow_arr=sim_inflow_arr)
                                    sim_env_lambda = env_constructor(params=sim_flow_params, version=0)()
                                    sim_vec_env = DummyVecEnv([lambda: sim_env_lambda])
                                    sim_env = sim_vec_env.envs[0]
                                    sim_model = PPO2.load(model_file, env=sim_vec_env, n_steps=1)
                    
                                    # total number of steps for a simulation
                                    num_steps = sim_env.env_params.horizon
                                    try: 
                                        #  arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow
                                        output_arr = evaluate_model(False, sim_model, sim_env, num_steps)
                                    except Exception as e:
                                        print("Exception occurred during simulation: ", e) 
                                    else: 
                                        # test simulation completed 
                                        test_sim_avg_speed = output_arr[3]
                                        print("AI controller average speed: ", test_sim_avg_speed)
                                        print("window average speed: ", window_avg_speed)
                                        if test_sim_avg_speed > 5:
                                            print("AI controller average speed > 5 (m/s), switching to AI")
                                            # DEBUG: no switching
                                            cur_controller = 'ai'
                                        else: 
                                            print("AI controller average speed <= 5 (m/s) , not switching")
                                        # update simulation based whitebox time and speed window
                                        wb0_arr.append(test_sim_avg_speed)
                                        wb0_time_arr = np.append(wb0_time_arr, j)
                                    debug_inflow_arr.append(sim_inflow_arr)
                                    sim_env.terminate()
                            
                state, reward, done, _ = env.step(rl_actions(state))
            elif cur_controller == 'ai': 
                # switching to AI controlloer
                if not load_ai: 
                    print("Initializing AI controller.")
                    env.k.kernel_api.poi.setColor("cur-controller", (0,255,0))
                    # model.env = vec_env
                    model = PPO2.load(model_file, env=vec_env, n_steps=1)
                    load_ai = True
                    load_safe = False
                    # mark switch time
                    switch_time_to_ai.append(j)
                    # action, _states = model.predict(state)
                    
                action, _states = model.predict(state)
                state, reward, done, _ = env.step(action)

                if switch_mode == 3:
                    # time since last test simulation
                    white_time_elapsed = j - white_time_arr[-1]

            # all vehicles currently in the network
            veh_ids = env.k.vehicle.get_ids()
            # loaded vehicles (including ones in the queue)
            loaded_vehs = env.k.kernel_api.simulation.getLoadedIDList()
            
            # vehicles added to the system
            departed_vehs = env.k.kernel_api.simulation.getDepartedIDList()
            
            for v_id in departed_vehs:
                edge_idx = outside_edges.index(env.k.vehicle.get_edge(v_id))
                inflow_cur[edge_idx] += 1 
            if inflow_window_count < inflow_window_size: 
                inflow_window.append(copy.copy(inflow_cur))
                inflow_cur = [0] * 8
                inflow_window_count += 1
            else: 
                inflow_window.pop(0)
                inflow_window.append(copy.copy(inflow_cur))
                inflow_cur = [0] * 8

            # update inflow 
            inflow += len(departed_vehs)
            # IDs of vehicles that are currently in the queue
            cur_queued_vehs = list(set(loaded_vehs)- set(departed_vehs))
            # IDs of vehicles that leave the queue (therefore enter the network)
            poped_vehs = list(set(departed_vehs) - set(loaded_vehs))
            # current queue size
            cur_queue_size = len(cur_queued_vehs)
            if cur_queue_size != 0:
                # update maximum queue size  
                if cur_queue_size > max_queue_size:
                    max_queue_size = cur_queue_size
                # add currently queued vehicles
                queued_vehs.extend(cur_queued_vehs)
            
            # remove vehicles that left the queue from the queue
            if len(poped_vehs) != 0: 
                queued_vehs = list(set(queued_vehs) - set(poped_vehs))

            # Compute the velocity speeds and cumulative returns.    
            veh_vel = np.append(np.array(env.k.vehicle.get_speed(veh_ids)), np.zeros(len(queued_vehs)))
            if not (any(veh_vel < -100) or len(veh_vel) == 0):
                avg_vel = np.mean(veh_vel)
                vel.append(avg_vel)
                if window_count < window_size:
                    window.append(avg_vel)
                    window_count+=1
                else:
                    window.pop(0)
                    window.append(avg_vel)
                    window_avg_speed = np.mean(window)
                    print("step: ", j, ", average speed of past ", window_size, " steps is ", window_avg_speed)

                    # # DEBUGGING PURPOSE
                    # inflow_arr = [0] * 8 
                    # for arr in inflow_window: 
                    #     for i in range(8): 
                    #         inflow_arr[i] += arr[i]
                    # coeff = 36000 / inflow_window_size
                    # inflow_arr = [i * coeff for i in inflow_arr]
                    # print("\nprinting inflow window\n", inflow_arr)
                    # # END


                    speed_arr = np.append(speed_arr, window_avg_speed)
                    time_arr = np.append(time_arr, j)
                    is_ai_arr = np.append(is_ai_arr, 1 if cur_controller == 'ai' else 0)
                    # blackbox: switch to safe controller
                    if cur_controller == 'ai' and window_avg_speed < 4 and switch_mode != 0:
                        cur_controller = 'safe'

                    # whitebox simulation: 
                    if cur_controller == 'ai' and switch_mode == 3:
                        

                        # action-probability based whitebox monitor
                        action_prob = model.action_probability(np.array(state), actions=np.array(action))

                        # update action_probability rolling window
                        if len(wb1_rolling_arr) < 100:
                            wb1_rolling_arr.append(action_prob)
                        else:
                            wb1_rolling_arr.pop(0)
                            wb1_rolling_arr.append(action_prob)
                            wb1_avg_rate = np.mean(wb1_rolling_arr)
                            wb1_arr = np.append(wb1_arr, wb1_avg_rate)
                            # print("step: ", j, ", confidence level is", fuzz_avg_rate)
                            wb1_time_arr = np.append(wb1_time_arr, j)

                        # agreement based whitebox monitor
                        sum = 0
                        # print("cur action: ", action)
                        # action_mask = [int(x) for x in list('{0:0b}'.format(action))]
                        # action_mask = [0] * (4 - len(action_mask)) + action_mask
                        # print(action_mask)
                        for i in range(len(models_list)):
                            mod = models_list[i]
                            mod_action, _mod_states = mod.predict(state)
                            # print("mod", i, " action: ", mod_action)
                            action_mod_mask = [int(x) for x in list('{0:0b}'.format(mod_action))]
                            action_mod_mask = [0] * (4 - len(action_mod_mask)) + action_mod_mask
                            # print(action_mod_mask)
                            if mod_action == action:
                                sum += 1

                        agreement_rate = sum / len(models_list)

                        # update agreement based rolling window
                        if len(wb2_rolling_arr) < 100:
                            wb2_rolling_arr.append(agreement_rate)
                        else:
                            wb2_rolling_arr.pop(0)
                            wb2_rolling_arr.append(agreement_rate)
                            wb2_avg_rate = np.mean(wb2_rolling_arr)
                            wb2_arr = np.append(wb2_arr, wb2_avg_rate)
                            # print("step: ", j, ", confidence level is", fuzz_avg_rate)
                            wb2_time_arr = np.append(wb2_time_arr, j)

                        # simulation based whitebox monitor
                        if white_time_elapsed > wb_simulation_freq: 
                             # mark whitebox simulation time
                            white_time_arr.append(j)

                            wb_inflow_arr = [0] * 8 
                            for arr in inflow_window: 
                                for i in range(8): 
                                    wb_inflow_arr[i] += arr[i]
                            coeff = 36000 / inflow_window_size
                            wb_inflow_arr = [i * coeff for i in wb_inflow_arr]
                            print("wb inflow array is ", wb_inflow_arr)
                            wb_flow_params = setup_flow(500, None, {"yellow": 3, "straight": 26, "left": 5}, 6, None, 0, 0, 1000, render=False, inflow_arr=wb_inflow_arr)
                            wb_env_lambda = env_constructor(params=wb_flow_params, version=0)()
                            wb_vec_env = DummyVecEnv([lambda: wb_env_lambda])
                            wb_env = wb_vec_env.envs[0]
                            wb_model = PPO2.load(model_file, env=wb_vec_env, n_steps=1)
            
                            # total number of steps for a simulation
                            num_steps = wb_env.env_params.horizon
                            try: 
                                #  arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow
                                output_arr = evaluate_model(False, wb_model, wb_env, num_steps)
                            except Exception as e:
                                print("Exception occurred during simulation: ", e) 
                            else: 
                                # test simulation completed 
                                wb_sim_avg_speed = output_arr[3]
                                print("AI controller average speed: ", wb_sim_avg_speed)
                                if wb_sim_avg_speed < 4:
                                    print("WHITEBOX: AI controller simulated average speed < 4 (m/s), switching to safe")
                                    # DEBUG: no switching
                                    cur_controller = 'safe'
                                    
                                # update simulation based whitebox time and speed window
                                wb0_arr.append(wb_sim_avg_speed)
                                wb0_time_arr = np.append(wb0_time_arr, j)
                                    
                            wb_env.terminate()

            # reset prev total and prev count
            if len(veh_ids) != 0:
                prev_total = 0
                prev_count = 0

            # print(dir(env))
            for veh_id in env.k.vehicle.get_arrived_ids():
                total += cartimes[veh_id]
                count += 1
            for veh_id in veh_ids:
                cartimes[veh_id] = env.k.kernel_api.vehicle.getAccumulatedWaitingTime(veh_id)
                # get all remaining cars in the system
                prev_total += cartimes[veh_id]
                prev_count += 1
                
            if done:
                break


        df = pd.DataFrame({"step" : time_arr, "speed" : speed_arr, "ai": is_ai_arr})
        if controller == 'safe':
            df.to_csv("safe.csv", index=False)
        else:
            df.to_csv("switch-mode{}.csv".format(switch_mode), index=False)
        # np.savetxt("switch-mode{}.csv".format(switch_mode), speed_arr, delimiter=",")
        if FUZZ: 
            df_wb1 = pd.DataFrame({"time": wb1_time_arr, "hit-rate" : wb1_arr})
            df_wb1.to_csv("wb1.csv", index=False)
            df_wb2 = pd.DataFrame({"time": wb2_time_arr, "hit-rate" : wb2_arr})
            df_wb2.to_csv("wb2.csv", index=False)
            df_wb0 = pd.DataFrame({"time" : wb0_time_arr, "hit-rate" : wb0_arr})
            df_wb0.to_csv("wb0.csv", index=False)

        arrived_waiting_time = total / count
        remaining_waiting_time = prev_total / prev_count
        all_waiting_time = (total + prev_total) / (prev_count + count)
        average_speed = np.mean(vel)
        remaining_queue_size = len(queued_vehs)
        print("average waiting time (s) of arrived vehicles is: ", arrived_waiting_time)
        print("average waiting time (s) of remaining vehicles is: ", remaining_waiting_time)
        print("average waiting time (s) of all vehicles is:", all_waiting_time)
        print("average speed (m/s) of all vehicles is ", average_speed)
        print("maximum queue size is ", max_queue_size)
        print("number of remaining vehicles in the queue ", remaining_queue_size)
        print("number of remaining vehicles in the network ", prev_count)
        print("inflow is ", inflow)
        print("outflow is ", count)
        outflow = env.k.vehicle.get_outflow_rate(int(500))
        print("debug inflow array is\n", debug_inflow_arr)
        env.terminate()

        return [arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, prev_count, inflow, count] 
    elif job_id == 1:
        while True: 
            if temp.sim_running.value is not 0:
                print("starting test simulation: ", controller)
                sim_inflow_arr = [0] * 8
                for i in range(8): 
                    sim_inflow_arr[i] = temp.inflow_arr[i]
                print("inflow array is ", sim_inflow_arr)
                sim_flow_params = setup_flow(500, None, {"yellow": 3, "straight": 26, "left": 5}, 6, None, 0, 0, 1000, render=False, inflow_arr=sim_inflow_arr)
                sim_env_lambda = env_constructor(params=sim_flow_params, version=0)()
                sim_vec_env = DummyVecEnv([lambda: sim_env_lambda])
                sim_env = sim_vec_env.envs[0]
                sim_model = PPO2.load(model_file, env=sim_vec_env, n_steps=1)
                # total number of steps for a simulation
                num_steps = sim_env.env_params.horizon

                try: 
                    if controller == 'ai': 
                        #  arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow
                        output_arr = evaluate_model(False, sim_model, sim_env, num_steps)
                    elif controller == 'safe':
                        output_arr = evaluate_model(True, None, sim_env, num_steps)
                except Exception as e:
                    print("Exception occurred during simulation: ", e) 
                else: 
                    for i in range(9):
                        temp.results[i] = output_arr[i]
                # test simulation completed 
                temp.sim_running.value = 0
        return []


if __name__ == '__main__':  
    warnings.filterwarnings('ignore', category=FutureWarning)
    freeze_support()

    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices =["run", "safe", "plot"] ,help="choose from [run, safe, plot]", type=str)
    parser.add_argument("file", nargs="?", help="model file", type=str)
    parser.add_argument("--render", nargs="?", choices=["true", "false"], help="whether to render SUMO gui", type=str, default="false")
    parser.add_argument("--seed", nargs="?", help="seed the randomness in the simulation", type=int, default=-1)
    # traffic light settings
    parser.add_argument("--yellow", nargs="?", help="specify the duration of yellow lights in safe controller", type=float, default=3)
    parser.add_argument("--straight", nargs="?", help="specify the duration of straight red/green lights in safe controller", type=float, default=26)
    parser.add_argument("--left", nargs="?", help="specify the duration of left-turning red/green lights in safe controller", type=float, default=5)
    # inflow settings
    parser.add_argument("--rate", nargs="?", help="number of vehicles per hour at regular scenarios", type=int, default=500)
    parser.add_argument("--scenario", nargs="?", help="scenarios that trip the AI system", type=int, default=None)
    # vehicle settings
    parser.add_argument("--route", nargs="?", help="routes that trip the AI system", type=int, default=None)
    # ai configs
    parser.add_argument("--num-observed", nargs="?", help="number of vehicles observed on each edge (must be even)", type=int, default=6)
    # simulation settings
    parser.add_argument("--horizon", nargs="?", help="total number of steps of a simulation", type=int, default=25000)
    # RADICS settings
    parser.add_argument("--switch-mode", nargs="?", help="switch mode", type=int, default=1)
    parser.add_argument("--whitebox", nargs="?", help="choose a whitebox monitor to use", type=int, default=1)
    parser.add_argument("--parallel", nargs="?", choices=["true", "false"], help="whether to run test simulations in parallel for switch-mode 2", type=str, default="false")
    parser.add_argument("--runall", nargs="?", choices=["true", "false"], help="whether to all simulations (safe, ai, switch-mode 1, switch-mode 2)", type=str, default="false")
    parser.add_argument("--trip-timestep", nargs="?", help="timestep at which the tripping scenario starts", type=int, default=10000)
    parser.add_argument("--regular-timestep", nargs="?", help="timestep at which regular scenario starts", type=int, default=13000)
    parser.add_argument("--inflow-window", nargs="?", help="inflow window size (in steps) used in switch-mode 2 and whitebox monitor", type=int, default=600)
    parser.add_argument("--speed-window", nargs="?", help="size (in steps) of speed window array", type=int, default=1000)
    args = parser.parse_args()


    RENDER = False
    PARALLEL = False
    RUNALL = False
    if args.render == "true":
        RENDER = True
    if args.parallel == "true":
        PARALLEL = True
    if args.runall == "true":
        RUNALL = True

    switch_mode = args.switch_mode
    controller = args.mode
    inflow_window = args.inflow_window
    speed_window = args.speed_window
    seed = args.seed

    starting_step = 0
    model_file = args.file
    if model_file is not None: 
        starting_step = int(model_file.strip("rl_model.zip"))

    durations = {"yellow": args.yellow, "straight": args.straight, "left": args.left}
    flow_params = setup_flow(args.rate, args.scenario, durations, args.num_observed, args.route, args.trip_timestep, args.regular_timestep, args.horizon, render=RENDER)
    
    p = Pool(2)
    load_input_arr = []
    if RUNALL:
        # safe 
        load_input_arr.append([0, flow_params, model_file, switch_mode, 'safe', PARALLEL, inflow_window, speed_window, seed])
        # ai
        load_input_arr.append([0, flow_params, model_file, 0, 'ai', PARALLEL, inflow_window, speed_window, seed])
        # switch-mode 1
        load_input_arr.append([0, flow_params, model_file, 1, 'ai', PARALLEL, inflow_window, speed_window, seed])
        # switch-mode 2
        load_input_arr.append([0, flow_params, model_file, 2, 'ai', PARALLEL, inflow_window, speed_window, seed])
        # switch-mode 3: whitebox monitor
        load_input_arr.append([0, flow_params, model_file, 3, 'ai', PARALLEL, inflow_window, speed_window, seed])
    elif controller == 'run':
        load_input_arr.append([0, flow_params, model_file, switch_mode, 'ai', PARALLEL, inflow_window, speed_window, seed])
        if PARALLEL: # create another thread when running test simulation in parallel
            load_input_arr.append([1, flow_params, model_file, switch_mode, 'ai', PARALLEL, inflow_window, speed_window, seed])
    elif controller == 'safe':
        load_input_arr.append([0, flow_params, model_file, switch_mode, 'safe', PARALLEL, inflow_window, speed_window, seed])

    if controller != "plot":
        output_arr = p.map(mp_simulate, load_input_arr)

    # generate plots
    if RUNALL or controller == "plot":
        plot(True, args.scenario, args.trip_timestep, args.regular_timestep, args.horizon)
        plot(False, args.scenario, args.trip_timestep, args.regular_timestep, args.horizon)
