# Import required packages
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import cm
import matplotlib.font_manager as fm
from matplotlib.ticker import MaxNLocator
import argparse
# Rebuild the matplotlib font cache
fm._rebuild()
# # Collect all the font names available to matplotlib
# font_names = [f.name for f in fm.fontManager.ttflist]
# print(font_names)

ROLLING_AVG = 300


def plot(normalize, scenario, trip_scenario_timestep, regular_scenario_timestep, tot_timestep):
        
    # load CSV files
    time_arr_ai, speed_arr_ai, is_ai_arr_ai = np.loadtxt('switch-mode0.csv', unpack=True, delimiter=',', skiprows=1)
    confidence_arr = np.loadtxt("fuzz.csv", unpack=True, delimiter=',', skiprows=1)
    
    # create data frames 
    # df_1 = pd.DataFrame({"step": time_arr_1, "speed" : speed_arr_1, "ai": is_ai_arr_1})
    # df_2 = pd.DataFrame({"step": time_arr_2, "speed" : speed_arr_2, "ai": is_ai_arr_2})
    # df_3 = pd.DataFrame({"step": time_arr_3, "speed" : speed_arr_3, "ai": is_ai_arr_3})
    df_ai = pd.DataFrame({"speed" : speed_arr_ai})
    df_confidence = pd.DataFrame({"hit-rate" : confidence_arr})

    # AI_mean = df_ai["speed"].mean()
    # safe_mean = df_safe["speed"].mean()


    if not normalize:
        # print("safe average speed: {:.2f}".format(df_safe["speed"].mean()))
        print("ai average speed: {:.2f}".format(df_ai["speed"].mean()))
        # print("Blackbox average speed: {:.2f}".format(df_1["speed"].mean()))
        # print("switch-mode 2 average speed: ",  df_2["speed"].mean())
        # print("RADICS average speed: {:.2f}".format(df_3["speed"].mean()))

    if normalize: 
        # normalization
        df_1["speed"] = df_1["speed"] / df_safe["speed"]
        # df_2["speed"] = df_2["speed"] / df_safe["speed"]
        df_3["speed"] = df_3["speed"] / df_safe["speed"]
        df_ai["speed"] = df_ai["speed"] / df_safe["speed"]


    # apply rolling average
    df_ai["speed"] = df_ai["speed"].rolling(window=ROLLING_AVG).mean()
    df_confidence["hit-rate"] = df_confidence["hit-rate"].rolling(window=ROLLING_AVG).mean()


    # # label data based on whether it's AI controller
    # df_1_ai = df_1[df_1['ai'] != 0]
    # df_1_safe = df_1[df_1['ai'] == 0]
    # # df_2_ai = df_2[df_2['ai'] != 0]
    # # df_2_safe = df_2[df_2['ai'] == 0]
    # df_3_ai = df_3[df_3['ai'] != 0]
    # df_3_safe = df_3[df_3['ai'] == 0]
    # df_1['label'] = np.where(df_1['ai'] != 0, -1, 1)
    # # df_2['label'] = np.where(df_2['ai'] != 0, -1, 1)
    # df_3['label'] = np.where(df_3['ai'] != 0, -1, 1)


    # Create figure object and store it in a variable called 'fig' # figsize=(3, 3)
    fig = plt.figure(figsize=(20,10))
    # Generate 10 colors from the 'tab10' colormap
    colors = cm.get_cmap('tab10', 10)

    # assign colors 
    c_ai = "red"
    c_confidence = "blue"

    mpl.rcParams['font.family'] = 'Times New Roman'
    plt.rcParams['font.size'] = 32
    plt.rcParams['axes.linewidth'] = 3
    # Add axes object to our figure that takes up entire figure
    ax = fig.add_axes([0, 0, 1, 1])
    # Edit the major and minor ticks of the x and y axes
    ax.xaxis.set_tick_params(which='major', size=10, width=2, direction='in', top=True)
    # ax.xaxis.set_tick_params(which='minor', size=7, width=2, direction='in', top=True)
    ax.yaxis.set_tick_params(which='major', size=10, width=2, direction='in', right=False)
    # ax.yaxis.set_tick_params(which='minor', size=7, width=2, direction='in', right=False)

    # Hide the top and right spines of the axis
    # ax.spines['right'].set_visible(False)
    # ax.spines['top'].set_visible(False)

    # Set the axis limits
    ax.set_xlim(0, tot_timestep)
    # Add the x axis label
    ax.set_xlabel('Timestep', labelpad=10)

    ax.set_ylim(0, 8)
    # Add the y axis label
    ax.set_ylabel('Speed (m/s)', color=c_ai, labelpad=10)
    ax.tick_params(axis='y', labelcolor=c_ai)


    ax2 = ax.twinx()
    # ax2.set_ylim(0, 0.8)
    ax2.set_ylabel('Confidence Level', color=c_confidence, labelpad=10)    
    ax2.tick_params(axis='y', labelcolor=c_confidence)

    # get rid of duplicated 0 at origin
    plt.gca().xaxis.set_major_locator(MaxNLocator(prune='lower'))

    # mark regular cases and tripping cases
    ax.axvline(x=trip_scenario_timestep, linestyle='solid', color='purple')
    ax.axvline(x=regular_scenario_timestep, linestyle='solid', color='purple')
        
    ax.plot(time_arr_ai, df_ai["speed"], linewidth=3, color=c_ai, label='AI', linestyle='solid')
    ax2.plot([i for i in range(7900)], df_confidence["hit-rate"], linewidth=3, color=c_confidence, label='confidence', linestyle='dotted')

    def plot_func_mode_1(group):
        style = 'solid' if (group['label'] < 0).all() else 'dashed'
        ax.plot(group.step, group.speed, linewidth=3, color=c_sm1 , label='', linestyle=style)

    # def plot_func_mode_2(group):
    #     style = 'dashed' if (group['label'] < 0).all() else 'solid'
    #     ax.plot(group.step, group.speed, linewidth=2, color=c_sm2 , label='', linestyle=style)

    def plot_func_mode_3(group):
        style = 'solid' if (group['label'] < 0).all() else 'dashed'
        ax.plot(group.step, group.speed, linewidth=3, color=c_sm3, label='', linestyle=style)

    # df_1 = df_1.dropna(axis=0, how='any')
    # df_2 = df_2.dropna(axis=0, how='any')
    # df_3= df_3.dropna(axis=0, how='any')

    # df_1.groupby((df_1['label'].shift() * df_1['label'] < 0).cumsum()).apply(plot_func_mode_1)
    # df_2.groupby((df_2['label'].shift() * df_2['label'] < 0).cumsum()).apply(plot_func_mode_2)
    # df_3.groupby((df_3['label'].shift() * df_3['label'] < 0).cumsum()).apply(plot_func_mode_3)

    # create customized legends
    handles, labels = ax.get_legend_handles_labels()
    handles2, labels2 = ax2.get_legend_handles_labels()
    # ## Create custom artists
    # switch_mode_1_ai = plt.Line2D((0,1),(0,0), color=c_sm1, linewidth=3, linestyle="solid")
    # switch_mode_1_safe = plt.Line2D((0,1),(0,0), color=c_sm1,linewidth=3, linestyle="dashed")
    # # switch_mode_2_ai = plt.Line2D((0,1),(0,0), color=c_sm2, linestyle="dashed")
    # # switch_mode_2_safe = plt.Line2D((0,1),(0,0), color=c_sm2, linestyle="solid")
    # switch_mode_3_ai = plt.Line2D((0,1),(0,0), color=c_sm3, linewidth=3, linestyle="solid")
    # switch_mode_3_safe = plt.Line2D((0,1),(0,0), color=c_sm3, linewidth=3, linestyle="dashed")

    # Create legend from custom artist/label lists
    legend_objs = handles 
    ax.legend(
        legend_objs,
        labels,
        loc='best',
        frameon=False, 
        fontsize=32
    )
    ax2.legend(
        handles2,
        labels2,
        loc='best',
        frameon=False, 
        fontsize=32
    )

    # title_str = '80M rl_model, scenario {:d}{}'.format(scenario, ", normalized" if normalize else "")
    title_str = 'RADICS{}'.format(" Normalized" if normalize else "")
    # figure title
    plt.title(title_str)
    # Save figure
    plt.savefig('{}.png'.format(title_str), dpi=300, transparent=False, bbox_inches='tight')

    # switch mode 1
    # AI 
    # ax.plot(df_1_ai["step"].to_numpy(), df_1_ai["speed"].to_numpy(), linewidth=2, color=colors(1), label='switch mode 1 ai', linestyle='dashed')
    # safe
    # ax.plot(df_1_safe["step"].to_numpy(), df_1_safe["speed"].to_numpy(), linewidth=2, color=colors(1), label='switch mode 1 safe', linestyle='solid')
    # switch mode 2
    # AI 
    # ax.plot(df_2_ai["step"].to_numpy(), df_2_ai["speed"].to_numpy(), linewidth=2, color=colors(2), label='switch mode 2 ai', linestyle=':')
    # safe
    # ax.plot(df_2_safe["step"].to_numpy(), df_2_safe["speed"].to_numpy(), linewidth=2, color=colors(2), label='switch mode 2 safe', linestyle='solid')


    # ax.plot(time_arr_1, df_1["speed"], linewidth=2, color=colors(1), label='switch mode 1', linestyle='dashed')
    # ax.plot(time_arr_2, df_2["speed"], linewidth=2, color=colors(2), label='switch mode 2', linestyle='solid')
    # ax.plot(time_arr_safe, df_safe["speed"], linewidth=2, color=colors(0), label='safe', linestyle='solid')
    # ax.plot(time_arr_ai, df_ai["speed"], linewidth=2, color=colors(3), label='ai', linestyle='dotted')
    # ax.axhline(y=1, linestyle='dashed')
    

    # ax.legend(bbox_to_anchor=(1, 1), loc="best", frameon=False, fontsize=16)
    # ax.legend(loc="best")

    # Plot and show our data
    # ax.plot(time_arr_safe, speed_arr_safe, linewidth=2, color=colors(4), label='safe', linestyle='solid')
    # ax.plot(time_arr_1, speed_arr_1, linewidth=2, color=colors(1), label='switch mode 1', linestyle='dashed')
    # ax.plot(time_arr_2, speed_arr_2, linewidth=2, color=colors(2), label='switch mode 2', linestyle=':')

    
     # ???
    # speed_arr_2 = df_2.to_numpy()
    # speed_arr_safe = df_safe.to_numpy()

    

    # plt.show()

if __name__ == '__main__':  
    # parser = argparse.ArgumentParser()
    # parser.add_argument("--scenario", nargs="?", help="scenario", type=int, default=0)
    # parser.add_argument("--normalize", nargs="?", choices=["true", "false"], help="whether to normalize the plot", type=str, default="false")
    # args = parser.parse_args()

    # normalize = False
    # if args.normalize == "true":
    #     normalize = True

    plot(False, 7, 3000, 8000, 8000)