When you log into rain, first run `conda deactivate`,
then run `conda activate flow`
Then cd into `training_system_double_lanes`


## Running Scripts located in `training_system_double_lanes`

#### 1) Kick off One Training Job with `run_train_session.sh`
Script looks like this:
`./run_train_session.sh <new_job_name> <FOLDER_NAME THAT contains RL lights, example generalized_sp22> ALL flags seperated by an underscore`

Example Run
`./run_train_session.sh test_job generalized_sp22 --num-observed=6_--yellow=1.5_--rand-seed-val=30000_--use-random`
This script will create all necessary folders to log outputs, save models, and use tmux to set up a background train job

#### 2) Set up multiple parallel runs across multiple machines with  `training_multi_runs.sh`
Script looks like this:
`./training_multi_runs.sh add_jobs.txt`
Where add_jobs.txt is a list of all the train jobs you want to kick off

Your `add_jobs.txt` file will look something like this:
```
train JOB_ONE generalized_sp22 --rand-seed-val=10000_--look-ahead=1_--rows=5_--cols=5
train JOB_TWO generalized_sp22 --rand-seed-val=20000_--look-ahead=1_--rows=5_--cols=5
train JOB_THREE generalized_sp22 --rand-seed-val=30000_--look-ahead=1_--rows=5_--cols=5

```

## Running Scripts located in `devtools`
Note: Make sure you are in the `training_system_double_lanes` folder first,
before running these commands

#### 1) Generating train plots with `plot_output.py`
Script will parse the logs for a given train job and plot the speeds and wait times
Plots witll be saved to the `results/plots` folder

Example
`python devtools/plot_output.py -f results/runs_txt_files_sp_22/5x5_safe_sides_b_look_one.txt`

#### 2) Locating the best model of any run with `get_best_acc.py`
Script will parse the logs for a given train job and get the best model and its
average speed

Example
`python devtools/get_best_acc.py -f results/runs_txt_files_sp_22/5x5_safe_sides_a_look_one.txt`

#### 3) Terminating running jobs, distributed across machines with `delete_job_list.sh`
Script looks like this:
`./devtools/shell_scripts/delete_job_list.sh del_jobs.txt`
Where `del_jobs.txt` is a list of all the train jobs you want to terminate.
NOTE: This operation is irreversable, so use with caution
Double check the `del_jobs.txt`file before running

Your `del_jobs.txt` file should look something like this

```
3x3_safe_sides_a_default
3x3_safe_sides_b_default
3x3_safe_sides_c_default
3x3_random_sides_a_default
3x3_random_sides_b_default
3x3_random_sides_c_default

```
Where each row contains the name of a running job (on any rain machine) that you wish
to terminate. (Seperated by the newline character)

#### 4) Checking the status of running jobs, distributed across machines with `check_available_sessions.sh`

Script will tell you if it is feasable to kick off training jobs
across different machines, given a threshold script will also
print out a list of all running jobs for each machine if the verbose flag is set
`./devtools/shell_scripts/check_available_sessions.sh <total number of jobs we are trying to kick off> <threshold number of jobs that each machine can tolerate> <VERBOSE FLAG. Set to true to print the names of all running jobs for each machine>`

Example
`./devtools/shell_scripts/check_available_sessions.sh 15 4 true`

