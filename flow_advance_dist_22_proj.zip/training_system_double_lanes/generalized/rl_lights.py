"""
A reinforcement learning training script using FLOW (https://github.com/flow-project/flow). 

Model: PPO2
Agent: Single agent
Policy: MlpPolicy
Libraries (used by flow): stable-baselines, tensorflow, SUMO

Network:
2 x 2 traffic grid. 
Each edge has two lanes. Vehicles can turn and routes are random. 

"""

import warnings
from multiprocessing import Process, freeze_support
from modules.helper import gen_edges, get_outside_edges, evaluate_model, train, run, setup_flow
from modules.experiment import Experiment
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices =["train", "run", "safe"] ,help="choose from [train, run, safe]", type=str)
    parser.add_argument("file", nargs="?", help="model file", type=str)
    parser.add_argument("--eval", nargs="?", help="number of random runs to evaluate a model", type=int, default=1)
    parser.add_argument("--render", nargs="?", choices=["true", "false"], help="whether to render SUMO gui", type=str, default="false")
    parser.add_argument("--rate", nargs="?", help="number of vehicles per hour", type=int, default=500)
    parser.add_argument("--yellow", nargs="?", help="specify the duration of yellow lights in safe controller", type=float, default=3)
    parser.add_argument("--straight", nargs="?", help="specify the duration of straight red/green lights in safe controller", type=float, default=26)
    parser.add_argument("--left", nargs="?", help="specify the duration of left-turning red/green lights in safe controller", type=float, default=5)
    parser.add_argument("--scenario", nargs="?", help="scenarios that trip the AI system", type=int, default=None)
    parser.add_argument("--route", nargs="?", help="routes that trip the AI system", type=int, default=None)
    parser.add_argument("--num-observed", nargs="?", help="number of vehicles observed on each edge (must be even)", type=int, default=6)
    parser.add_argument("--rows", nargs="?", help="number of rows", type=int, default=1)
    parser.add_argument("--cols", nargs="?", help="number of columns", type=int, default=1)
    args = parser.parse_args()

    RENDER = False
    if args.render == "true":
        RENDER = True

    starting_step = 0
    model_file = args.file
    if model_file is not None: 
        starting_step = int(model_file.strip("rl_model.zip"))

    durations = {"yellow": args.yellow, "straight": args.straight, "left": args.left}

    if args.mode == "train":
        flow_params = setup_flow(args.rate, args.scenario, durations, args.num_observed, args.route, rows=args.rows, cols=args.cols, render=RENDER)
        print("starting from step", starting_step)
        train(flow_params, starting_step, model_file)
    elif args.mode == "run":
        if model_file is not None: 
            flow_params = setup_flow(args.rate, args.scenario, durations, args.num_observed, args.route, rows=args.rows, cols=args.cols, render=RENDER)
            print("running from step", starting_step)
            run(flow_params, starting_step, model_file, args.eval)
        else:
            print("need to specify which model to run")
            exit(1)
    elif args.mode == "safe":
        flow_params = setup_flow(args.rate, args.scenario, durations, args.num_observed, args.route, rows=args.rows, cols=args.cols, static=True, render=RENDER)
        print("starting safe controller")
        exp = Experiment(flow_params)
        # run the sumo simulation
        _ = exp.run(1, convert_to_csv=False)

if __name__ == '__main__':
    warnings.filterwarnings('ignore', category=FutureWarning)
    freeze_support()
    main()

# when training, generate a random seed. 
# in run, here's the seed to run recreate