"""
A reinforcement learning training script using FLOW (https://github.com/flow-project/flow). 

Model: PPO2
Agent: Single agent
Policy: MlpPolicy
Libraries (used by flow): stable-baselines, tensorflow, SUMO

Network:
2 x 2 traffic grid. 
Each edge has two lanes. Vehicles can turn and routes are random. 

"""

import warnings
from multiprocessing import Process, freeze_support
from helper import gen_edges, get_outside_edges, evaluate_model, train, run, setup_flow
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices =["train", "run", "safe"] ,help="choose from [train, run, safe]", type=str)
    parser.add_argument("file", nargs="?", help="model file", type=str)
    parser.add_argument("--runs", nargs="?", help="number of random runs to evaluate a model", type=int, default=1)

    args = parser.parse_args()

    starting_step = 0
    model_file = args.file
    if model_file is not None: 
        starting_step = int(model_file.strip("rl_model.zip"))

    flow_params = setup_flow()

    if args.mode == "train":
        print("starting from step", starting_step)
        train(flow_params, starting_step, model_file)
    elif args.mode == "run":
        if model_file is not None: 
            print("running from step", starting_step)
            run(flow_params, starting_step, model_file, args.runs)
        else:
            print("need to specify which model to run")
            exit(1)
    elif args.mode == "safe":
        print("starting safe controller")

if __name__ == '__main__':
    warnings.filterwarnings('ignore', category=FutureWarning)
    freeze_support()
    main()

# when training, generate a random seed. 
# in run, here's the seed to run recreate