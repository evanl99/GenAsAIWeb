import numpy as np
from stable_baselines import PPO2
from stable_baselines.common.vec_env import DummyVecEnv
from flow.utils.registry import env_constructor
from flow.core.params import VehicleParams
from flow.controllers import GridRouter, SimCarFollowingController
from flow.core import rewards
from flow.core.params import InFlows
from flow.controllers.lane_change_controllers import SimLaneChangeController
from flow.core.params import SumoParams, EnvParams, InitialConfig, NetParams, \
    InFlows, SumoCarFollowingParams, SumoLaneChangeParams
from flow.core.params import TrafficLightParams
from flow.core.params import NetParams
from grid_env import TrafficLightGridPOEnv
from grid_network import TrafficLightGridNetwork
from pickle import dump, load
from tabulate import tabulate
import numpy as np
import random
import tensorflow as tf
from datetime import datetime

training_model_seed = 7218
# configurable parameters
VEHICLE_RATE = 500 # number of vehicles per hour
HORIZON = 3000 # number of training steps per iteration/simulation
ROLLOUT_SIZE = 3000 # rollout_size should be multiple of 4
STEPS_PER_TRAIN = 50000 
VERBOSE = 2

def gen_edges(col_num, row_num):
    """Generate the names of the outer edges in the grid network.
    Parameters
    ----------
    col_num : int
        number of columns in the grid
    row_num : int
        number of rows in the grid
    Returns
    -------
    list of str
        names of all the outer edges
    """
    edges = []

    # build the left and then the right edges
    for i in range(col_num):
        edges += ['left' + str(row_num) + '_' + str(i)]
        edges += ['right' + '0' + '_' + str(i)]

    # build the bottom and then top edges
    for i in range(row_num):
        edges += ['bot' + str(i) + '_' + '0']
        edges += ['top' + str(i) + '_' + str(col_num)]

    return edges


def get_outside_edges(rows, cols):
    edges = []
    for i in range(rows):
        edges.append("bot{}_0".format(i))
        edges.append("top{}_{}".format(i, cols))
    for j in range(cols):
        edges.append("left{}_{}".format(rows, j))
        edges.append("right0_{}".format(j))
    return edges

def evaluate_model(model, eval_env, horizon, steps):
    obs = eval_env.reset()
    reward = 0
    total = 0
    count = 0
    times = {}
    speed = []
    prev_total = 0
    prev_count = 0
    for i in range(horizon):
        action, _states = model.predict(obs)
        obs, rs, dones, info = eval_env.step(action)
        reward += rs
        # calculate average speed at this timestep 
        vel = np.array(eval_env.envs[0].k.vehicle.get_speed(eval_env.envs[0].k.vehicle.get_ids()))
        if not (any(vel < -100) or len(vel) == 0):
            speed.append(np.mean(vel))
        # reset prev total and prev count
        if len(eval_env.envs[0].k.vehicle.get_ids()) != 0:
            prev_total = 0
            prev_count = 0
        for veh_id in eval_env.envs[0].k.vehicle.get_ids():
            times[veh_id] = eval_env.envs[0].k.kernel_api.vehicle.getAccumulatedWaitingTime(veh_id)
            # get all remaining cars in the system
            prev_total += times[veh_id]
            prev_count += 1
        try:
            for veh_id in eval_env.envs[0].k.vehicle.get_arrived_ids():
                total += times[veh_id]
                count += 1
        except TypeError:
            pass

    arrived_waiting_time = total / count
    remaining_waiting_time = prev_total / prev_count
    all_waiting_time = (total + prev_total) / (prev_count + count)
    average_speed = np.mean(speed)

    print("after ", steps, " steps") 
    print("average waiting time (s) of arrived vehicles is: ", arrived_waiting_time)
    print("average waiting time (s) of remaining vehicles is: ", remaining_waiting_time)
    print("average waiting time (s) of all vehicles is:", all_waiting_time)
    print("average speed (m/s) of all vehicles is ", average_speed)
    return arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed


def train(flow_params, starting_step, model_file):
    # whether render simulation when training
    flow_params['sim'].render = False

    constructor = env_constructor(params=flow_params, version=0)()
    env = DummyVecEnv([lambda: constructor])
    
    # setup training model
    train_model = PPO2('MlpPolicy', env, verbose=VERBOSE, n_steps=ROLLOUT_SIZE, seed=training_model_seed, learning_rate=5e-4)

    # set random seeds
    np.random.seed(5051)
    random.seed(6169)

    steps = 0 # start with a new model

    # load an existing model 
    if starting_step != 0: 
        train_model = PPO2.load(model_file, env=env)
        print("loading: "+model_file)
        steps = starting_step
    
    while True:
        print("steps per training is ", STEPS_PER_TRAIN)
        train_model.learn(total_timesteps=STEPS_PER_TRAIN)
        steps += STEPS_PER_TRAIN

        # save model after each iteration
        fname = "rl_model" + str(steps)
        train_model.save(fname)
        # save random state 
        pickle_fname = fname + ".pickle"
        rand_state_objects = (random.getstate(), np.random.get_state())
        rand_state_file = open(pickle_fname, "wb")
        dump(rand_state_objects, rand_state_file)
        rand_state_file.close()

        print("saving" + fname)

        env = env_constructor(params=flow_params, version=0)()
        # The algorithms require a vectorized environment to run
        eval_env = DummyVecEnv([lambda: env])

        # evaluate the model and print out average delay, speed
        evaluate_model(train_model, eval_env, flow_params['env'].horizon, steps)
    
def run(flow_params, starting_step, model_file, num_runs):
     # render option 
    flow_params['sim'].render = True 
    # setup env 
    env = env_constructor(params=flow_params, version=0)()
    eval_env = DummyVecEnv([lambda: env])
    
    

    print("starting evaluation of the model for ", num_runs, " runs")
    
    

    if num_runs == 1:
        # load random states 
        # pickle_fname = "rl_model" + str(starting_step) + ".pickle"
        # rand_state_objects = tuple()
        # rand_state_file = open(pickle_fname, "rb")
        # rand_state_objects = load(rand_state_file)
        # rand_state_file.close()

        # load the model for evaluation 
        eval_model = PPO2.load(model_file, env=eval_env, n_steps=ROLLOUT_SIZE)

        # np.random.seed(5051)
        # random.seed(6169)
        # random.setstate(rand_state_objects[0])
        # np.random.set_state(rand_state_objects[1])

        random.seed(6367)
        np.random.seed(9239)
        tf.set_random_seed(6883)

        evaluate_model(eval_model, eval_env, flow_params['env'].horizon, starting_step)
        
    else:
        arrived_waiting_time_arr = [] 
        remaining_waiting_time_arr = [] 
        all_waiting_time_arr = [] 
        average_speed_arr = []

        # random.seed(datetime.now())

        for i in range(num_runs): 
            print("running ", i + 1, " out of ", num_runs)

            env = env_constructor(params=flow_params, version=0)()
            eval_env = DummyVecEnv([lambda: env])

            eval_model = PPO2.load(model_file, env=eval_env, n_steps=ROLLOUT_SIZE)
            random.seed(datetime.now())
            rand_seed = random.randrange(10000)
            np_rand_seed= random.randrange(10000)
            tf_rand_seed = random.randrange(10000)
            print("python random seed is ", rand_seed)
            print("np random seed is ", np_rand_seed)
            print("tf random seed is ", tf_rand_seed)
            random.seed(rand_seed)
            np.random.seed(np_rand_seed)
            tf.set_random_seed(tf_rand_seed)
            # evaluate the model and print out average delay, speed
            
            arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed = evaluate_model(eval_model, eval_env, flow_params['env'].horizon, starting_step)
            arrived_waiting_time_arr.append(arrived_waiting_time)
            remaining_waiting_time_arr.append(remaining_waiting_time)
            all_waiting_time_arr.append(all_waiting_time)
            average_speed_arr.append(average_speed)
            
        print(tabulate([["10th percentile", np.percentile(arrived_waiting_time_arr, 10), np.percentile(remaining_waiting_time_arr, 10), np.percentile(all_waiting_time_arr, 10), np.percentile(average_speed_arr, 10)],
            ["50th percentile", np.percentile(arrived_waiting_time_arr, 50), np.percentile(remaining_waiting_time_arr, 50), np.percentile(all_waiting_time_arr, 50), np.percentile(average_speed_arr, 50)], 
            ["90th percentile", np.percentile(arrived_waiting_time_arr, 90), np.percentile(remaining_waiting_time_arr, 90), np.percentile(all_waiting_time_arr, 90), np.percentile(average_speed_arr, 90)],
            ["95th percentile", np.percentile(arrived_waiting_time_arr, 95), np.percentile(remaining_waiting_time_arr, 95), np.percentile(all_waiting_time_arr, 95), np.percentile(average_speed_arr, 95)], 
            ["maximum", np.amax(arrived_waiting_time_arr), np.amax(remaining_waiting_time_arr), np.amax(all_waiting_time_arr), np.amax(average_speed_arr)], 
            ["minimum", np.amin(arrived_waiting_time_arr), np.amin(remaining_waiting_time_arr), np.amin(all_waiting_time_arr), np.amin(average_speed_arr)]], 
            headers=["", "Arrived Waiting Time (s)", "Remaining Waiting Time (s)", "All Waiting Time (s)", "Average Speed (m/s)"],
            tablefmt='orgtbl'))

def setup_flow():

    # grid parameters
    inner_length = 100
    long_length = 100
    short_length = 100
    n = 2  # rows
    m = 2  # columns
    num_cars_left = 20
    num_cars_right = 20
    num_cars_top = 20
    num_cars_bot = 20
    # tot_cars = (num_cars_left + num_cars_right) * m + (num_cars_top + num_cars_bot) * n

    grid_array = {"short_length": short_length, "inner_length": inner_length,
                  "long_length": long_length, "row_num": n, "col_num": m,
                  "cars_left": num_cars_left, "cars_right": num_cars_right,
                  "cars_top": num_cars_top, "cars_bot": num_cars_bot}


    """
    Traffic light phases
    SUMO traffic lights documentation: https://sumo.dlr.de/docs/Simulation/Traffic_Lights.html#Signal_state_definitions
     
    S: straight lane, L: left-turning lane, R: right-turning lane
    
    * One lane no turning (S): 
    - static phases for safe controllers
    phases = [{"duration": "31", "state": "GGGrrrGGGrrr"},
              {"duration": "6", "state": "yyyrrryyyrrr"},
              {"duration": "31", "state": "rrrGGGrrrGGG"},
              {"duration": "6", "state": "rrryyyrrryyy"}]
    - phases required for safe controllers and RL systems        
    phases1lane = ['GGGrrrGGGrrr','yyyrrryyyrrr','rrrGGGrrrGGG','rrryyyrrryyy']

    * Two lanes with turning (L | S/R)
    - static phases for safe controllers
    durations2lanes_left_turning = [{"duration": "18", "state": "GGrrrrGGrrrr"},
                   {"duration": "3", "state": "yyrrrryyrrrr"},
                   {"duration": "5", "state": "rrGrrrrrGrrr"},
                   {"duration": "3", "state": "rryrrrrryrrr"},
                   {"duration": "18", "state": "rrrGGrrrrGGr"},
                   {"duration": "3", "state": "rrryyrrrryyr"},
                   {"duration": "5", "state": "rrrrrGrrrrrG"},
                   {"duration": "3", "state": "rrrrryrrrrry"}]
    - phases required for safe controllers and RL systems     
    phases2lanes = ["GGrrrrGGrrrr", "yyrrrryyrrrr", "rrGrrrrrGrrr", "rryrrrrryrrr", "rrrGGrrrrGGr", "rrryyrrrryyr", "rrrrrGrrrrrG", "rrrrryrrrrry"]

    * Three lanes with turning (L | S | R)
    - static phases for safe controllers
    durations3lanes = [{"duration": "12", "state": "GGGrrrrrGGGrrrrr"},
                   {"duration": "3", "state": "yyyrrrrryyyrrrrr"},
                   {"duration": "5", "state": "rrrGrrrrrrrGrrrr"},
                   {"duration": "3", "state": "rrryrrrrrrryrrrr"},
                   {"duration": "12", "state": "rrrrGGGrrrrrGGGr"},
                   {"duration": "3", "state": "rrrryyyrrrrryyyr"},
                   {"duration": "5", "state": "rrrrrrrGrrrrrrrG"},
                   {"duration": "3", "state": "rrrrrrryrrrrrrry"}]
    - phases required for safe controllers and RL systems     
    phases3lanes = ["GGGrrrrrGGGrrrrr", "yyyrrrrryyyrrrrr", "rrrGrrrrrrrGrrrr", "rrryrrrrrrryrrrr", "rrrrGGGrrrrrGGGr", "rrrryyyrrrrryyyr", "rrrrrrrGrrrrrrrG", "rrrrrrryrrrrrrry"]
    """
    phases2lanes = ["GGrrrrGGrrrr", "yyrrrryyrrrr", "rrGrrrrrGrrr", "rryrrrrryrrr", "rrrGGrrrrGGr", "rrryyrrrryyr", "rrrrrGrrrrrG", "rrrrryrrrrry"]
    
    # vehicle parameters
    vehicles = VehicleParams()
    vehicles.add("human",
                 acceleration_controller=(SimCarFollowingController, {}),
                 lane_change_controller=(SimLaneChangeController, {}),
                 lane_change_params=SumoLaneChangeParams(lane_change_mode='strategic'),
                 car_following_params=SumoCarFollowingParams(
                     speed_mode="right_of_way",
                     impatience="off",
                     decel=7.5,
                    #  accel=4.0,
                     min_gap=2.5))

    initial_config = InitialConfig(spacing='custom')

    # introducing vehicles to the network 
    inflows = InFlows()
    p = .15
    # inflows.add(veh_type="human",
    #                     edge="top1_2",
    #                     vehs_per_hour=500,
    #                     # probability=p,
    #                     depart_lane="best",
    #                     depart_speed="random",
    #                     color="white")
    for edge in get_outside_edges(n, m):
        if edge[0] == 'l' or edge[0] == 'r':
            inflows.add(veh_type="human",
                        edge=edge,
                        vehs_per_hour=VEHICLE_RATE,
                        # probability=p,
                        depart_lane="best",
                        depart_speed="random",
                        color="white")
        else:
            inflows.add(veh_type="human",
                        edge=edge,
                        vehs_per_hour=VEHICLE_RATE,
                        # probability=p,
                        depart_lane="best",
                        depart_speed="random",
                        color="white")

    # additional parameters
    ADDITIONAL_NET_PARAMS = {"grid_array": grid_array, "speed_limit": 35,
                             "horizontal_lanes": 2, "vertical_lanes": 2,
                             "traffic_lights": True}
    ADDITIONAL_ENV_PARAMS = {"discrete": True, "num_observed": 6, 'switch_time': 3,'switch_time_rg' : 3,
                             'tl_type': 'actuated', 'target_velocity': 50, 'phase': phases2lanes}
    
    # network, environment, and simulation parameters
    net_params = NetParams(inflows=inflows, additional_params=ADDITIONAL_NET_PARAMS)
    env_params = EnvParams(additional_params=ADDITIONAL_ENV_PARAMS)
    sim_params = SumoParams(sim_step=.1, render=True, restart_instance=True)

    # flow parameters
    flow_params = dict(
        exp_tag='RL_lights',
        env_name=TrafficLightGridPOEnv,
        network=TrafficLightGridNetwork,
        simulator='traci',
        sim=sim_params,
        env=env_params,
        net=net_params,
        veh=vehicles,
        initial=initial_config,
        # tls=tl_logic
    )
    # setting number of time steps per simulation/iteration
    flow_params['env'].horizon = HORIZON
    return flow_params