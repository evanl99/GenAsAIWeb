### NOTE: NEED TO BE IN TRAIN_SYSTEMS_DOUBLE_LANES DIRECTORY FOR THIS TO WORK
### Example of running this script: ./run_train_session.sh straight-light-time-inc template --straight=39

SESSION_NAME=$1 
MODEL_TYPE_DIR=$2 #Ex: Template, generalized, generalized-tiny
RUN_ARGS=$3 #SEPERATE BY UNDERSCORE EX: --num-observed=3_--yellow=5

#Create new tmux session that will contain run
tmux new-session -d -s ${SESSION_NAME}

#Handle conda env in session
tmux send-keys eval " source /opt/anaconda3/etc/profile.d/conda.sh" C-m
tmux send-keys eval " conda deactivate" C-m
tmux send-keys eval " conda activate flow" C-m

path=$(pwd)
temp_path="/home/assured_ai/daniel/flow/training_system_double_lanes" #TODO: Fix up logic

#Seperate by underscore
RUN_ARGS_ARR=(${RUN_ARGS//_/ })
RUN_SCRIPT="python ${temp_path}/${MODEL_TYPE_DIR}/rl_lights.py train"

for elem in "${RUN_ARGS_ARR[@]}"
do
   #echo "$elem"
   RUN_SCRIPT+=" ${elem}"
done

#Get name for text file
OUT_FILE_NAME=$(tmux display-message -p '#S')
echo "Created New Session Name: ${OUT_FILE_NAME}"

#Add --model_path args
RUN_SCRIPT+=" --model_path ${temp_path}/results/sp_22_rl_models/${OUT_FILE_NAME}"

echo "RUNNING SCRIPT: ${RUN_SCRIPT} > results/runs_txt_files_sp_22/${OUT_FILE_NAME}.txt"
tmux send-keys eval " ${RUN_SCRIPT} > ${temp_path}/results/runs_txt_files_sp_22/${OUT_FILE_NAME}.txt" C-m
tmux detach -s ${SESSION_NAME}
