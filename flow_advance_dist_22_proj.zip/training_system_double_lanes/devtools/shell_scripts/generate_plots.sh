#!/bin/bash

#Generates plots for all text files:
#WARNING, WILL OVERWRITE EXISTING PLOTS
#NOTE: for script to work, you need to be in the "training_system_double_lanes" directory

path=$(pwd)
for filename in ${path}/results/runs_txt_files_sp_22/*.txt; do
    echo ${filename}
    eval "python3 devtools/plot_output.py -f ${filename}"
done
