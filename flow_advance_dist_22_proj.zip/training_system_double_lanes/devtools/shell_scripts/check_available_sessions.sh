#!/bin/bash

#This script will go through all machines and check if there is room to distribute all jobs
#Args
# 1= num jobs: number of jobs that we want to be able to run. We will check if there is enough room to run them all
# 2 = threshold_per_machine: If #jobs_in_a_machine >= threshold, we won't be able to run any jobs
# Else, number of jobs we can run in machine = threshold - jobs_in_a_machine 
# 3 = Verbose: Print names of all the jobs running in each machine if this is set to 1 (useful to see running jobs)
# Note: the ideal number of jobs per machine is 4

available_machines=("rain10" "rain11" "rain12" "rain13" "rain14" "rain15")

jobs_to_run=$1 #How many jobs we want to distribute across machine
threshold_per_machine=$2 #threshold per machine
verbose=$3 #If we should print output or not

#Get current machine
hostname=$(hostname)
IFS='.' read -ra hostname_arr <<< "$hostname" #split hostname
current_machine="${hostname_arr[0]}"
#echo $current_machine

#Declare Tallies
available_space=0
total_number_of_jobs_running=0

for str in ${available_machines[@]}; do
  if [[ "$str" != "$current_machine" ]]; then #ssh if string doesn't equal to current machine
    num_jobs=$(ssh assured_ai@$str 'tmux ls | wc -l') #get number of jobs
    tmux_list_command=$( ssh assured_ai@$str tmux ls | awk '{printf"%s___%s-%s-%s-%s ",$1,$6,$7,$8,$9}')    
  else
    num_jobs=$(tmux ls | wc -l) #get number of jobs
    tmux_list_command=$(tmux ls | awk '{printf"%s___%s-%s-%s-%s ",$1,$6,$7,$8,$9}') #NOTE: THIS WORKS!
  fi
  diff=$((threshold_per_machine-num_jobs))
  num_can_run=$(( 0 > $diff ? 0 : $diff ))
  available_space=$(($available_space + $num_can_run))
  total_number_of_jobs_running=$(($total_number_of_jobs_running + $num_jobs))

  #output if verbose set to true
  if [ "$verbose" == true ];
  then
    echo "----- ${str} -----"
    echo "Current number of jobs running: ${num_jobs}"
    echo "Space available on machine: ${num_can_run}"
    
    #Echo jobs running on machine
    IFS=') ' read -r -a tmux_arr <<< "${tmux_list_command}"
    #echo $tmux_list_command
    echo " "
    echo "current jobs running on machine "
    for item in "${tmux_arr[@]}"; do
      echo "$item"  
    done
    echo "---------------"
    echo ""
  fi
done

#Output result if verbose command line arg set to true
if [ "$verbose" == true ];
then
  echo "Total number of jobs running Across Rain10-15: ${total_number_of_jobs_running}" 
  echo "Available space for jobs to run: ${available_space}"
fi


if [ "$jobs_to_run" -le  "$available_space" ]; then
    echo true
else
    echo false 
fi