#!/bin/bash

# Script that helps easily clear tmux jobs that we no longer need
# Reads in a list of running jobs from a file seperated by lines (note, jobs must be spelled correctly)
# Searches all 6 rain servers and deletes the tmux sessions if they exists

DELETE_FILE_PATH=$1 #Path to txt file that contains info
jobs_to_del=()


#function for checking if array contains elem
arrayContainsElement () {
  local elem match_elem="$1"
  shift
  for elem; do [[ "$match_elem" == "$elem" ]] && return 0; done
  return 1
}


#Read file into Array
while IFS= read -r line
do
  jobs_to_del+=("${line}")
done < "$DELETE_FILE_PATH"

#for str in ${jobs_to_del[@]}; do
#  echo ${str}
#done

#Get current machine
hostname=$(hostname)
IFS='.' read -ra hostname_arr <<< "$hostname" #split hostname
current_machine="${hostname_arr[0]}"
#echo $current_machine


available_machines=("rain10" "rain11" "rain12" "rain13" "rain14" "rain15")
for str in ${available_machines[@]}; do
  if [[ "$str" != "$current_machine" ]]; then #ssh if string doesn't equal to current machine
    tmux_list_command=$( ssh assured_ai@$str tmux ls | awk '{printf"%s",$1}')    
  else
    tmux_list_command=$(tmux ls | awk '{printf"%s",$1}') #NOTE: THIS WORKS!
  fi

  #Echo jobs running on machine
  IFS=':' read -r -a tmux_arr <<< "${tmux_list_command}"
  #echo $tmux_list_command
  echo "$str"
  echo "current jobs running on machine "
  for item in "${tmux_arr[@]}"; do
    #echo "$item"
    arrayContainsElement "$item" "${jobs_to_del[@]}"
    if [ $?  == 0 ]; then #if match, delete job
      
      if [[ "$str" != "$current_machine" ]]; then #ssh if string doesn't equal to current machine
        eval "ssh assured_ai@$str 'tmux kill-session -t ${item}'"    
      else
        eval "tmux kill-session -t ${item}"
      fi
      
      echo "deleted ${item}" 
    fi 
  done
  echo "---------------"
  echo ""
done
