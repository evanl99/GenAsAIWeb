import matplotlib.pyplot as plt
import matplotlib.axes as axes
import re
import argparse
import os
import logging
import matplotlib.ticker as ticker


class Parsing_Regex:
    def __init__(self):
        self.steps = re.compile('after\s*(\d*)\s*steps', flags=re.IGNORECASE)
        self.avg_wait_arr = re.compile('average waiting time \(s\) of arrived vehicles is:\s*(\d*\.\d*)', flags=re.IGNORECASE)
        self.avg_wait_rem = re.compile('average waiting time \(s\) of remaining vehicles is:\s*(\d*\.\d*)', flags=re.IGNORECASE)
        self.avg_wait_all = re.compile('average waiting time \(s\) of all vehicles is:\s*(\d*\.\d*)', flags=re.IGNORECASE)
        self.avg_speed_all = re.compile('average speed \(m/s\) of all vehicles is\s*(\d*\.\d*)', flags=re.IGNORECASE)
        self.max_queue = re.compile('maximum queue size is \s*(\d*)', flags=re.IGNORECASE)
        self.rem_queue = re.compile('number of remaining vehicles in the queue\s*(\d*)', flags=re.IGNORECASE)
        self.rem_network = re.compile('number of remaining vehicles in the network\s*(\d*)', flags=re.IGNORECASE)
        self.inflow = re.compile('inflow is\s*(\d*)', flags=re.IGNORECASE)
        self.outflow = re.compile('outflow is\s*(\d*)', flags=re.IGNORECASE)

    def _get_helper(self, input_arr):
        try:
            if len(input_arr) > 0:
                return float(input_arr[0])
        except Exception as e:
            print(e)
            return None
    
    def get_steps(self, input):
        temp = self._get_helper(self.steps.findall(input))
        if temp is not None:
            return int(temp)
        return temp
    
    def get_avg_wait_arr(self, input):
        return self._get_helper(self.avg_wait_arr.findall(input))

    def get_avg_wait_rem(self, input):
        return self._get_helper(self.avg_wait_rem.findall(input))

    def get_avg_wait_all(self, input):
        return self._get_helper(self.avg_wait_all.findall(input))

    def get_avg_speed_all(self, input):
        return self._get_helper(self.avg_speed_all.findall(input))

    def get_max_queue(self, input):
        return self._get_helper(self.max_queue.findall(input))

    def get_rem_queue(self, input):
        return self._get_helper(self.rem_queue.findall(input))

    def get_rem_network(self, input):
        return self._get_helper(self.rem_network.findall(input))

    def get_inflow(self, input):
        return self._get_helper(self.inflow.findall(input))

    def get_outflow(self, input):
        return self._get_helper(self.outflow.findall(input))


def parse_file(parse_file):
    regex = Parsing_Regex()
    
    line_number = -1

    steps, avg_wait_arr, avg_wait_rem, avg_wait_all, avg_speed_all, max_queue, rem_queue, rem_network, inflow, outflow = None, None, None, None, None, None, None, None, None, None

    #iteration, avg_speed, avg_overall, avg_last_50, avg_last_10 = None, None, None, None, None
    print(parse_file)

    with open(parse_file, "r") as fp:
        line = fp.readline()
        
        while line:
            if line_number == -1 and line.startswith('saving'):
                line_number = 0
            elif line_number == 0:
                steps = regex.get_steps(line)
                line_number += 1
            elif line_number == 1:
                avg_wait_arr = regex.get_avg_wait_arr(line)
                line_number += 1
            elif line_number == 2:
                avg_wait_rem = regex.get_avg_wait_rem(line)
                line_number += 1
            elif line_number == 3:
                avg_wait_all = regex.get_avg_wait_all(line)
                line_number += 1
            elif line_number == 4:
                avg_speed_all = regex.get_avg_speed_all(line)
                line_number += 1
            elif line_number == 5:
                max_queue = regex.get_max_queue(line)
                line_number += 1
            elif line_number == 6:
                rem_queue = regex.get_rem_queue(line)
                line_number += 1
            elif line_number == 7:
                rem_network = regex.get_rem_network(line)
                line_number += 1
            elif line_number == 8:
                inflow = regex.get_inflow(line)
                line_number += 1
            elif line_number == 9:
                outflow = regex.get_outflow(line)
                line_number += 1
            elif line_number > 9:
                line_number = -1
                yield steps, avg_wait_arr, avg_wait_rem, avg_wait_all, avg_speed_all, max_queue, rem_queue, rem_network, inflow, outflow
                steps, avg_wait_arr, avg_wait_rem, avg_wait_all, avg_speed_all, max_queue, rem_queue, rem_network, inflow, outflow = None, None, None, None, None, None, None, None, None, None
                
                
            line = fp.readline()
                



def make_graph(filename, best, all):
    
    steps, avg_wait_arr, avg_wait_rem, avg_wait_all, avg_speed_all, max_queue, rem_queue, rem_network, inflow, outflow = [], [], [], [], [], [], [], [], [], []
    #iters, avg_speeds, overall_speeds, avg_last_50s, avg_last_10s = [], [], [], [], []
    for step, awa, awr, awl, asl, mq, rq, rn, inf, outf in parse_file(filename):
        #TODO: figure out way to plot graph without using so much memory
        steps.append(step)
        avg_wait_arr.append(awa)
        avg_wait_rem.append(awr)
        avg_wait_all.append(awl)
        avg_speed_all.append(asl)
        max_queue.append(mq)
        rem_queue.append(rq)
        rem_network.append(rn)
        inflow.append(inf)
        outflow.append(outf)
    
    print(len(steps), len(avg_wait_arr), len(avg_wait_rem), len(avg_wait_all),
        len(avg_speed_all), len(max_queue), len(rem_queue), len(rem_network), len(inflow), len(outflow))

    # plot line charts
    file_name = filename.split('/')[-1]
    file_name = file_name.split('.txt')[0]

    plt.plot(steps, avg_wait_arr, label="arrived")
    plt.plot(steps, avg_wait_rem, label="remaining")
    plt.plot(steps, avg_wait_all, label="all")
    plt.ylabel("Waiting Time")
    plt.title("Average waiting times at each iteration")
    plt.savefig('./results/plots/%s_wait.png' % file_name)
    plt.clf()


    if best > 0 and all > 0:
        for sp in range(len(avg_speed_all)):
            avg_speed_all[sp] = avg_speed_all[sp] * best / all
    plt.plot(steps, avg_speed_all, label="avg_speed")
    plt.ylabel("Speed")
    plt.title("Training speeds at each iteration")
    if best > 0 and all > 0:
        plt.savefig('./results/plots/%s_speed.png' % (file_name + '_pertinent'))
    #plt.show()'''


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description='''Reads in a file and plots the following over the course of training:
                    avg_wait_arr, avg_wait_rem, avg_wait_all, avg_speed_all''')
    parser.add_argument('-f', '--filename',
                        help="the output file to parse and graph", required=True, type=str)
    parser.add_argument('-b', '--best', help="the pertinent speed", required=False, type=float, default=0)
    parser.add_argument('-a', '--all', help="the overall avg speed", required=False, type=float, default=0)
    args = parser.parse_args()
    make_graph(args.filename, args.best, args.all)