import numpy as np
from .ppo2 import PPO2
from stable_baselines.common.vec_env import DummyVecEnv
from flow.utils.registry import env_constructor
from flow.core.params import VehicleParams
from flow.controllers import SimCarFollowingController
from flow.core import rewards
from flow.core.params import InFlows
from flow.controllers.lane_change_controllers import SimLaneChangeController
from flow.core.params import SumoParams, EnvParams, InitialConfig, NetParams, \
    InFlows, SumoCarFollowingParams, SumoLaneChangeParams
from flow.core.params import TrafficLightParams
from flow.core.params import NetParams
from .grid_env import TrafficLightGridPOEnv
from .grid_env_safe_controller import TrafficLightGridSafeControllerEnv
from .grid_network import TrafficLightGridNetwork
from pickle import dump, load
from tabulate import tabulate
import numpy as np
import random
import tensorflow as tf
from datetime import datetime
import multiprocessing
import sys

# configurable parameters
VEHICLE_RATE = 500 # number of vehicles per hour
VERBOSE = 2

def gen_edges(col_num, row_num):
    """Generate the names of the outer edges in the grid network.
    Parameters
    ----------
    col_num : int
        number of columns in the grid
    row_num : int
        number of rows in the grid
    Returns
    -------
    list of str
        names of all the outer edges
    """
    edges = []

    # build the left and then the right edges
    for i in range(col_num):
        edges += ['left' + str(row_num) + '_' + str(i)]
        edges += ['right' + '0' + '_' + str(i)]

    # build the bottom and then top edges
    for i in range(row_num):
        edges += ['bot' + str(i) + '_' + '0']
        edges += ['top' + str(i) + '_' + str(col_num)]

    return edges


def get_outside_edges(rows, cols):
    edges = []
    for i in range(rows):
        edges.append("bot{}_0".format(i))
        edges.append("top{}_{}".format(i, cols))
    for j in range(cols):
        edges.append("left{}_{}".format(rows, j))
        edges.append("right0_{}".format(j))
    return edges


def evaluate_model(model, eval_env, horizon, steps=None):
    obs = eval_env.reset()
    reward = 0
    # total accumulated waiting time of all arrived vehicles
    total = 0
    # total number of arrived vehicles
    count = 0
    # a dictionary that stores accumulated waiting time for vehicles
    times = {}
    # an array of average velocities for each time step
    speed = []
    # total accumulated waiting time of vehicles in the last time step
    prev_total = 0
    # number of arrived vehicles in the last time step
    prev_count = 0
    # stores vehicles in the queue. 
    queued_vehs = []
    # maximum length of the queue
    max_queue_size = 0
    # number of vehicles which departed 
    inflow = 0

    for i in range(horizon):
        action, _states = model.predict(obs)
        obs, rs, dones, info = eval_env.step(action)
        reward += rs
        # all vehicles currently in the network
        cur_vehs = np.array(eval_env.envs[0].k.vehicle.get_ids())
        # loaded vehicles (including ones in the queue)
        loaded_vehs = eval_env.envs[0].k.kernel_api.simulation.getLoadedIDList()
        # vehicles added to the system
        departed_vehs = eval_env.envs[0].k.kernel_api.simulation.getDepartedIDList()
        # update inflow 
        inflow += len(departed_vehs)
        # IDs of vehicles that are currently in the queue
        cur_queued_vehs = list(set(loaded_vehs)- set(departed_vehs))
        # IDs of vehicles that leave the queue (therefore enter the network)
        poped_vehs = list(set(departed_vehs) - set(loaded_vehs))
        # current queue size
        cur_queue_size = len(cur_queued_vehs)
        if cur_queue_size != 0:
            # update maximum queue size  
            if cur_queue_size > max_queue_size:
                max_queue_size = cur_queue_size
            # add currently queued vehicles
            queued_vehs.extend(cur_queued_vehs)
        
        # remove vehicles that left the queue from the queue
        if len(poped_vehs) != 0: 
            queued_vehs = list(set(queued_vehs) - set(poped_vehs))

        # calculate average speed at this timestep 
        vel = np.append(np.array(eval_env.envs[0].k.vehicle.get_speed(cur_vehs)), np.zeros(len(queued_vehs)))
        if not (any(vel < -100) or len(vel) == 0):
            speed.append(np.mean(vel))
        # reset prev total and prev count
        if len(cur_vehs) != 0:
            prev_total = 0
            prev_count = 0
        for veh_id in cur_vehs:
            times[veh_id] = eval_env.envs[0].k.kernel_api.vehicle.getAccumulatedWaitingTime(veh_id)
            # get all remaining cars in the system
            prev_total += times[veh_id]
            prev_count += 1

        # update total accumulated waiting time of all arrived vehicles and update number of arrived vehicles
        try:
            for veh_id in eval_env.envs[0].k.vehicle.get_arrived_ids():
                total += times[veh_id]
                count += 1
        except TypeError:
            pass

    arrived_waiting_time = total / count
    remaining_waiting_time = prev_total / prev_count
    all_waiting_time = (total + prev_total) / (prev_count + count)
    average_speed = np.mean(speed)
    remaining_queue_size = len(queued_vehs)

    if steps == None: 
        print("model evaluation:")
    else: 
        print("after ", steps, " steps") 
    print("average waiting time (s) of arrived vehicles is: ", arrived_waiting_time)
    print("average waiting time (s) of remaining vehicles is: ", remaining_waiting_time)
    print("average waiting time (s) of all vehicles is:", all_waiting_time)
    print("average speed (m/s) of all vehicles is ", average_speed)
    print("maximum queue size is ", max_queue_size)
    print("number of remaining vehicles in the queue ", remaining_queue_size)
    print("number of remaining vehicles in the network ", prev_count)
    print("inflow is ", inflow)
    print("outflow is ", count)
    return arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, prev_count, inflow, count


def train(flow_params, starting_step, model_file, lr):

    constructor = env_constructor(params=flow_params, version=0)()
    env = DummyVecEnv([lambda: constructor])

    # set a seed based on system time
    # random.seed(datetime.now())
    # three random seeds 
    # PPO2_model_seed = random.randrange(10000)
    # rand_seed = random.randrange(10000)
    # np_rand_seed= random.randrange(10000)
    # tf_rand_seed = random.randrange(10000)
    # print("python random seed is ", rand_seed)
    # print("np random seed is ", np_rand_seed)
    # print("tf random seed is ", tf_rand_seed)

    steps = 0 # start with a new model

    STEPS_PER_TRAIN = flow_params['env'].horizon * 10
    # rollout_size should be multiple of 4
    # ROLLOUT_SIZE = 4 * flow_params['net'].additional_params["grid_array"]["row_num"] * flow_params['net'].additional_params["grid_array"]["col_num"] 
    ROLLOUT_SIZE = 24

    # load an existing model 
    if starting_step != 0: 
        train_model = PPO2.load(model_file, env=env)
        print("loading: "+model_file)
        steps = starting_step
        print("loaded learning rate: ", train_model.learning_rate(1))
        train_model.learning_rate = lr
        print("change learning rate to: ", lr)
    else:
        # setup training model
        train_model = PPO2('MlpPolicy', env, verbose=VERBOSE, n_steps=ROLLOUT_SIZE, learning_rate=lr)
        print("learning rate: ", lr)

    # set python random, np random, and tensorflow seeds
    # random.seed(rand_seed)
    # np.random.seed(np_rand_seed)
    # tf.set_random_seed(tf_rand_seed)
    
    while steps < starting_step + 1000000:
        print("steps per training is ", STEPS_PER_TRAIN)
        train_model.learn(total_timesteps=STEPS_PER_TRAIN)
        print("current learning rate: ", train_model.learning_rate(1))

        steps += STEPS_PER_TRAIN

        # save model after each iteration
        fname = "rl_model" + str(steps)
        train_model.save(fname)
        # # save random state 
        # pickle_fname = fname + ".pickle"
        # rand_state_objects = (random.getstate(), np.random.get_state())
        # rand_state_file = open(pickle_fname, "wb")
        # dump(rand_state_objects, rand_state_file)
        # rand_state_file.close()

        print("saving" + fname)

        env_ = env_constructor(params=flow_params, version=0)()
        # The algorithms require a vectorized environment to run
        eval_env = DummyVecEnv([lambda: env_])

        # evaluate the model and print out average delay, speed
        evaluate_model(train_model, eval_env, flow_params['env'].horizon, steps)

        env = DummyVecEnv([lambda: constructor])
        train_model = PPO2.load(fname, env=env)
    
# multiprocess worker function
def mp_run(input_arr):
    py_seed, np_seed, tf_seed, flow_params, model_file = input_arr
      # create environment
    env = env_constructor(params=flow_params, version=0)()
    eval_env = DummyVecEnv([lambda: env])

    ROLLOUT_SIZE = 4 * flow_params['net'].additional_params["grid_array"]["row_num"] * flow_params['net'].additional_params["grid_array"]["col_num"]
     # load model from file
    eval_model = PPO2.load(model_file, env=eval_env, n_steps=ROLLOUT_SIZE)
    print("python random seed is ", py_seed)
    print("np random seed is ", np_seed)
    print("tf random seed is ", tf_seed)
    # set python random, np random, and tensorflow seeds
    random.seed(py_seed)
    np.random.seed(np_seed)
    tf.set_random_seed(tf_seed)
    # evaluate the model and print out average waiting times and average speed
    arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow = evaluate_model(eval_model, eval_env, flow_params['env'].horizon)
    return [arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow]
    
def run(flow_params, starting_step, model_file, num_runs):
    
    print("starting evaluation of the model for ", num_runs, " runs")

    if num_runs == 1:
        # setup env 
        env = env_constructor(params=flow_params, version=0)()
        eval_env = DummyVecEnv([lambda: env])
        
        ROLLOUT_SIZE = 4 * flow_params['net'].additional_params["grid_array"]["row_num"] * flow_params['net'].additional_params["grid_array"]["col_num"]

        # load random states 
        # pickle_fname = "rl_model" + str(starting_step) + ".pickle"
        # rand_state_objects = tuple()
        # rand_state_file = open(pickle_fname, "rb")
        # rand_state_objects = load(rand_state_file)
        # rand_state_file.close()

        # load the model for evaluation 
        eval_model = PPO2.load(model_file, env=eval_env, n_steps=ROLLOUT_SIZE)

        # np.random.seed(5051)
        # random.seed(6169)
        # random.setstate(rand_state_objects[0])
        # np.random.set_state(rand_state_objects[1])

        # set a seed based on system time
        random.seed(datetime.now())
        py_seed = random.randrange(10000)
        np_seed = random.randrange(10000)
        tf_seed = random.randrange(10000)
        # print("python random seed is ", py_seed)
        # print("np random seed is ", np_seed)
        # print("tf random seed is ", tf_seed)
        # set python random, np random, and tensorflow seeds
        random.seed(6057)
        np.random.seed(7574)
        tf.set_random_seed(3542)
        HORIZON = flow_params['env'].horizon * flow_params['net'].additional_params["grid_array"]["row_num"] * flow_params['net'].additional_params["grid_array"]["col_num"]
        evaluate_model(eval_model, eval_env, HORIZON, starting_step)
    
    else: 
        arrived_waiting_time_arr = [] 
        remaining_waiting_time_arr = [] 
        all_waiting_time_arr = [] 
        average_speed_arr = []
        max_queue_size_arr = []
        remaining_queue_size_arr = []
        remaining_num_vehs_arr = [] 
        inflow_arr = []
        outflow_arr = []

        # set a seed based on system time
        random.seed(datetime.now())

        mp_input_arr = []
        for i in range(num_runs): 
            mp_input = [random.randrange(10000), random.randrange(10000), random.randrange(10000), flow_params, model_file]
            mp_input_arr.append(mp_input)

        p = multiprocessing.Pool()
        mp_output_arr = p.map(mp_run, mp_input_arr)
        print("mp output array is ", mp_output_arr)

        for arr in mp_output_arr: 
            arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow = arr
            arrived_waiting_time_arr.append(arrived_waiting_time)
            remaining_waiting_time_arr.append(remaining_waiting_time)
            all_waiting_time_arr.append(all_waiting_time)
            average_speed_arr.append(average_speed)
            max_queue_size_arr.append(max_queue_size)
            remaining_queue_size_arr.append(remaining_queue_size)
            remaining_num_vehs_arr.append(remaining_num_vehs)
            inflow_arr.append(inflow)
            outflow_arr.append(outflow)
            
        # print stats
        print(tabulate([["5th percentile", np.percentile(arrived_waiting_time_arr, 5), np.percentile(remaining_waiting_time_arr, 5), np.percentile(all_waiting_time_arr, 5), np.percentile(average_speed_arr, 5), np.percentile(max_queue_size_arr, 5), np.percentile(remaining_queue_size_arr, 5), np.percentile(remaining_num_vehs_arr, 5), np.percentile(inflow_arr, 5), np.percentile(outflow_arr, 5)],
            ["10th percentile", np.percentile(arrived_waiting_time_arr, 10), np.percentile(remaining_waiting_time_arr, 10), np.percentile(all_waiting_time_arr, 10), np.percentile(average_speed_arr, 10), np.percentile(max_queue_size_arr, 10), np.percentile(remaining_queue_size_arr, 10), np.percentile(remaining_num_vehs_arr, 10), np.percentile(inflow_arr, 10), np.percentile(outflow_arr, 10)],
            ["30th percentile", np.percentile(arrived_waiting_time_arr, 30), np.percentile(remaining_waiting_time_arr, 30), np.percentile(all_waiting_time_arr, 30), np.percentile(average_speed_arr, 30), np.percentile(max_queue_size_arr, 30), np.percentile(remaining_queue_size_arr, 30), np.percentile(remaining_num_vehs_arr, 30), np.percentile(inflow_arr, 30), np.percentile(outflow_arr, 30)],
            ["50th percentile", np.percentile(arrived_waiting_time_arr, 50), np.percentile(remaining_waiting_time_arr, 50), np.percentile(all_waiting_time_arr, 50), np.percentile(average_speed_arr, 50), np.percentile(max_queue_size_arr, 50), np.percentile(remaining_queue_size_arr, 50), np.percentile(remaining_num_vehs_arr, 50), np.percentile(inflow_arr, 50), np.percentile(outflow_arr, 50)], 
            ["70th percentile", np.percentile(arrived_waiting_time_arr, 70), np.percentile(remaining_waiting_time_arr, 70), np.percentile(all_waiting_time_arr, 70), np.percentile(average_speed_arr, 70), np.percentile(max_queue_size_arr, 70), np.percentile(remaining_queue_size_arr, 70), np.percentile(remaining_num_vehs_arr, 70), np.percentile(inflow_arr, 70), np.percentile(outflow_arr, 70)], 
            ["90th percentile", np.percentile(arrived_waiting_time_arr, 90), np.percentile(remaining_waiting_time_arr, 90), np.percentile(all_waiting_time_arr, 90), np.percentile(average_speed_arr, 90), np.percentile(max_queue_size_arr, 90), np.percentile(remaining_queue_size_arr, 90), np.percentile(remaining_num_vehs_arr, 90), np.percentile(inflow_arr, 90), np.percentile(outflow_arr, 90)],
            ["95th percentile", np.percentile(arrived_waiting_time_arr, 95), np.percentile(remaining_waiting_time_arr, 95), np.percentile(all_waiting_time_arr, 95), np.percentile(average_speed_arr, 95), np.percentile(max_queue_size_arr, 95), np.percentile(remaining_queue_size_arr, 95), np.percentile(remaining_num_vehs_arr, 95), np.percentile(inflow_arr, 95), np.percentile(outflow_arr, 95)], 
            ["maximum", np.amax(arrived_waiting_time_arr), np.amax(remaining_waiting_time_arr), np.amax(all_waiting_time_arr), np.amax(average_speed_arr), np.amax(max_queue_size_arr), np.amax(remaining_queue_size_arr), np.amax(remaining_num_vehs_arr), np.amax(inflow_arr), np.amax(outflow_arr)], 
            ["minimum", np.amin(arrived_waiting_time_arr), np.amin(remaining_waiting_time_arr), np.amin(all_waiting_time_arr), np.amin(average_speed_arr), np.amin(max_queue_size_arr), np.amin(remaining_queue_size_arr), np.amin(remaining_num_vehs_arr), np.amin(inflow_arr), np.amin(outflow_arr)],
            ["standard deviation", np.std(arrived_waiting_time_arr), np.std(remaining_waiting_time_arr), np.std(all_waiting_time_arr), np.std(average_speed_arr), np.std(max_queue_size_arr), np.std(remaining_queue_size_arr), np.std(remaining_num_vehs_arr), np.std(inflow_arr), np.std(outflow_arr)]], 
            headers=["", "Arrived Waiting Time (s)", "Remaining Waiting Time (s)", "All Waiting Time (s)", "Average Speed (m/s)", "Maximum Queue Size", "Remaining Queue Size", "Number of Remaining Vehicles", "Inflow", "Outflow"],
            tablefmt='orgtbl'))

def setup_flow(num_vehs_per_hour, scenario, durations, num_observed, route, rows, cols, static=False, render=False):

    # grid parameters
    inner_length = 100
    long_length = 100
    short_length = 100
    n = rows  # rows
    m = cols  # columns
    num_cars_left = 20
    num_cars_right = 20
    num_cars_top = 20
    num_cars_bot = 20
    # tot_cars = (num_cars_left + num_cars_right) * m + (num_cars_top + num_cars_bot) * n

    grid_array = {"short_length": short_length, "inner_length": inner_length,
                  "long_length": long_length, "row_num": n, "col_num": m,
                  "cars_left": num_cars_left, "cars_right": num_cars_right,
                  "cars_top": num_cars_top, "cars_bot": num_cars_bot}


    """
    Traffic light phases
    SUMO traffic lights documentation: https://sumo.dlr.de/docs/Simulation/Traffic_Lights.html#Signal_state_definitions
     
    S: straight lane, L: left-turning lane, R: right-turning lane
    
    * One lane no turning (S): 
    - static phases for safe controllers
    phases = [{"duration": "31", "state": "GGGrrrGGGrrr"},
              {"duration": "6", "state": "yyyrrryyyrrr"},
              {"duration": "31", "state": "rrrGGGrrrGGG"},
              {"duration": "6", "state": "rrryyyrrryyy"}]
    - phases required for safe controllers and RL systems        
    phases1lane = ['GGGrrrGGGrrr','yyyrrryyyrrr','rrrGGGrrrGGG','rrryyyrrryyy']

    * Two lanes with turning (L | S/R)
    - static phases for safe controllers
    durations2lanes_left_turning = [{"duration": "18", "state": "GGrrrrGGrrrr"},
                   {"duration": "3", "state": "yyrrrryyrrrr"},
                   {"duration": "5", "state": "rrGrrrrrGrrr"},
                   {"duration": "3", "state": "rryrrrrryrrr"},
                   {"duration": "18", "state": "rrrGGrrrrGGr"},
                   {"duration": "3", "state": "rrryyrrrryyr"},
                   {"duration": "5", "state": "rrrrrGrrrrrG"},
                   {"duration": "3", "state": "rrrrryrrrrry"}]
    - phases required for safe controllers and RL systems     
    phases2lanes = ["GGrrrrGGrrrr", "yyrrrryyrrrr", "rrGrrrrrGrrr", "rryrrrrryrrr", "rrrGGrrrrGGr", "rrryyrrrryyr", "rrrrrGrrrrrG", "rrrrryrrrrry"]

    * Three lanes with turning (L | S | R)
    - static phases for safe controllers
    durations3lanes = [{"duration": "12", "state": "GGGrrrrrGGGrrrrr"},
                   {"duration": "3", "state": "yyyrrrrryyyrrrrr"},
                   {"duration": "5", "state": "rrrGrrrrrrrGrrrr"},
                   {"duration": "3", "state": "rrryrrrrrrryrrrr"},
                   {"duration": "12", "state": "rrrrGGGrrrrrGGGr"},
                   {"duration": "3", "state": "rrrryyyrrrrryyyr"},
                   {"duration": "5", "state": "rrrrrrrGrrrrrrrG"},
                   {"duration": "3", "state": "rrrrrrryrrrrrrry"}]
    - phases required for safe controllers and RL systems     
    phases3lanes = ["GGGrrrrrGGGrrrrr", "yyyrrrrryyyrrrrr", "rrrGrrrrrrrGrrrr", "rrryrrrrrrryrrrr", "rrrrGGGrrrrrGGGr", "rrrryyyrrrrryyyr", "rrrrrrrGrrrrrrrG", "rrrrrrryrrrrrrry"]
    """
    phases2lanes = ["GGrrrrGGrrrr", "yyrrrryyrrrr", "rrGrrrrrGrrr", "rryrrrrryrrr", "rrrGGrrrrGGr", "rrryyrrrryyr", "rrrrrGrrrrrG", "rrrrryrrrrry"]
    nodes = ["center0", "center1", "center2", "center3"]
    yellow_time = str(durations["yellow"])
    straight_time = str(durations["straight"])
    left_time = str(durations["left"])

    durations2lanes_left_turning = [{"duration": straight_time, "state": "GGrrrrGGrrrr"},
                   {"duration": yellow_time, "state": "yyrrrryyrrrr"},
                   {"duration": left_time, "state": "rrGrrrrrGrrr"},
                   {"duration": yellow_time, "state": "rryrrrrryrrr"},
                   {"duration": straight_time, "state": "rrrGGrrrrGGr"},
                   {"duration": yellow_time, "state": "rrryyrrrryyr"},
                   {"duration": left_time, "state": "rrrrrGrrrrrG"},
                   {"duration": yellow_time, "state": "rrrrryrrrrry"}]
    # traffic light logic
    tl_logic = TrafficLightParams(baseline=False)
    # initialize nodes (intersections)
    for node_id in nodes:
        tl_logic.add(node_id, tls_type="static", programID="1", offset=None, phases=durations2lanes_left_turning)
    # vehicle parameters
    vehicles = VehicleParams()
    vehicles.add("human",
                 acceleration_controller=(SimCarFollowingController, {}),
                 lane_change_controller=(SimLaneChangeController, {}),
                 lane_change_params=SumoLaneChangeParams(lane_change_mode='strategic'),
                 car_following_params=SumoCarFollowingParams(
                     speed_mode="right_of_way",
                     impatience="off",
                     decel=7.5,
                    #  accel=4.0,
                     min_gap=2.5))

    initial_config = InitialConfig(spacing='custom')

    # introducing vehicles to the network 
    inflows = InFlows()
    p = .15
    if scenario is None: 
        for edge in get_outside_edges(n, m):
            inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=num_vehs_per_hour,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
    elif scenario == 1: 
        for edge in get_outside_edges(n, m):
            if edge == "top1_2":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=752,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=464,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
    elif scenario == 2: 
        for edge in get_outside_edges(n, m):
            if edge == "top1_2":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=150,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=550,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
    elif scenario == 3: 
        for edge in get_outside_edges(n, m):
            if edge == "top1_2" or edge == "left2_1":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=650,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=450,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
    elif scenario == 4: 
        for edge in get_outside_edges(n, m):
            if edge == "top1_2":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=700,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=100,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")  
    elif scenario == 5:
        for edge in get_outside_edges(n, m):
            if edge == "top1_2":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=750,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=500,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")  
    elif scenario == 6:
        for edge in get_outside_edges(n, m):
            if edge == "top1_2":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=500,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=100,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")  
    elif scenario == 7: 
        for edge in get_outside_edges(n, m):
            inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=100,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
    else: 
        print("scenario ", scenario, " not implemented")
        exit(1)

    # additional parameters
    ADDITIONAL_NET_PARAMS = {"grid_array": grid_array, "speed_limit": 35,
                             "horizontal_lanes": 2, "vertical_lanes": 2,
                             "traffic_lights": True, "route": route}
    ADDITIONAL_ENV_PARAMS = {"discrete": True, "num_observed": num_observed, 'switch_time': 3,'switch_time_rg' : 3,
                             'tl_type': 'actuated', 'target_velocity': 50, 'phase': phases2lanes}
    
    # network, environment, and simulation parameters
    net_params = NetParams(inflows=inflows, additional_params=ADDITIONAL_NET_PARAMS)
    env_params = EnvParams(additional_params=ADDITIONAL_ENV_PARAMS)
    sim_params = SumoParams(sim_step=.1, render=render, restart_instance=True)

    # flow parameters
    if static:
        flow_params = dict(
            exp_tag='RL_lights',
            env_name=TrafficLightGridSafeControllerEnv,
            network=TrafficLightGridNetwork,
            simulator='traci',
            sim=sim_params,
            env=env_params,
            net=net_params,
            veh=vehicles,
            initial=initial_config,
            tls=tl_logic
        )
    else: 
        flow_params = dict(
            exp_tag='RL_lights',
            env_name=TrafficLightGridPOEnv,
            network=TrafficLightGridNetwork,
            simulator='traci',
            sim=sim_params,
            env=env_params,
            net=net_params,
            veh=vehicles,
            initial=initial_config,
            # tls=tl_logic
        )
    # setting number of time steps per simulation/iteration
    # flow_params['env'].horizon = m * n * 3000
    flow_params['env'].horizon = 3000
    return flow_params
