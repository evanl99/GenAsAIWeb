'''
File to store helper funcs
'''

def get_outside_edges(rows, cols):
    edges = []
    for i in range(rows):
        edges.append("bot{}_0".format(i))
        edges.append("top{}_{}".format(i, cols))
    for j in range(cols):
        edges.append("left{}_{}".format(rows, j))
        edges.append("right0_{}".format(j))
    return edges


#TODO IF TIME: Refactor smell using polymorphism and add description
def handle_scenarios(scenario, inflows, n, m, num_vehs_per_hour):
    if scenario is None: 
        for edge in get_outside_edges(n, m):
            inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=num_vehs_per_hour,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
    elif scenario == 1: 
        for edge in get_outside_edges(n, m):
            if edge == "top1_2":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=752,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=464,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
    elif scenario == 2: 
        for edge in get_outside_edges(n, m):
            if edge == "top1_2":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=150,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=550,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
    elif scenario == 3: 
        for edge in get_outside_edges(n, m):
            if edge == "top1_2" or edge == "left2_1":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=650,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=450,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
    elif scenario == 4: 
        for edge in get_outside_edges(n, m):
            if edge == "top1_2":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=700,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=100,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")  
    elif scenario == 5:
        for edge in get_outside_edges(n, m):
            if edge == "top1_2":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=750,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=500,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")  
    elif scenario == 6:
        for edge in get_outside_edges(n, m):
            if edge == "top1_2":
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=500,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
            else:
                inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=100,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")  
    elif scenario == 7: 
        for edge in get_outside_edges(n, m):
            inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=100,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white")
    else: 
        print("scenario ", scenario, " not implemented")
        exit(1)



#ADDED FUNC
#TODO: Refactor to helper file
def get_edges_at_center_nodes(network, num_rows, num_cols, only_inflows=False):
    """
    Gets list of all incoming at outgoing edges at node
    FROM grid_network.py
    
    "On an horizontal edge, the id of the top road is "top{i}_{j}" and the
    id of the bottom road is "bot{i}_{j}", where i is the index of the row
    where the edge is and j is the index of the column to the right of it.

    On a vertical edge, the id of the right road is "right{i}_{j}" and the
    id of the left road is "left{i}_{j}", where i is the index of the row
    above the edge and j is the index of the column where the edge is."
    NOTE: I is likely index of row below the edge

    only_inflows: only append edges going in

    """
    #TODO: Refactor to helper file
    def get_center_node_positions(n, m):
        """
        Gets all non corner nodes in an n by m grid
        row and col are zero indexed
        n is number of rows
        m is number of cols
        Ex: in a 3 x 3. return [(1, 1)]
        returns list of tuples
        """
        if m < 3 or n < 3:
            return []
        res = []
        for i in range(1, n - 1):
            for j in range(1, m - 1):
                res.append((i, j))
        return res


    #full_edge_list = self.k.network.get_edge_list()
    center_nodes = get_center_node_positions(num_rows, num_cols)
    edges = []
    for node_pos in center_nodes:
        i, j = node_pos
        if only_inflows:
            edges += [
                ("bot%s_%s" % (i, j)),
                ("top%s_%s" % (i, j + 1)),
                ("left%s_%s" %(i + 1, j)),
                ("right%s_%s" %(i, j)),
            ]
        else:
            edges += [
                ("bot%s_%s" % (i, j)),
                ("bot%s_%s" % (i, j + 1)),
                ("top%s_%s" % (i, j)),
                ("top%s_%s" % (i, j + 1)),
                ("left%s_%s" % (i, j)),
                ("left%s_%s" %(i + 1, j)),
                ("right%s_%s" %(i, j)),
                ("right%s_%s" % (i + 1, j)),
            ]
    edges = list(set(edges)) #Get unique edges only
    
    #check that edge is valid
    edge_dict = {x: True for x in network.get_edge_list()}
    for edge in edges:
        if edge not in edge_dict:
            raise ValueError
    
    return edges