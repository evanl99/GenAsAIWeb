# configurable parameters
HORIZON = 3000 # number of training steps per iteration/simulation
ROLLOUT_SIZE = 3000 # rollout_size should be multiple of 4

#NOTE: Rollout size should equal horizon
STEPS_PER_TRAIN = 50000 
VERBOSE = 2