import os
import numpy as np
from stable_baselines import PPO2
from stable_baselines.common.vec_env import DummyVecEnv
from flow.utils.registry import env_constructor
from flow.core.params import VehicleParams
from flow.controllers import SimCarFollowingController
from flow.core import rewards
from flow.core.params import InFlows
from flow.controllers.lane_change_controllers import SimLaneChangeController
from flow.core.params import SumoParams, EnvParams, InitialConfig, NetParams, \
    InFlows, SumoCarFollowingParams, SumoLaneChangeParams
from flow.core.params import TrafficLightParams
from flow.core.params import NetParams
from modules.grid_env import TrafficLightGridPOEnv
from modules.safe_grid_env import TrafficLightGridSafeController
from modules.grid_network import TrafficLightGridNetwork
from utils.utils import get_outside_edges, get_edges_at_center_nodes, handle_scenarios
from pickle import dump, load
from tabulate import tabulate
import numpy as np
import random
import tensorflow as tf
from datetime import datetime
import multiprocessing
from utils.constants import HORIZON, ROLLOUT_SIZE, STEPS_PER_TRAIN, VERBOSE


def evaluate_model(model, eval_env, horizon, steps=None):
    #    
    obs = eval_env.reset()
    reward = 0
    # total accumulated waiting time of all arrived vehicles
    total = 0
    # total number of arrived vehicles
    count = 0
    # a dictionary that stores accumulated waiting time for vehicles
    times = {}
    # an array of average velocities for each time step
    speed = []
    # total accumulated waiting time of vehicles in the last time step
    prev_total = 0
    # number of arrived vehicles in the last time step
    prev_count = 0
    # stores vehicles in the queue. 
    queued_vehs = []
    # maximum length of the queue
    max_queue_size = 0
    # number of vehicles which departed 
    inflow = 0

    max_vel = 0


    center_ratio = 0
    unique_center_ratio, times_cars_appear = 0, 0
    for i in range(horizon):
        action, _states = model.predict(obs)
        #import pdb
        #pdb.set_trace()
        obs, rs, dones, info = eval_env.step(action)
        reward += rs
        # all vehicles currently in the network
        #cur_vehs = np.array(eval_env.envs[0].k.vehicle.get_ids())
        
        total_vehicles = np.array(eval_env.envs[0].k.vehicle.get_ids())
        #TODO: refactor magic numbers to actually take in row and col size
        cur_vehs = np.array(eval_env.envs[0].k.vehicle.get_ids_by_edge(get_edges_at_center_nodes(eval_env.envs[0].k.network, 3,3, only_inflows=True)))
        iter_center_ratio = (len(cur_vehs)  + 1e-10) /(len(total_vehicles) + 1e-10)
        center_ratio += iter_center_ratio
        
        if len(cur_vehs) > 0:
            unique_center_ratio += ((len(cur_vehs)  + 1e-10) /(len(total_vehicles) + 1e-10))
            times_cars_appear += 1

        eval_env.__class__ = DummyVecEnv
        # loaded vehicles (including ones in the queue)
        loaded_vehs = eval_env.envs[0].k.kernel_api.simulation.getLoadedIDList()
        # vehicles added to the system
        departed_vehs = eval_env.envs[0].k.kernel_api.simulation.getDepartedIDList()
        # update inflow 
        inflow += len(departed_vehs)
        # IDs of vehicles that are currently in the queue
        cur_queued_vehs = list(set(loaded_vehs)- set(departed_vehs))
        # IDs of vehicles that leave the queue (therefore enter the network)
        poped_vehs = list(set(departed_vehs) - set(loaded_vehs))
        # current queue size
        cur_queue_size = len(cur_queued_vehs)
        if cur_queue_size != 0:
            # update maximum queue size  
            if cur_queue_size > max_queue_size:
                max_queue_size = cur_queue_size
            # add currently queued vehicles
            queued_vehs.extend(cur_queued_vehs)
        
        # remove vehicles that left the queue from the queue
        if len(poped_vehs) != 0: 
            queued_vehs = list(set(queued_vehs) - set(poped_vehs))

        # calculate average speed at this timestep 
        vel = np.append(np.array(eval_env.envs[0].k.vehicle.get_speed(cur_vehs)), np.zeros(len(queued_vehs)))
        max_vel = max(np.mean(vel), max_vel)
        if not (any(vel < -100) or len(vel) == 0):
            speed.append(np.mean(vel))
        # reset prev total and prev count
        if len(cur_vehs) != 0:
            prev_total = 0
            prev_count = 0
        for veh_id in cur_vehs:
            times[veh_id] = eval_env.envs[0].k.kernel_api.vehicle.getAccumulatedWaitingTime(veh_id)
            # get all remaining cars in the system
            prev_total += times[veh_id]
            prev_count += 1

        # update total accumulated waiting time of all arrived vehicles and update number of arrived vehicles
        try:
            for veh_id in cur_vehs: #eval_env.envs[0].k.vehicle.get_arrived_ids(): TODO: Investigate
                total += times[veh_id]
                count += 1
        except TypeError:
            pass

    arrived_waiting_time = total / count
    remaining_waiting_time = prev_total / prev_count
    all_waiting_time = (total + prev_total) / (prev_count + count)
    average_speed = np.mean(speed)
    remaining_queue_size = len(queued_vehs)

    if steps == None: 
        print("model evaluation:")
    else: 
        print("after ", steps, " steps") 
    print("average waiting time (s) of arrived vehicles is: ", arrived_waiting_time)
    print("average waiting time (s) of remaining vehicles is: ", remaining_waiting_time)
    print("average waiting time (s) of all vehicles is:", all_waiting_time)
    print("average speed (m/s) of all vehicles is ", average_speed)
    print("maximum queue size is ", max_queue_size)
    print("number of remaining vehicles in the queue ", remaining_queue_size)
    print("number of remaining vehicles in the network ", prev_count)
    print("inflow is ", inflow)
    print("outflow is ", count)
    print("DEBUG: MAX Velocity is %s" % max_vel)

    ratio = center_ratio/horizon
    unique_ratio = (unique_center_ratio + 1e-10) / (times_cars_appear + 1e-10)
    print("DEBUG: Ratio of cars in middle vs total is %s" % ratio)
    print("DEBUG: Ratio of cars in middle vs total %s" % ratio)
    print("DEBUG: Ratio of cars in middle vs total WHEN MIDDLE CARS EXIST %s" % unique_ratio)
    return arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, prev_count, inflow, count

def train(flow_params, starting_step, model_file, lr, rand_seed_val, model_dir_path=None):
    constructor = env_constructor(params=flow_params, version=0)()
    env = DummyVecEnv([lambda: constructor])

    # set a seed based on system time
    if rand_seed_val:
        random.seed(rand_seed_val)
    else:
        random.seed(datetime.now())
    
    # three random seeds 
    PPO2_model_seed = random.randrange(rand_seed_val)
    rand_seed = random.randrange(rand_seed_val)
    np_rand_seed= random.randrange(rand_seed_val)
    tf_rand_seed = random.randrange(rand_seed_val)

    print("python random seed is ", rand_seed)
    print("np random seed is ", np_rand_seed)
    print("tf random seed is ", tf_rand_seed)
    
    # setup training model
    train_model = PPO2('MlpPolicy', env, verbose=VERBOSE, n_steps=ROLLOUT_SIZE, seed=PPO2_model_seed, learning_rate=5e-4)

    # set python random, np random, and tensorflow seeds
    random.seed(rand_seed)
    np.random.seed(np_rand_seed)
    tf.set_random_seed(tf_rand_seed)

    steps = 0 # start with a new model

    # load an existing model 
    if starting_step != 0: 
        train_model = PPO2.load(model_file, env=env)
        print("loading: "+ model_file)
        steps = starting_step
        print("loaded learning rate: ", train_model.learning_rate(1))
        train_model.learning_rate = lr
        print("change learning rate to: ", lr)
    
    while True:
        print("steps per training is ", STEPS_PER_TRAIN)
        train_model.learn(total_timesteps=STEPS_PER_TRAIN)
        steps += STEPS_PER_TRAIN

        # save model after each iteration
        if model_dir_path:
            if not os.path.exists(model_dir_path):
                os.makedirs(model_dir_path)
            fname = model_dir_path + "/rl_model" + str(steps)
        else:
            fname = "rl_model" + str(steps)

        train_model.save(fname)
        # save random state 
        pickle_fname = fname + ".pickle"
        rand_state_objects = (random.getstate(), np.random.get_state())
        rand_state_file = open(pickle_fname, "wb")
        dump(rand_state_objects, rand_state_file)
        rand_state_file.close()

        print("saving" + fname)

        env = env_constructor(params=flow_params, version=0)()
        # The algorithms require a vectorized environment to run
        eval_env = DummyVecEnv([lambda: env])

        # evaluate the model and print out average delay, speed
        evaluate_model(train_model, eval_env, flow_params['env'].horizon, steps)



# multiprocess worker function
def mp_run(input_arr):
    '''
    Logic for running multiple evaluation jobs at once
    '''
    py_seed, np_seed, tf_seed, flow_params, model_file = input_arr
      # create environment
    env = env_constructor(params=flow_params, version=0)()
    eval_env = DummyVecEnv([lambda: env])

     # load model from file

    eval_model = PPO2.load(model_file, env=eval_env, n_steps=ROLLOUT_SIZE)

    print("python random seed is ", py_seed)
    print("np random seed is ", np_seed)
    print("tf random seed is ", tf_seed)
    # set python random, np random, and tensorflow seeds
    random.seed(py_seed)
    np.random.seed(np_seed)
    tf.set_random_seed(tf_seed)
    # evaluate the model and print out average waiting times and average speed
    arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow = evaluate_model(eval_model, eval_env, flow_params['env'].horizon)
    return [arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow]


def run(flow_params, starting_step, model_file, num_runs, rand_seed_val):
    '''
    Run for a given model
    '''
    print("starting evaluation of the model for ", num_runs, " runs")

    if num_runs == 1:
        # setup env 
        env = env_constructor(params=flow_params, version=0)()
        eval_env = DummyVecEnv([lambda: env])
        print(env.observation_space)

        # load the model for evaluation 
        eval_model = PPO2.load(model_file, env=eval_env, n_steps=ROLLOUT_SIZE)

        env.get_state()

        # set a seed based on system time
        if not rand_seed_val:
            random.seed(rand_seed_val)
        else:
            random.seed(datetime.now())

        py_seed = random.randrange(10000)
        np_seed = random.randrange(10000)
        tf_seed = random.randrange(10000)
        print("python random seed is ", py_seed)
        print("np random seed is ", np_seed)
        print("tf random seed is ", tf_seed)
        # set python random, np random, and tensorflow seeds
        # random.seed(277)
        # np.random.seed(680)
        # tf.set_random_seed(4164)


        evaluate_model(eval_model, eval_env, flow_params['env'].horizon, starting_step)
    
    else: 
        arrived_waiting_time_arr = [] 
        remaining_waiting_time_arr = [] 
        all_waiting_time_arr = [] 
        average_speed_arr = []
        max_queue_size_arr = []
        remaining_queue_size_arr = []
        remaining_num_vehs_arr = [] 
        inflow_arr = []
        outflow_arr = []

        # set a seed based on system time
        random.seed(datetime.now())

        mp_input_arr = []
        for i in range(num_runs): 
            mp_input = [random.randrange(10000), random.randrange(10000), random.randrange(10000), flow_params, model_file]
            mp_input_arr.append(mp_input)

        p = multiprocessing.Pool()
        mp_output_arr = p.map(mp_run, mp_input_arr)
        print("mp output array is ", mp_output_arr)

        for arr in mp_output_arr: 
            arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow = arr
            arrived_waiting_time_arr.append(arrived_waiting_time)
            remaining_waiting_time_arr.append(remaining_waiting_time)
            all_waiting_time_arr.append(all_waiting_time)
            average_speed_arr.append(average_speed)
            max_queue_size_arr.append(max_queue_size)
            remaining_queue_size_arr.append(remaining_queue_size)
            remaining_num_vehs_arr.append(remaining_num_vehs)
            inflow_arr.append(inflow)
            outflow_arr.append(outflow)
            
        # print stats
        print(tabulate([["5th percentile", np.percentile(arrived_waiting_time_arr, 5), np.percentile(remaining_waiting_time_arr, 5), np.percentile(all_waiting_time_arr, 5), np.percentile(average_speed_arr, 5), np.percentile(max_queue_size_arr, 5), np.percentile(remaining_queue_size_arr, 5), np.percentile(remaining_num_vehs_arr, 5), np.percentile(inflow_arr, 5), np.percentile(outflow_arr, 5)],
            ["10th percentile", np.percentile(arrived_waiting_time_arr, 10), np.percentile(remaining_waiting_time_arr, 10), np.percentile(all_waiting_time_arr, 10), np.percentile(average_speed_arr, 10), np.percentile(max_queue_size_arr, 10), np.percentile(remaining_queue_size_arr, 10), np.percentile(remaining_num_vehs_arr, 10), np.percentile(inflow_arr, 10), np.percentile(outflow_arr, 10)],
            ["30th percentile", np.percentile(arrived_waiting_time_arr, 30), np.percentile(remaining_waiting_time_arr, 30), np.percentile(all_waiting_time_arr, 30), np.percentile(average_speed_arr, 30), np.percentile(max_queue_size_arr, 30), np.percentile(remaining_queue_size_arr, 30), np.percentile(remaining_num_vehs_arr, 30), np.percentile(inflow_arr, 30), np.percentile(outflow_arr, 30)],
            ["50th percentile", np.percentile(arrived_waiting_time_arr, 50), np.percentile(remaining_waiting_time_arr, 50), np.percentile(all_waiting_time_arr, 50), np.percentile(average_speed_arr, 50), np.percentile(max_queue_size_arr, 50), np.percentile(remaining_queue_size_arr, 50), np.percentile(remaining_num_vehs_arr, 50), np.percentile(inflow_arr, 50), np.percentile(outflow_arr, 50)], 
            ["70th percentile", np.percentile(arrived_waiting_time_arr, 70), np.percentile(remaining_waiting_time_arr, 70), np.percentile(all_waiting_time_arr, 70), np.percentile(average_speed_arr, 70), np.percentile(max_queue_size_arr, 70), np.percentile(remaining_queue_size_arr, 70), np.percentile(remaining_num_vehs_arr, 70), np.percentile(inflow_arr, 70), np.percentile(outflow_arr, 70)], 
            ["90th percentile", np.percentile(arrived_waiting_time_arr, 90), np.percentile(remaining_waiting_time_arr, 90), np.percentile(all_waiting_time_arr, 90), np.percentile(average_speed_arr, 90), np.percentile(max_queue_size_arr, 90), np.percentile(remaining_queue_size_arr, 90), np.percentile(remaining_num_vehs_arr, 90), np.percentile(inflow_arr, 90), np.percentile(outflow_arr, 90)],
            ["95th percentile", np.percentile(arrived_waiting_time_arr, 95), np.percentile(remaining_waiting_time_arr, 95), np.percentile(all_waiting_time_arr, 95), np.percentile(average_speed_arr, 95), np.percentile(max_queue_size_arr, 95), np.percentile(remaining_queue_size_arr, 95), np.percentile(remaining_num_vehs_arr, 95), np.percentile(inflow_arr, 95), np.percentile(outflow_arr, 95)], 
            ["maximum", np.amax(arrived_waiting_time_arr), np.amax(remaining_waiting_time_arr), np.amax(all_waiting_time_arr), np.amax(average_speed_arr), np.amax(max_queue_size_arr), np.amax(remaining_queue_size_arr), np.amax(remaining_num_vehs_arr), np.amax(inflow_arr), np.amax(outflow_arr)], 
            ["minimum", np.amin(arrived_waiting_time_arr), np.amin(remaining_waiting_time_arr), np.amin(all_waiting_time_arr), np.amin(average_speed_arr), np.amin(max_queue_size_arr), np.amin(remaining_queue_size_arr), np.amin(remaining_num_vehs_arr), np.amin(inflow_arr), np.amin(outflow_arr)],
            ["standard deviation", np.std(arrived_waiting_time_arr), np.std(remaining_waiting_time_arr), np.std(all_waiting_time_arr), np.std(average_speed_arr), np.std(max_queue_size_arr), np.std(remaining_queue_size_arr), np.std(remaining_num_vehs_arr), np.std(inflow_arr), np.std(outflow_arr)]], 
            headers=["", "Arrived Waiting Time (s)", "Remaining Waiting Time (s)", "All Waiting Time (s)", "Average Speed (m/s)", "Maximum Queue Size", "Remaining Queue Size", "Number of Remaining Vehicles", "Inflow", "Outflow"],
            tablefmt='orgtbl'))


#Note: ADDED use_random for whether or not we
# of training it. Need this param because eval looks different from training
#Should use a random controller in place of a safe one
def setup_flow(num_vehs_per_hour, scenario, durations, num_observed, route, \
                static=False, render=False, random_controller=False, \
                rows=3, cols=3, look_ahead=0, inflows_only=False):
    #NOTE: "Look ahead, special param used for modifying the feature vector to look ahead 1 light in each dir"
    #NOTE: Inflows only, special param
    # grid parameters
    inner_length = 100
    long_length = 100
    short_length = 100
    n = rows  # rows
    m = cols  # columns
    num_cars_left = 20
    num_cars_right = 20
    num_cars_top = 20
    num_cars_bot = 20
    # tot_cars = (num_cars_left + num_cars_right) * m + (num_cars_top + num_cars_bot) * n

    grid_array = {"short_length": short_length, "inner_length": inner_length,
                  "long_length": long_length, "row_num": n, "col_num": m,
                  "cars_left": num_cars_left, "cars_right": num_cars_right,
                  "cars_top": num_cars_top, "cars_bot": num_cars_bot}


    """
    Traffic light phases
    SUMO traffic lights documentation: https://sumo.dlr.de/docs/Simulation/Traffic_Lights.html#Signal_state_definitions
     
    S: straight lane, L: left-turning lane, R: right-turning lane
    
    * One lane no turning (S): 
    - static phases for safe controllers
    phases = [{"duration": "31", "state": "GGGrrrGGGrrr"},
              {"duration": "6", "state": "yyyrrryyyrrr"},
              {"duration": "31", "state": "rrrGGGrrrGGG"},
              {"duration": "6", "state": "rrryyyrrryyy"}]
    - phases required for safe controllers and RL systems        
    phases1lane = ['GGGrrrGGGrrr','yyyrrryyyrrr','rrrGGGrrrGGG','rrryyyrrryyy']

    * Two lanes with turning (L | S/R)
    - static phases for safe controllers
    durations2lanes_left_turning = [{"duration": "18", "state": "GGrrrrGGrrrr"},
                   {"duration": "3", "state": "yyrrrryyrrrr"},
                   {"duration": "5", "state": "rrGrrrrrGrrr"},
                   {"duration": "3", "state": "rryrrrrryrrr"},
                   {"duration": "18", "state": "rrrGGrrrrGGr"},
                   {"duration": "3", "state": "rrryyrrrryyr"},
                   {"duration": "5", "state": "rrrrrGrrrrrG"},
                   {"duration": "3", "state": "rrrrryrrrrry"}]
    - phases required for safe controllers and RL systems     
    phases2lanes = ["GGrrrrGGrrrr", "yyrrrryyrrrr", "rrGrrrrrGrrr", "rryrrrrryrrr", "rrrGGrrrrGGr", "rrryyrrrryyr", "rrrrrGrrrrrG", "rrrrryrrrrry"]

    * Three lanes with turning (L | S | R)
    - static phases for safe controllers
    durations3lanes = [{"duration": "12", "state": "GGGrrrrrGGGrrrrr"},
                   {"duration": "3", "state": "yyyrrrrryyyrrrrr"},
                   {"duration": "5", "state": "rrrGrrrrrrrGrrrr"},
                   {"duration": "3", "state": "rrryrrrrrrryrrrr"},
                   {"duration": "12", "state": "rrrrGGGrrrrrGGGr"},
                   {"duration": "3", "state": "rrrryyyrrrrryyyr"},
                   {"duration": "5", "state": "rrrrrrrGrrrrrrrG"},
                   {"duration": "3", "state": "rrrrrrryrrrrrrry"}]
    - phases required for safe controllers and RL systems     
    phases3lanes = ["GGGrrrrrGGGrrrrr", "yyyrrrrryyyrrrrr", "rrrGrrrrrrrGrrrr", "rrryrrrrrrryrrrr", "rrrrGGGrrrrrGGGr", "rrrryyyrrrrryyyr", "rrrrrrrGrrrrrrrG", "rrrrrrryrrrrrrry"]
    """
    phases2lanes = ["GGrrrrGGrrrr", "yyrrrryyrrrr", "rrGrrrrrGrrr", "rryrrrrryrrr", "rrrGGrrrrGGr", "rrryyrrrryyr", "rrrrrGrrrrrG", "rrrrryrrrrry"]
    
    nodes = ["center%s" % i for i in range(n * m)]
    #for i in range(n):
    #    for j in range(m):
    #        nodes.append("row_%s_col_%s" % (i, j))
    #print(nodes)
 
    #nodes = ["center0", "center1", "center2", "center3"]
    yellow_time = str(durations["yellow"])
    straight_time = str(durations["straight"])
    left_time = str(durations["left"])

    durations2lanes_left_turning = [{"duration": straight_time, "state": "GGrrrrGGrrrr"},
                   {"duration": yellow_time, "state": "yyrrrryyrrrr"},
                   {"duration": left_time, "state": "rrGrrrrrGrrr"},
                   {"duration": yellow_time, "state": "rryrrrrryrrr"},
                   {"duration": straight_time, "state": "rrrGGrrrrGGr"},
                   {"duration": yellow_time, "state": "rrryyrrrryyr"},
                   {"duration": left_time, "state": "rrrrrGrrrrrG"},
                   {"duration": yellow_time, "state": "rrrrryrrrrry"}]
    # traffic light logic
    tl_logic = TrafficLightParams(baseline=False)
    # initialize nodes (intersections)

    center_node_num = (n * m) // 2
    
    if static:
        for node_id in nodes:
            tl_logic.add(node_id, tls_type="static", programID="1", offset=None, phases=durations2lanes_left_turning)
    else:
        for node_id in nodes:
            if node_id != 'center%s' % (center_node_num): #middle node TODO: Revert back
                tl_logic.add(node_id, tls_type="static", programID="1", offset=None, phases=durations2lanes_left_turning)

    # vehicle parameters
    vehicles = VehicleParams()
    vehicles.add("human",
                 acceleration_controller=(SimCarFollowingController, {}),
                 lane_change_controller=(SimLaneChangeController, {}),
                 lane_change_params=SumoLaneChangeParams(lane_change_mode='strategic'),
                 car_following_params=SumoCarFollowingParams(
                     speed_mode="right_of_way",
                     impatience="off",
                     decel=7.5,
                    #  accel=4.0,
                     min_gap=2.5))

    initial_config = InitialConfig(spacing='custom')

    # introducing vehicles to the network 
    inflows = InFlows()
    p = .15
    handle_scenarios(scenario, inflows, n, m, num_vehs_per_hour)

    # additional parameters
    ADDITIONAL_NET_PARAMS = {"grid_array": grid_array, "speed_limit": 35,
                             "horizontal_lanes": 2, "vertical_lanes": 2,
                             "traffic_lights": True, "route": route}
    ADDITIONAL_ENV_PARAMS = {"discrete": True, "num_observed": num_observed, 'switch_time': 3,'switch_time_rg' : 3,
                             'tl_type': 'actuated', 'target_velocity': 50, 'phase': phases2lanes,
                             'use_random': random_controller,
                             'look_ahead': look_ahead, 
                             'inflows_only': inflows_only
                             }
    
    # network, environment, and simulation parameters
    net_params = NetParams(inflows=inflows, additional_params=ADDITIONAL_NET_PARAMS)
    env_params = EnvParams(additional_params=ADDITIONAL_ENV_PARAMS)
    sim_params = SumoParams(sim_step=.1, render=render, restart_instance=True)

    # flow parameters
    if static or not random_controller:
        env_class = TrafficLightGridPOEnv if not static else TrafficLightGridSafeController
        #import pdb
        #pdb.set_trace()
        flow_params = dict(
            exp_tag='RL_lights',
            env_name=env_class,
            network=TrafficLightGridNetwork,
            simulator='traci',
            sim=sim_params,
            env=env_params,
            net=net_params,
            veh=vehicles,
            initial=initial_config,
            tls=tl_logic
        )
        if static: #safe controller
            print("yellow light duration: ", yellow_time, "s")
            print("straight green light duration: ", straight_time, "s")
            print("left-turning green light duration: ", left_time, "s")
    else: 
        flow_params = dict(
            exp_tag='RL_lights',
            env_name=TrafficLightGridPOEnv,
            network=TrafficLightGridNetwork,
            simulator='traci',
            sim=sim_params,
            env=env_params,
            net=net_params,
            veh=vehicles,
            initial=initial_config,
            #tls=tl_logic
        )
    

    #NOTE: If not static, we don't pass in safe controller. (In our case we will pass in to all 8 except)
    # setting number of time steps per simulation/iteration
    flow_params['env'].horizon = HORIZON
    return flow_params