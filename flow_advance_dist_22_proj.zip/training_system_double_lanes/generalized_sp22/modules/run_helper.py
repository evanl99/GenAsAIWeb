import os
from pyexpat import model
import numpy as np
from stable_baselines import PPO2
from stable_baselines.common.vec_env import DummyVecEnv
from flow.utils.registry import env_constructor
from flow.core.params import VehicleParams
from flow.controllers import SimCarFollowingController
from flow.core import rewards
from flow.core.params import InFlows
from flow.controllers.lane_change_controllers import SimLaneChangeController
from flow.core.params import SumoParams, EnvParams, InitialConfig, NetParams, \
    InFlows, SumoCarFollowingParams, SumoLaneChangeParams
from flow.core.params import TrafficLightParams
from flow.core.params import NetParams
from modules.experiment import Experiment
from modules.run_grid_env import EvalTrafficLightGridPOEnv
from modules.grid_network import TrafficLightGridNetwork
from utils.utils import get_outside_edges, handle_scenarios
from pickle import dump, load
from tabulate import tabulate
import numpy as np
import random
import re
import tensorflow as tf
from datetime import datetime
from utils.constants import HORIZON, ROLLOUT_SIZE, STEPS_PER_TRAIN, VERBOSE



def run_on_generic_grid(flow_params, starting_step, model_file, num_runs, rand_seed_val, pad):
    '''
    Run for a given model
    '''
    print("starting evaluation of the model for ", num_runs, " runs")

    if num_runs == 1:
        # setup env 
        env = env_constructor(params=flow_params, version=0)()
        eval_env = DummyVecEnv([lambda: env])
        
        #import pdb
        #pdb.set_trace()

        # load the model for evaluation 
        eval_model = PPO2.load(model_file, env=eval_env, n_steps=ROLLOUT_SIZE)

        # set a seed based on system time
        if not rand_seed_val:
            random.seed(rand_seed_val)
        else:
            random.seed(datetime.now())

        py_seed = random.randrange(10000)
        np_seed = random.randrange(10000)
        tf_seed = random.randrange(10000)
        print("python random seed is ", py_seed)
        print("np random seed is ", np_seed)
        print("tf random seed is ", tf_seed)

        env.model = eval_model
        eval_model_run(eval_model, eval_env, flow_params['env'].horizon, starting_step, pad)
    
    else: 
        #MP runs not implemented. TODO: use mp run from helper 
        raise NotImplementedError

def eval_model_run(model, eval_env, horizon, steps=None, pad=False):
    #
    obs = eval_env.reset()
    reward = 0
    # total accumulated waiting time of all arrived vehicles
    total = 0
    # total number of arrived vehicles
    count = 0
    # a dictionary that stores accumulated waiting time for vehicles
    times = {}
    # an array of average velocities for each time step
    speed = []
    # total accumulated waiting time of vehicles in the last time step
    prev_total = 0
    # number of arrived vehicles in the last time step
    prev_count = 0
    # stores vehicles in the queue. 
    queued_vehs = []
    # maximum length of the queue
    max_queue_size = 0
    # number of vehicles which departed 
    inflow = 0

    for i in range(horizon):
        obs, rs, dones, info = eval_env.step([0]) #TODO: Look into smart overriding or modify vec env

        reward += rs
        # all vehicles currently in the network
        cur_vehs = np.array(eval_env.envs[0].k.vehicle.get_ids())
        # loaded vehicles (including ones in the queue)
        loaded_vehs = eval_env.envs[0].k.kernel_api.simulation.getLoadedIDList()
        # vehicles added to the system
        departed_vehs = eval_env.envs[0].k.kernel_api.simulation.getDepartedIDList()
        # update inflow 
        inflow += len(departed_vehs)
        # IDs of vehicles that are currently in the queue
        cur_queued_vehs = list(set(loaded_vehs)- set(departed_vehs))
        # IDs of vehicles that leave the queue (therefore enter the network)
        poped_vehs = list(set(departed_vehs) - set(loaded_vehs))
        # current queue size
        cur_queue_size = len(cur_queued_vehs)
        if cur_queue_size != 0:
            # update maximum queue size  
            if cur_queue_size > max_queue_size:
                max_queue_size = cur_queue_size
            # add currently queued vehicles
            queued_vehs.extend(cur_queued_vehs)
        
        # remove vehicles that left the queue from the queue
        if len(poped_vehs) != 0: 
            queued_vehs = list(set(queued_vehs) - set(poped_vehs))

        # calculate average speed at this timestep 
        vel = np.append(np.array(eval_env.envs[0].k.vehicle.get_speed(cur_vehs)), np.zeros(len(queued_vehs)))
        if not (any(vel < -100) or len(vel) == 0):
            speed.append(np.mean(vel))
        # reset prev total and prev count
        if len(cur_vehs) != 0:
            prev_total = 0
            prev_count = 0
        for veh_id in cur_vehs:
            times[veh_id] = eval_env.envs[0].k.kernel_api.vehicle.getAccumulatedWaitingTime(veh_id)
            # get all remaining cars in the system
            prev_total += times[veh_id]
            prev_count += 1

        # update total accumulated waiting time of all arrived vehicles and update number of arrived vehicles
        try:
            for veh_id in eval_env.envs[0].k.vehicle.get_arrived_ids():
                total += times[veh_id]
                count += 1
        except TypeError:
            pass

    arrived_waiting_time = total / count
    remaining_waiting_time = prev_total / prev_count
    all_waiting_time = (total + prev_total) / (prev_count + count)
    average_speed = np.mean(speed)
    remaining_queue_size = len(queued_vehs)

    if steps == None: 
        print("model evaluation:")
    else: 
        print("after ", steps, " steps") 
    print("average waiting time (s) of arrived vehicles is: ", arrived_waiting_time)
    print("average waiting time (s) of remaining vehicles is: ", remaining_waiting_time)
    print("average waiting time (s) of all vehicles is:", all_waiting_time)
    print("average speed (m/s) of all vehicles is ", average_speed)
    print("maximum queue size is ", max_queue_size)
    print("number of remaining vehicles in the queue ", remaining_queue_size)
    print("number of remaining vehicles in the network ", prev_count)
    print("inflow is ", inflow)
    print("outflow is ", count)
    print("inflow outflow ratio %s", (count/inflow))
    return arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, prev_count, inflow, count


def run_setup_flow(num_vehs_per_hour, scenario, durations, num_observed, route, \
                render=False, random_controller=False, is_eval=False,
                rows=3, cols=3, look_ahead=False, pad=False, model_size=1, model_row_count=1, model_col_count=1): #TODO: pass model size to params
    # grid parameters
    inner_length = 100
    long_length = 100
    short_length = 100
    if pad:
        n = rows + 2
        m = cols + 2
    else:
        n = rows  # rows
        m = cols  # columns
    num_cars_left = 20
    num_cars_right = 20
    num_cars_top = 20
    num_cars_bot = 20
    # tot_cars = (num_cars_left + num_cars_right) * m + (num_cars_top + num_cars_bot) * n

    grid_array = {"short_length": short_length, "inner_length": inner_length,
                  "long_length": long_length, "row_num": n, "col_num": m,
                  "cars_left": num_cars_left, "cars_right": num_cars_right,
                  "cars_top": num_cars_top, "cars_bot": num_cars_bot}

    phases2lanes = ["GGrrrrGGrrrr", "yyrrrryyrrrr", "rrGrrrrrGrrr", "rryrrrrryrrr", "rrrGGrrrrGGr", "rrryyrrrryyr", "rrrrrGrrrrrG", "rrrrryrrrrry"]
    if pad:    
        nodes = ["center%s" % i for i in range(n * m)]
        yellow_time = str(durations["yellow"])
        straight_time = str(durations["straight"])
        left_time = str(durations["left"])
        durations2lanes_left_turning = [{"duration": straight_time, "state": "GGrrrrGGrrrr"},
                    {"duration": yellow_time, "state": "yyrrrryyrrrr"},
                    {"duration": left_time, "state": "rrGrrrrrGrrr"},
                    {"duration": yellow_time, "state": "rryrrrrryrrr"},
                    {"duration": straight_time, "state": "rrrGGrrrrGGr"},
                    {"duration": yellow_time, "state": "rrryyrrrryyr"},
                    {"duration": left_time, "state": "rrrrrGrrrrrG"},
                    {"duration": yellow_time, "state": "rrrrryrrrrry"}]
        # traffic light logic
        tl_logic = TrafficLightParams(baseline=False)
        # initialize nodes (intersections)
        for node_id in nodes:
            id = int(node_id.split('center')[1])
            if id % (m) == 0 or id % (m) == m - 1 or id < m or id > (m) * (n - 1) : # intersection on outer edge
                tl_logic.add(node_id, tls_type="static", programID="1", offset=None, phases=durations2lanes_left_turning)

    # vehicle parameters
    vehicles = VehicleParams()
    vehicles.add("human",
                 acceleration_controller=(SimCarFollowingController, {}),
                 lane_change_controller=(SimLaneChangeController, {}),
                 lane_change_params=SumoLaneChangeParams(lane_change_mode='strategic'),
                 car_following_params=SumoCarFollowingParams(
                     speed_mode="right_of_way",
                     impatience="off",
                     decel=7.5,
                    #  accel=4.0,
                     min_gap=2.5))

    initial_config = InitialConfig(spacing='custom')

    # introducing vehicles to the network 
    inflows = InFlows()
    p = .15
    handle_scenarios(scenario, inflows, n, m, num_vehs_per_hour)

    # additional parameters
    ADDITIONAL_NET_PARAMS = {"grid_array": grid_array, "speed_limit": 35,
                             "horizontal_lanes": 2, "vertical_lanes": 2,
                             "traffic_lights": True, "route": route}
    ADDITIONAL_ENV_PARAMS = {"discrete": True, "num_observed": num_observed, 'switch_time': 3,'switch_time_rg' : 3,
                             'tl_type': 'actuated', 'target_velocity': 50, 'phase': phases2lanes,
                             'use_random': random_controller,
                             'is_eval': is_eval,
                             'pad': pad,
                             'look_ahead': look_ahead,
                             'model_size': model_size,
                             'model_row_count': model_row_count,
                             'model_col_count': model_col_count}
    
    # network, environment, and simulation parameters
    net_params = NetParams(inflows=inflows, additional_params=ADDITIONAL_NET_PARAMS)
    env_params = EnvParams(additional_params=ADDITIONAL_ENV_PARAMS)
    sim_params = SumoParams(sim_step=.1, render=render, restart_instance=True)

    # flow parameters
    if pad:
        flow_params = dict(
            exp_tag='RL_lights',
            env_name=EvalTrafficLightGridPOEnv,
            network=TrafficLightGridNetwork,
            simulator='traci',
            sim=sim_params,
            env=env_params,
            net=net_params,
            veh=vehicles,
            initial=initial_config,
            tls=tl_logic
        )
    else:
        flow_params = dict(
            exp_tag='RL_lights',
            env_name=EvalTrafficLightGridPOEnv,
            network=TrafficLightGridNetwork,
            simulator='traci',
            sim=sim_params,
            env=env_params,
            net=net_params,
            veh=vehicles,
            initial=initial_config,
            #tls=tl_logic
        )
    #NOTE: If not static, we don't pass in safe controller. (In our case we will pass in to all 8 except)
    # setting number of time steps per simulation/iteration
    flow_params['env'].horizon = HORIZON
    return flow_params