"""Environments for networks with traffic lights.

These environments are used to train traffic lights to regulate traffic flow
through an n x m traffic light grid.
"""

import pdb
from matplotlib.pyplot import phase_spectrum
import numpy as np
import re
import random
from modules.grid_env import TrafficLightGridEnv

from gym.spaces.box import Box
from gym.spaces.discrete import Discrete
from gym.spaces import Tuple

from flow.core import rewards
from modules.base import Env
from collections import defaultdict


ADDITIONAL_PO_ENV_PARAMS = {
    # num of vehicles the agent can observe on each incoming edge
    "num_observed": 2,
    # velocity to use in reward functions
    "target_velocity": 30,
}


class EvalTrafficLightGridPOEnv(TrafficLightGridEnv):
    """Environment used to Evaluate traffic lights.

    Required from env_params:

    * switch_time: minimum switch time for each traffic light (in seconds).
      Earlier RL commands are ignored.
    * num_observed: number of vehicles nearest each intersection that is
      observed in the state space; defaults to 2

    States
        An observation is the number of observed vehicles in each intersection
        closest to the traffic lights, a number uniquely identifying which
        edge the vehicle is on, and the speed of the vehicle.

    Actions
        The action space consist of a list of float variables ranging from 0-1
        specifying whether a traffic light is supposed to switch or not. The
        actions are sent to the traffic light in the grid from left to right
        and then top to bottom.

    Rewards
        The reward is the delay of each vehicle minus a penalty for switching
        traffic lights

    Termination
        A rollout is terminated once the time horizon is reached.

    Additional
        Vehicles are rerouted to the start of their original routes once they
        reach the end of the network in order to ensure a constant number of
        vehicles.

    """

    def __init__(self, env_params, sim_params, network, simulator='traci'):
        super().__init__(env_params, sim_params, network, simulator)

        for p in ADDITIONAL_PO_ENV_PARAMS.keys():
            if p not in env_params.additional_params:
                raise KeyError(
                    'Environment parameter "{}" not supplied'.format(p))

        # number of vehicles nearest each intersection that is observed in the
        # state space; defaults to 2
        self.num_observed = env_params.additional_params.get("num_observed", 2)
        self.observed_ids = []

        #Get dimensions of the enviornment size the model was trained on
        self.model_row_count = env_params.additional_params.get("model_row_count", 1) 
        self.model_col_count = env_params.additional_params.get("model_col_count", 1)
        self.model_size = self.model_row_count * self.model_col_count

        self.last_change_state_vector = np.zeros((self.model_size, 1))
        self.direction_state_vector = np.zeros((self.model_size, 1))
        self.direction_left_state_vector = np.zeros((self.model_size, 1))
        self.currently_yellow_state_vector = np.zeros((self.model_size, 1))
        self.pad = env_params.additional_params.get('pad')
        self.look_ahead = env_params.additional_params.get('look_ahead')

        #only use in cases where pad is true and
        self.safe_controller_last_change = 0
        self.last_change_safe_val = 0

        self.model = None #TODO: replace with better logic
        # used during visualization
    
    @property
    def action_space(self):
        """See class definition."""
        if self.discrete:
            return Discrete(2 ** self.model_size)
        else:
            return Box(
                low=-1,
                high=1,
                shape=(self.model_size,),
                dtype=np.float32)


    @property
    def observation_space(self):
        """State space that is partially observed.

        Velocities, distance to intersections, edge number (for nearby
        vehicles) from each direction, edge information, and traffic light
        state.

        reduce size to 20: 
        4 * num cars 
        2 for each edge 

        1. start training of 

        position independent feature vector 
        """
        
        edge_list = self._get_edges_at_node_range([1], size_func_only=True) if self.rows >= 2 \
            and self.cols >= 2 else self.k.network.get_edge_list()
        

        if self.look_ahead > 0:
            num_lights_observed = self.look_ahead * 4 + 1
            tl_box = Box(
                low=0.,
                high=3,
                shape=(3 * 4 * self.num_observed * (self.model_size * num_lights_observed)+
                    2 * len(edge_list) * (num_lights_observed - 1) + # len(self.k.network.get_edge_list()) is 24
                    3 * (self.model_size * num_lights_observed),),
                dtype=np.float32)
        else:
             tl_box = Box(
                low=0.,
                high=3,
                shape=(3 * 4 * self.num_observed * self.model_size +
                    2 * len(edge_list) + # len(self.k.network.get_edge_list()) is 24
                    3 * self.model_size,),
                dtype=np.float32)
        
        return tl_box
    
    #ADDED FUNC
    def _get_center_node_positions(self, n, m):
        """
        Gets all non corner nodes in an n by m grid
        row and col are zero indexed
        n is number of rows
        m is number of cols
        Ex: in a 3 x 3. return [(1, 1)]
        returns list of tuples
        """
        if m < 3 or n < 3:
            return []
        res = []
        for i in range(1, n - 1):
            for j in range(1, m - 1):
                res.append((i, j))
        return res
    
    #ADDED FUNC
    def _get_node_postions_by_name(self, node_nums, rows, cols):
        res = []
        node_nums.sort()
        for num in node_nums:
            i = num // rows
            j = num % cols
            res.append((i,j))
        return res


    #ADDED FUNC
    def _get_edges_at_node_range(self, node_nums=None, only_inflows=False, size_func_only=False):
        """
        Gets list of all incoming at outgoing edges at node
        FROM grid_network.py
        
        "On an horizontal edge, the id of the top road is "top{i}_{j}" and the
        id of the bottom road is "bot{i}_{j}", where i is the index of the row
        where the edge is and j is the index of the column to the right of it.

        On a vertical edge, the id of the right road is "right{i}_{j}" and the
        id of the left road is "left{i}_{j}", where i is the index of the row
        above the edge and j is the index of the column where the edge is."
        NOTE: I is likely index of row below the edge

        only_inflows: only append edges going in
        nodenames: list of nodes by their node names
        """
        #full_edge_list = self.k.network.get_edge_list()
        node_tuple_list = []
        if node_nums is None:
            node_tuple_list = self._get_center_node_positions(self.rows, self.cols)
        else:
            node_tuple_list = self._get_node_postions_by_name(node_nums, self.rows, self.cols)
        edges = []
        for node_pos in node_tuple_list:
            i, j = node_pos
            if only_inflows:
                edges += [
                    ("bot%s_%s" % (i, j)),
                    ("top%s_%s" % (i, j + 1)),
                    ("left%s_%s" %(i + 1, j)),
                    ("right%s_%s" %(i, j)),
                ]
            else:
                edges += [
                    ("bot%s_%s" % (i, j)),
                    ("bot%s_%s" % (i, j + 1)),
                    ("top%s_%s" % (i, j)),
                    ("top%s_%s" % (i, j + 1)),
                    ("left%s_%s" % (i, j)),
                    ("left%s_%s" %(i + 1, j)),
                    ("right%s_%s" %(i, j)),
                    ("right%s_%s" % (i + 1, j)),
                ]
        edges = list(set(edges)) #Get unique edges only
        
        #check that edge is valid
        edge_dict = {x: True for x in self.k.network.get_edge_list()}
        #TODO: Fix
        '''for edge in edges:
            if edge not in edge_dict:
                raise ValueError'''
        
        #NOTE: VERY HACKY. TODO, fix
        if len(edges) > 32:
            return edges[:32]
        
        if len(edges) < 32 and not size_func_only and self.look_ahead >= 1:
            import pdb
            pdb.set_trace()
            new_zero_edges = [0] * (32 - len(edges))
            return edges + new_zero_edges
        return edges

    def _get_lookahead_state_nodes(self, center_node_name=None):
        if self.look_ahead == 0:
            return [center_node_name]

        if self.look_ahead > self.rows // 2:
            raise ValueError("Can't look ahead outside of grid. Look ahead must be smaller than half row size")
        rows = self.rows
        cols = self.cols
        look_ahead = self.look_ahead

        center_node_num = int(center_node_name.split("center")[1])
        state_nodes = [center_node_name]
        for i in range(look_ahead):
            look_ahead_num = i + 1

            left = "center%s" % (center_node_num - look_ahead_num)
            right = "center%s" % (center_node_num + look_ahead_num)
            top = "center%s" % (center_node_num - cols * look_ahead_num)
            bottom = "center%s" % (center_node_num + cols * look_ahead_num)
            state_nodes.extend((left, right, top, bottom))
        return state_nodes

    def _get_state_node_traffic_info(self, state_node_nums, center_node_name=None):
        '''
        returns three lists for look_ahead * 4 + center node
        If look_ahead == 1, returns 5 nodes
        '''
        state_node_nums.sort()
        center_node_num = int(center_node_name.split("center")[1])
        
        #import pdb
        
        if self.safe_controller_last_change % 370 == 0: #randomly pick between phase 0 or 4
            self.last_change_safe_val = 0
        elif self.safe_controller_last_change % 370 == 260:  #switch to first yellow
            self.last_change_safe_val = 0
        elif self.safe_controller_last_change % 370  == 290: #switch to left turn
            self.last_change_safe_val = 0
        elif self.safe_controller_last_change % 370 == 340: #switch to left turn yellow
            self.last_change_safe_val = 0
                
        #Indicates direction based on state
        state_direction_dict = { 'GGrrrrGGrrrr' : 0, 'yyrrrryyrrrr' : 0, 
                                'rrGrrrrrGrrr' : 0 , 'rrrrryrrrrry': 0, 
                                'rrrGGrrrrGGr': 1, 'rrryyrrrryyr': 1,
                                'rrrrrGrrrrrG' : 1, 'rryrrrrryrrr' : 1 }

        #Assign last change if center_node_num == node, else, assign last_change_safe_val
        last_change_arr, direction_arr, currently_yellow_arr = [], [], []
        for node_num in state_node_nums:
            node_row = node_num // self.rows
            node_col = node_num % self.cols
            
            #Use safe controller for padding
            if node_row in [0, self.rows - 1] or node_col in [0, self.cols - 1]:
                #if center_node_num == node_num: #TODO: Support multiple center nodes
                light_state = self.k.traffic_light.get_state("center%s" % (node_num))
                current_yellow_state = 1 if 'y' in light_state else 0
                direction_state = state_direction_dict[light_state]
                last_change_state = self.last_change_safe_val / 10

                currently_yellow_arr.append(current_yellow_state)
                direction_arr.append(direction_state)
                last_change_arr.append(last_change_state)
            else:
                currently_yellow_arr.append(self.currently_yellow_state_vector[0][0])
                last_change_arr.append(self.last_change_state_vector[0][0])
                direction_arr.append(self.direction_state_vector[0][0])
                

        self.last_change_safe_val += 1
        self.safe_controller_last_change += 1

        return np.asarray(last_change_arr), np.asarray(direction_arr), np.asarray(currently_yellow_arr)


    def get_state(self, nodename_input=['center5']):
        """See parent class.

        Returns self.num_observed number of vehicles closest to each traffic
        light and for each vehicle its velocity, distance to intersection,
        edge_number traffic light state. This is partially observed
        
        NOTE: Node name input is a list of all nodes that comprise feature vec
        """
        speeds = []
        dist_to_intersec = []
        edge_number = []
        max_speed = max(
            self.k.network.speed_limit(edge)
            for edge in self.k.network.get_edge_list())
        grid_array = self.net_params.additional_params["grid_array"]
        max_dist = max(grid_array["short_length"], grid_array["long_length"],
                       grid_array["inner_length"])
        all_observed_ids = []

        CENTER_NODE = nodename_input[0]
        all_nodes_to_look_at= self._get_lookahead_state_nodes(center_node_name=CENTER_NODE)

        for node_name, edges in self.network.node_mapping:            
            #ADDED Logic for feature vec modification center training
            #TODO: More elegant solution here
            #If node is center4, it is the middle of 9 nodes
            if node_name not in all_nodes_to_look_at:
                continue
            for edge in edges:
                observed_ids = \
                    self.get_closest_to_intersection(edge, self.num_observed)
                all_observed_ids += observed_ids

                # check which edges we have so we can always pad in the right
                # positions
                speeds += [
                    self.k.vehicle.get_speed(veh_id) / max_speed
                    for veh_id in observed_ids
                ]
                dist_to_intersec += [
                    (self.k.network.edge_length(
                        self.k.vehicle.get_edge(veh_id)) -
                        self.k.vehicle.get_position(veh_id)) / max_dist
                    for veh_id in observed_ids
                ]
                edge_number += \
                    [self._convert_edge(self.k.vehicle.get_edge(veh_id)) /
                     (self.k.network.network.num_edges - 1)
                     for veh_id in observed_ids]

                if len(observed_ids) < self.num_observed:
                    diff = self.num_observed - len(observed_ids)
                    speeds += [0] * diff
                    dist_to_intersec += [0] * diff
                    edge_number += [0] * diff

        # now add in the density and average velocity on the edges
        
        #ADDED Logic for feature vec modification center training
        #If node is center4, then its edges are ['bot1_1', 'right1_1', 'top1_2', 'left2_1']
        #And we should pay attention to those, otherwise we will ignore
        density = []
        velocity_avg = []
        
        state_node_nums = [int(nodename.split("center")[1]) for nodename in all_nodes_to_look_at]
        edge_list_to_use = self._get_edges_at_node_range(node_nums=state_node_nums) if self.rows >= 2 \
            and self.cols >= 2 else self.k.network.get_edge_list()
        
        for edge in edge_list_to_use: #
            ids = self.k.vehicle.get_ids_by_edge(edge)
            if len(ids) > 0:
                vehicle_length = 5
                density += [vehicle_length * len(ids) /
                            self.k.network.edge_length(edge)]
                velocity_avg += [np.mean(
                    [self.k.vehicle.get_speed(veh_id) for veh_id in
                     ids]) / max_speed]
            else:
                density += [0]
                velocity_avg += [0]
        self.observed_ids = list(set(self.observed_ids + all_observed_ids))
        
        #Logic to get info 1 edge away
        if self.look_ahead == 0:
            last_change_arr = self.last_change_state_vector
            direction_arr = self.direction_state_vector
            currently_yellow_arr = self.currently_yellow_state_vector
        else:
            last_change_arr, direction_arr, currently_yellow_arr = \
                self._get_state_node_traffic_info(state_node_nums, \
                                                 center_node_name=CENTER_NODE) #TODO: Support more than one center node

        info = {
            'speeds': speeds, #216 6 * 4 * 9 * (num observed * num edges at each node * num nodes)  #Need 24
            'dist_to_intersec': dist_to_intersec, #216  #Need 24
            'edge_number': edge_number, #216 #Need 24
            'density': density, #48 len(self.k.network.get_edge_list()) NEED 8
            'velocity_avg': velocity_avg, #48 len(self.k.network.get_edge_list()) NEED 8
            'last_change': last_change_arr, #9, just total num of nodes. Need 1
            'direction': direction_arr, #9, just total num of nodes. Need 1
            'currently_yellow': currently_yellow_arr #9, just total num of nodes. Need 1
        }

        #HACKY: TODO: Replace
        if self.rows == 1 and self.cols == 1:
            speeds = [1] * self.num_observed * 4
            dist_to_intersec = [1] * self.num_observed * 4
            edge_number = [1] * self.num_observed * 4

        
        temp = np.array(
            np.concatenate([
                speeds, dist_to_intersec, edge_number, density, velocity_avg,
                last_change_arr.flatten().tolist(),
                direction_arr.flatten().tolist(),
                currently_yellow_arr.flatten().tolist()
            ]))
        
        #if temp.shape[0] == 427:
        #    import pdb
        #    pdb.set_trace()



        return np.array(
            np.concatenate([
                speeds, dist_to_intersec, edge_number, density, velocity_avg,
                self.last_change_state_vector.flatten().tolist(),
                self.direction_state_vector.flatten().tolist(),
                self.currently_yellow_state_vector.flatten().tolist()
            ]))
    
    
    def compute_reward(self, rl_actions, **kwargs):
        return rewards.average_velocity(self)

    def additional_command(self):
        """See class definition."""
        # specify observed vehicles
        [self.k.vehicle.set_observed(veh_id) for veh_id in self.observed_ids]

    
    def _apply_rl_actions(self, rl_actions, nodename=None):
        """See class definition."""
        # check if the action space is discrete
        if self.discrete:
            # convert single value to list of 0's and 1's
            rl_mask = [int(x) for x in list('{0:0b}'.format(rl_actions))]
            rl_mask = [0] * (self.num_traffic_lights - len(rl_mask)) + rl_mask
        else:
            # convert values less than 0 to zero and above 0 to 1. 0 indicates
            # that should not switch the direction, and 1 indicates that switch
            # should happen
            rl_mask = rl_actions > 0.0
        
        action = rl_mask[0]
        i = int(nodename.split('center')[1])
        self.last_change[i] += self.sim_step
        if self.currently_yellow[i] == 1:  # currently yellow
            # Check if our timer has exceeded the yellow phase, meaning it
            # should switch to red
            if self.last_change[i] >= self.min_switch_time:
                # in next phase, cars go from top to bottom and cars don't turn left
                if self.direction[i] == 0 and self.direction_left[i] == 0:
                    self.k.traffic_light.set_state(
                        node_id='center{}'.format(i),
                        state=self.env_params.additional_params['phase'][0])
                # in next phase, cars go from top to bottom and cars turn left
                elif self.direction[i] == 0 and self.direction_left[i] == 1:
                    self.k.traffic_light.set_state(
                        node_id='center{}'.format(i),
                        state=self.env_params.additional_params['phase'][2])
                # in next phase, cars go from left to right and cars don't turn left
                elif self.direction[i] == 1 and self.direction_left[i] == 0:
                    self.k.traffic_light.set_state(
                        node_id='center{}'.format(i),
                        state=self.env_params.additional_params['phase'][4])
                # in next phase, cars go from left to right and cars turn left
                elif self.direction[i] == 1 and self.direction_left[i] == 1:
                    self.k.traffic_light.set_state(
                        node_id='center{}'.format(i),
                        state=self.env_params.additional_params['phase'][6])

                self.currently_yellow[i] = 0
                self.last_change[i] = 0.0
        else:
            if action and self.last_change[i] >= self.min_switch_time_rg:
                # in next phase, cars go from top to bottom and cars don't turn left
                if self.direction[i] == 0 and self.direction_left[i] == 0:
                    self.k.traffic_light.set_state(
                        node_id='center{}'.format(i),
                        state=self.env_params.additional_params['phase'][1])
                    self.direction_left[i] = 1
                # in next phase, cars go from top to bottom and cars turn left
                elif self.direction[i] == 0 and self.direction_left[i] == 1:
                    self.k.traffic_light.set_state(
                        node_id='center{}'.format(i),
                        state=self.env_params.additional_params['phase'][3])
                    self.direction_left[i] = 0
                    self.direction[i] = not self.direction[i]
                # in next phase, cars go from left to right and cars don't turn left
                elif self.direction[i] == 1 and self.direction_left[i] == 0:
                    self.k.traffic_light.set_state(
                        node_id='center{}'.format(i),
                        state=self.env_params.additional_params['phase'][5])
                    self.direction_left[i] = 1
                # in next phase, cars go from left to right and cars turn left
                elif self.direction[i] == 1 and self.direction_left[i] == 1:
                    self.k.traffic_light.set_state(
                        node_id='center{}'.format(i),
                        state=self.env_params.additional_params['phase'][7])
                    self.direction_left[i] = 0
                    self.direction[i] = not self.direction[i]

                self.last_change[i] = 0.0
                # self.direction[i] = not self.direction[i]
                self.currently_yellow[i] = 1


    def apply_rl_actions(self, rl_actions=None, nodename=None):
        """Specify the actions to be performed by the rl agent(s).

        If no actions are provided at any given step, the rl agents default to
        performing actions specified by SUMO.

        Parameters
        ----------
        rl_actions : array_like
            list of actions provided by the RL algorithm
        """
        # ignore if no actions are issued
        if rl_actions is None:
            return

        rl_clipped = self.clip_actions(rl_actions)
        self._apply_rl_actions(rl_clipped, nodename=nodename)

    def _convolve_model_over_grid(self, model, stride=1):
        '''
        Helper method for applying a "kernel"
        over the entire grid and making predictions as it goes

        ex. Model trained for four traffic lights (2x2 grid):
        convolving over 3x3 grid
        X's represent which lights a prediction is applied to
        at each time step

        step 1    step 2      step 3    step 4
        x,x,o      o,x,x      o,o,o     o,o,o
        x,x o  ->  o,x,x  ->  x,x,o  -> o,x,x
        o,o,o      o,o,o      x,x,o     o,x,x

        '''

        if self.rows < self.model_row_count or self.cols < self.model_col_count:
            raise ValueError("Cannot have a model larger than applied grid size")
        
        if (self.rows - self.model_row_count) % stride != 0:
            raise ValueError("Cannot convolve with \
                                grid rows: %s, \
                                model rows %s,\
                                stride %s" % (self.rows, self.model_row_count, stride))
        
        if (self.cols - self.model_col_count) % stride != 0:
            raise ValueError("Cannot convolve with \
                                grid cols: %s, \
                                model cols %s,\
                                stride %s" % (self.cols, self.model_col_count, stride))


        #TODO: Possibly delete or move logic to
        node_name_list = self.network.node_mapping #important
        for node_name in node_name_list:
            
            states = self.get_state([node_name[0]])
            # collect information of the state of the network based on the
            # environment class used
            self.state = np.asarray(states).T
            # collect observation new state associated with action
            
            next_observation = np.copy(states)

            
            action, _states = model.predict(next_observation)
            
            #TODO: do mask logic here, get array of actions
            #Then pass them into here
            self.apply_rl_actions(action, nodename=node_name[0])
        
        return next_observation

    
    def step(self, model):
        """Advance the environment by one step.

        Does so by updating each traffic light one at a time

        Parameters
        ----------
        rl_actions : array_like
            an list of actions provided by the rl algorithm
        **kwargs['model']: model used for making prediction
        Returns
        -------
        observation : array_like
            agent's observation of the current environment
        reward : float
            amount of reward associated with the previous state/action pair
        done : bool
            indicates whether the episode has ended
        info : dict
            contains other diagnostic information from the previous action
        """
        
        #NOTE SIMS PER STEP IS ONE for train and test
        #START OF SIM STEPS
        model = self.model
        
        self.time_counter += 1
        self.step_counter += 1

        # perform acceleration actions for controlled human-driven vehicles
        if len(self.k.vehicle.get_controlled_ids()) > 0:
            accel = []
            for veh_id in self.k.vehicle.get_controlled_ids():
                action = self.k.vehicle.get_acc_controller(
                    veh_id).get_action(self)
                accel.append(action)
            self.k.vehicle.apply_acceleration(
                self.k.vehicle.get_controlled_ids(), accel)

        # perform lane change actions for controlled human-driven vehicles
        if len(self.k.vehicle.get_controlled_lc_ids()) > 0:
            direction = []
            for veh_id in self.k.vehicle.get_controlled_lc_ids():
                target_lane = self.k.vehicle.get_lane_changing_controller(
                    veh_id).get_action(self)
                direction.append(target_lane)
            self.k.vehicle.apply_lane_change(
                self.k.vehicle.get_controlled_lc_ids(),
                direction=direction)

        # perform (optionally) routing actions for all vehicles in the
        # network, including RL and SUMO-controlled vehicles
        routing_ids = []
        routing_actions = []
        for veh_id in self.k.vehicle.get_ids():
            if self.k.vehicle.get_routing_controller(veh_id) \
                    is not None:
                routing_ids.append(veh_id)
                route_contr = self.k.vehicle.get_routing_controller(
                    veh_id)
                routing_actions.append(route_contr.choose_route(self))

        self.k.vehicle.choose_routes(routing_ids, routing_actions)


        node_name_list = self.network.node_mapping #important

        for node_name in node_name_list:
            #print(node_name[0])
            node_name_row = int(node_name[0].split('center')[1]) // self.rows
            node_name_col = int(node_name[0].split('center')[1])  % self.cols
            if self.look_ahead > 0:
                if node_name_row in [0, self.rows -1 ] or node_name_col in [0, self.cols -1]:
                    continue

            states = self.get_state([node_name[0]])
            
            #VERY HACKY: todo: fix
            #NOTE: This only applys for look ahead models
            #Not applicable to general models
            if states.shape[0] == 427:
                states = np.pad(states, [(0, 12)], mode='constant')

            # collect information of the state of the network based on the
            # environment class used
            self.state = np.asarray(states).T
            # collect observation new state associated with action
            
            next_observation = np.copy(states)

            #TODO: Get prediction and apply action here
            action, _states = model.predict(next_observation)
        
            if not self.pad:
                self.apply_rl_actions(action, nodename=node_name[0])
            else:
                i = int(node_name[0].split('center')[1])
                if i % (self.cols) != 0 and i % (self.cols) != self.cols - 1 and i > self.cols and i < (self.cols) * (self.rows - 1):
                    self.apply_rl_actions(action, nodename=node_name[0])

        
        self.additional_command()

        # advance the simulation in the simulator by one step
        self.k.simulation.simulation_step()

        # store new observations in the vehicles and traffic lights class
        self.k.update(reset=False)

        # update the colors of vehicles
        if self.sim_params.render:
            self.k.vehicle.update_vehicle_colors()

        # crash encodes whether the simulator experienced a collision
        crash = self.k.simulation.check_collision()

        # render a frame
        self.render()
        #END OF "SIM STEPS"

        # test if the environment should terminate due to a collision or the
        # time horizon being met
        done = (self.time_counter >= self.env_params.sims_per_step *
                (self.env_params.warmup_steps + self.env_params.horizon)
                or crash)

        # compute the info for each agent
        infos = {}

        # compute the reward
        if self.env_params.clip_actions:
            #rl_clipped = self.clip_actions(rl_actions)
            reward = self.compute_reward(None, fail=crash)
        else:
            reward = self.compute_reward(None, fail=crash)

        return next_observation, reward, done, infos
