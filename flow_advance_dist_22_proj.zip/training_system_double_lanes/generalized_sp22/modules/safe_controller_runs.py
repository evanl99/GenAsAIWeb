import numpy as np
import random
import tensorflow as tf
from modules.experiment import Experiment
import multiprocessing
from tabulate import tabulate



def run_safe(flow_params, num_runs):
    # set a seed based on system time
    random.seed(3000)#datetime.now()

    if num_runs == 1:
        print("starting safe controller")
        exp = Experiment(flow_params)
        # run the sumo simulation
        _ = exp.run(1, convert_to_csv=False)
    else: 
        arrived_waiting_time_arr = [] 
        remaining_waiting_time_arr = [] 
        all_waiting_time_arr = [] 
        average_speed_arr = []
        max_queue_size_arr = []
        remaining_queue_size_arr = []
        remaining_num_vehs_arr = [] 
        inflow_arr = []
        outflow_arr = []

        mp_input_arr = []
        for i in range(num_runs): 
            mp_input = [random.randrange(10000), random.randrange(10000), random.randrange(10000), flow_params]
            mp_input_arr.append(mp_input)

        p = multiprocessing.Pool()
        mp_output_arr = p.map(mp_run_safe, mp_input_arr)
        # print("mp output array is ", mp_output_arr)

        for arr in mp_output_arr: 
            arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow = arr
            arrived_waiting_time_arr.append(arrived_waiting_time)
            remaining_waiting_time_arr.append(remaining_waiting_time)
            all_waiting_time_arr.append(all_waiting_time)
            average_speed_arr.append(average_speed)
            max_queue_size_arr.append(max_queue_size)
            remaining_queue_size_arr.append(remaining_queue_size)
            remaining_num_vehs_arr.append(remaining_num_vehs)
            inflow_arr.append(inflow)
            outflow_arr.append(outflow)
            
        # print stats
        print(tabulate([["5th percentile", np.percentile(arrived_waiting_time_arr, 5), np.percentile(remaining_waiting_time_arr, 5), np.percentile(all_waiting_time_arr, 5), np.percentile(average_speed_arr, 5), np.percentile(max_queue_size_arr, 5), np.percentile(remaining_queue_size_arr, 5), np.percentile(remaining_num_vehs_arr, 5), np.percentile(inflow_arr, 5), np.percentile(outflow_arr, 5)],
            ["10th percentile", np.percentile(arrived_waiting_time_arr, 10), np.percentile(remaining_waiting_time_arr, 10), np.percentile(all_waiting_time_arr, 10), np.percentile(average_speed_arr, 10), np.percentile(max_queue_size_arr, 10), np.percentile(remaining_queue_size_arr, 10), np.percentile(remaining_num_vehs_arr, 10), np.percentile(inflow_arr, 10), np.percentile(outflow_arr, 10)],
            ["30th percentile", np.percentile(arrived_waiting_time_arr, 30), np.percentile(remaining_waiting_time_arr, 30), np.percentile(all_waiting_time_arr, 30), np.percentile(average_speed_arr, 30), np.percentile(max_queue_size_arr, 30), np.percentile(remaining_queue_size_arr, 30), np.percentile(remaining_num_vehs_arr, 30), np.percentile(inflow_arr, 30), np.percentile(outflow_arr, 30)],
            ["50th percentile", np.percentile(arrived_waiting_time_arr, 50), np.percentile(remaining_waiting_time_arr, 50), np.percentile(all_waiting_time_arr, 50), np.percentile(average_speed_arr, 50), np.percentile(max_queue_size_arr, 50), np.percentile(remaining_queue_size_arr, 50), np.percentile(remaining_num_vehs_arr, 50), np.percentile(inflow_arr, 50), np.percentile(outflow_arr, 50)], 
            ["70th percentile", np.percentile(arrived_waiting_time_arr, 70), np.percentile(remaining_waiting_time_arr, 70), np.percentile(all_waiting_time_arr, 70), np.percentile(average_speed_arr, 70), np.percentile(max_queue_size_arr, 70), np.percentile(remaining_queue_size_arr, 70), np.percentile(remaining_num_vehs_arr, 70), np.percentile(inflow_arr, 70), np.percentile(outflow_arr, 70)], 
            ["90th percentile", np.percentile(arrived_waiting_time_arr, 90), np.percentile(remaining_waiting_time_arr, 90), np.percentile(all_waiting_time_arr, 90), np.percentile(average_speed_arr, 90), np.percentile(max_queue_size_arr, 90), np.percentile(remaining_queue_size_arr, 90), np.percentile(remaining_num_vehs_arr, 90), np.percentile(inflow_arr, 90), np.percentile(outflow_arr, 90)],
            ["95th percentile", np.percentile(arrived_waiting_time_arr, 95), np.percentile(remaining_waiting_time_arr, 95), np.percentile(all_waiting_time_arr, 95), np.percentile(average_speed_arr, 95), np.percentile(max_queue_size_arr, 95), np.percentile(remaining_queue_size_arr, 95), np.percentile(remaining_num_vehs_arr, 95), np.percentile(inflow_arr, 95), np.percentile(outflow_arr, 95)], 
            ["maximum", np.amax(arrived_waiting_time_arr), np.amax(remaining_waiting_time_arr), np.amax(all_waiting_time_arr), np.amax(average_speed_arr), np.amax(max_queue_size_arr), np.amax(remaining_queue_size_arr), np.amax(remaining_num_vehs_arr), np.amax(inflow_arr), np.amax(outflow_arr)], 
            ["minimum", np.amin(arrived_waiting_time_arr), np.amin(remaining_waiting_time_arr), np.amin(all_waiting_time_arr), np.amin(average_speed_arr), np.amin(max_queue_size_arr), np.amin(remaining_queue_size_arr), np.amin(remaining_num_vehs_arr), np.amin(inflow_arr), np.amin(outflow_arr)],
            ["standard deviation", np.std(arrived_waiting_time_arr), np.std(remaining_waiting_time_arr), np.std(all_waiting_time_arr), np.std(average_speed_arr), np.std(max_queue_size_arr), np.std(remaining_queue_size_arr), np.std(remaining_num_vehs_arr), np.std(inflow_arr), np.std(outflow_arr)]], 
            headers=["", "Arrived Waiting Time (s)", "Remaining Waiting Time (s)", "All Waiting Time (s)", "Average Speed (m/s)", "Maximum Queue Size", "Remaining Queue Size", "Number of Remaining Vehicles", "Inflow", "Outflow"],
            tablefmt='orgtbl'))
        
        
def mp_run_safe(input_arr): 
    py_seed, np_seed, tf_seed, flow_params = input_arr
    print("python random seed is ", py_seed)
    print("np random seed is ", np_seed)
    print("tf random seed is ", tf_seed)
    # set python random, np random, and tensorflow seeds
    random.seed(py_seed)
    np.random.seed(np_seed)
    tf.set_random_seed(tf_seed)

    exp = Experiment(flow_params)
    # run the sumo simulation
    info_dict = exp.run(1, convert_to_csv=False)
    arrived_waiting_time = info_dict["arrived"]
    remaining_waiting_time = info_dict["remaining"]
    all_waiting_time = info_dict["all"]
    average_speed = info_dict["speed"]
    max_queue_size = info_dict["max_queue_size"]
    remaining_queue_size = info_dict["remaining_queue_size"]
    remaining_num_vehs = info_dict["num_remaining_vehs"]
    inflow = info_dict["inflow"]
    outflow = info_dict["outflow"]
    return [arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow]
