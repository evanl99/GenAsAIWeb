## How to run: 
First make sure that you are in the `generalized_sp22` folder

1. training an AI controller: 
`python rl_lights.py train --num-observed=<number of vehicles per edge the AI observes, default to 6>`

2. running an AI controller in the Training Environment:
NOTE: The same flags must be set as when training that model
`python rl_lights.py run  <path to model file>`

3. Running an AI Controller in the Generalized Environment
`python rl_lights.py run_general <path to model file>`


4. Running a safe controller: 
`python rl_lights.py safe`

5. Rendering a simulation
To show a simulation with either the `run` or `run_general` option,
you would need to add `--render=true` to the run command.
So your command would look something like
`python rl_lights.py run_general rl_model47050000.zip --render=true`


#### optional flags: 
##### The following flags were added for spring 2022 version of the project
--model_path
 path from train_systems_double_lanes to where you would want model files saved to
--use-random 
 define if we should replace safe controllers with random ones
--rand-seed-val
 Random seed for model training. Default to 10,000
--rows
 Number of rows in the environment. Default to 3
--cols 
 Number of cols in the environment. Default to 3
--pad-edges
 If true, add a layer of safe-controlled intersections to the outside of the environment. Default to False
--look-ahead 
 How many lights to look ahead for training. Default to 0
--inflows-only 
 Tells only on inflow edges to light. Default to False




##### The below flags were added by previous contributors to this project
--num-observed 
number of vehicles observed by the AI model on each edge. default value is 6. The AI controller observes <num-observed> / 2  vehicles per lane. 
--straight
safe controller straight light duration in seconds. default value is 26. 
--left 
safe controller left-turning light duration in seconds. default value is 5.•
--yellow 
safe controller yellow light duration in seconds. default value is 3.
--eval
evaluate the model <eval> times with different random seeds. 
--render 
whether to render the simulation. default value is false.
--rate
set traffic inflow rate to <rate> number of vehicles per hour on each outside edge. default value is 500.
--scenario
specify an inflow scenario
default scenario: each outside edge has an inflow of 500 vehicles per hour
scenario 1: edge "top1_2" has an inflow of 752 vehicles per hour, other edges have 464 vehicles per hour
scenario 2: edge "top1_2" has an inflow of 150 vehicles per hour, other edges have 550 vehicles per hour
scenario 3: edge "top1_2" and "left2_1" have an inflow of 650 vehicles per hour, other edges have 450 vehicles per hour
scenario 4: edge "top1_2" has an inflow of 700 vehicles per hour, other edges have 100 vehicles per hour
scenario 5: edge "top1_2" has an inflow of 750 vehicles per hour, other edges have 500 vehicles per hour
scenario 6: edge "top1_2" has an inflow of 500 vehicles per hour, other edges have 100 vehicles per hour
scenario 7: each outside edge has an inflow of 100 vehicles per hour
--route
specify a vehicle route 
default route: First intersection: 1/6 turn left, 1/6 turn right. Second intersection: 1/6 turn left, 1/6 turn right. All the way straight: 1/3 
route 1: First intersection: 1/2 turn left, 1/4 turn right. All the way straight: 1/4•
