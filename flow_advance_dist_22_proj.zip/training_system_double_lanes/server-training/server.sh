# a bash script to run commands on server 
# usage: sh server.sh <server-name> "commands ... "
# OR: sh server.sh (connect to server with lowest load) 

# load config parameters from server.config
. ./config

dest="" 
if [ $# -eq 0 ] # connecting to server with lowest load if <server-name> is not provided
    then
        lowest_load="100"
        lowest_server=""
        for s in ${available_servers[@]}; do
            result=$(ssh -i "$path_to_key" -p $port "${username}@$s.cnds.jhu.edu" cat  /proc/loadavg | awk '{print $1}')
            if [ $lowest_load \> $result ]
            then
                lowest_load=$result
                lowest_server=$s 
            fi 

            if [ 1.0 \> $lowest_load ]
            then
                break
            fi
        done
        dest="${username}@$lowest_server.cnds.jhu.edu"
        echo "Connecting to $lowest_server with load $lowest_load"
        ssh -i "$path_to_key" -p $port $dest -t "cd flow/training_system_double_lanes/server-training/; bash --login"
    else
        dest="${username}@$1.cnds.jhu.edu"
        echo "Connecting to $dest"
        if [ $# -eq 1 ]
        then
            ssh -i "$path_to_key" -p $port $dest -t "cd flow/training_system_double_lanes/server-training/; bash --login"
        else
            ssh -i "$path_to_key" -p $port $dest -t ". ~/.bashrc; cd flow/training_system_double_lanes/server-training/; ${@:2}; bash --login"
        fi
fi


