#!/bin/bash

#rows = ${1:unspecified}
#cols = ${2:unspecified}
#file = ${3:-unspecified}
read -p "Enter rows: " rows
read -p "Enter cols: " cols
read -p "Enter file: " file
read -p "Learning Rate: " lr
set_latest() {
    eval "latest=$(ls rl_model*.zip | sort -r --version-sort | head -1)"
}

run_from_scratch="python ~/flow/training_system_double_lanes/simplified-more-features/rl_lights.py train --rows=$rows --cols=$cols --lr=$lr >> out.txt"
run_from_model="python ~/flow/training_system_double_lanes/simplified-more-features/rl_lights.py train $file --rows=$rows --cols=$cols --lr=$lr >> out.txt"
if [ "$file" = "" ]; then
    echo "start training from scratch"
    eval $run_from_scratch
else
    echo "start training with model $file"
    eval $run_from_model
fi

while true
do
    set_latest
    cmd="python ~/flow/training_system_double_lanes/simplified-more-features/rl_lights.py train $latest --rows=$rows --cols=$cols --lr=$lr >> out.txt"
    echo "continue training with model $latest"
    eval $cmd
    wait
done
