#!/bin/bash

# Script that reads in a list of jobs to run (along with the hyperparams) and runs either the train scipt (if the first col is 0)
# or an eval script (eval script TBD) (if first col is 1)
# This script also runs another script to check if enough tmux sessions can be started and then
# Evenly distributes all sessions across 6 different rain servers

#TODO: FIX BUG THAT LETS MORE THAN FOUR JOBS RUNS ON MACHINE IF JOB IS ALREADY RUNNING
ADD_FILE_PATH=$1 #Path to txt file that contains info

jobs_to_add=()
threshold_per_machine=4
half_threshold_per_machine=2

#Read file into Array
while IFS= read -r line
do
  jobs_to_add+=("${line}")
done < "$ADD_FILE_PATH"


#Get current machine
hostname=$(hostname)
IFS='.' read -ra hostname_arr <<< "$hostname" #split hostname
current_machine="${hostname_arr[0]}"
#echo $current_machine

#Check if we have enough free space to run jobs
num_jobs_to_add=${#jobs_to_add[@]}
echo $num_jobs_to_add
#available_machines=("rain10" "rain11" "rain12" "rain13" "rain14" "rain15")
available_machines=("rain13" "rain14" "rain15")
can_run=$(eval "./devtools/shell_scripts/check_available_sessions.sh ${num_jobs_to_add}  ${threshold_per_machine} false")

if [ $can_run == false ]; then
  echo "ERROR: There is not enough space to run: ${num_jobs_to_add} jobs. Please check currently running jobs and delete several"
  exit
fi

second_pass=false
machines_idx=0 #index for machine array
jobs_idx=0 #index for job array
jobs_on_machine=0 #used to run two jobs per machine at a time

#Loop through all available machines twice
while [ $jobs_idx -lt ${#jobs_to_add[@]} ] 
do
  #Kick off tmux job on current machine
  #first split into four pieces (each line is space seperated), first one being a flag ("train" or "eval")
  #to indicate which script to run, args 2,3,4 are the args to pass into the train/eval scripts
  current_job_str=${jobs_to_add[$jobs_idx]}
  current_job_arr=($current_job_str)
  
  #get three arguments
  arg_one=${current_job_arr[1]}
  arg_two=${current_job_arr[2]}
  arg_three=${current_job_arr[3]}

  running_machine=${available_machines[$machines_idx]}
  path=$(pwd)
  
  echo "${path} PATH" 
  #Pick a script to run depending on first flag 
  if [[ ${current_job_arr[0]} == "train" ]]; then
    #Different run commands depending on what machine we are using
    if [[ "$running_machine" != "$current_machine" ]]; then #ssh if this is not the machine we are in
      num_jobs=$(ssh assured_ai@$running_machine 'tmux ls | wc -l') #get number of jobs
      #command="ssh assured_ai@${running_machine} cd ${path} && ./run_train_session.sh ${arg_one} ${arg_two} ${arg_three}"
      command="ssh assured_ai@${running_machine} 'bash -s' < ./run_train_session.sh ${arg_one} ${arg_two} ${arg_three}" 
    else
      num_jobs=$(tmux ls | wc -l) #get number of jobs
      command="./run_train_session.sh ${arg_one} ${arg_two} ${arg_three}"
    fi

    #LOGIC: If this is the first pass, only run job if less than two jobs are running
    #If this is the second run only run jobs if less than four are running
    if [[ $num_jobs -lt $half_threshold_per_machine && $second_pass == false ]]; then
      first_pass_bool=true
    else
      first_pass_bool=false
    fi

    if [[ $num_jobs -lt $threshold_per_machine && $second_pass == true ]]; then
      second_pass_bool=true
    else
      second_pass_bool=false
    fi

    if [[ first_pass_bool || second_pass_bool ]]; then
      eval $command #kick off training
    fi

    #echo "training : ${arg_one} ${arg_two} ${arg_three}"
    echo "Kicked off job for line: ${jobs_idx} on machine: ${available_machines[$machines_idx]}, "
  elif [[ ${current_job_arr[0]} == "eval" ]]; then
    echo "EVAL SCRIPT NOT YET IMPLEMENTED" #TODO: Implement and call here
  else
    #output error message,
    echo "SYNTAX ON LINE $((jobs_idx + 1)) is invalid, first word should be either 'train' or 'eval'"
  fi

  #NOW, update index
  #if one job is already running, set jobs_on_machine to 1
  #else, increment machine index forward
  if [[ $jobs_on_machine == 0 ]]; then
    jobs_on_machine=1
  else
    jobs_on_machine=0
    machines_idx=$((machines_idx + 1))
  fi
  
  #update indexes, set second_pass to true if we reached the end of the machine arr
  if [[ $machines_idx -ge  ${#available_machines[@]} ]]; then
    second_pass=true
    machines_idx=0
  fi
  jobs_idx=$((jobs_idx + 1))
done
