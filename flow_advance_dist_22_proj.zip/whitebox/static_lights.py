"""
A static safe controller for traffic lights using FLOW (https://github.com/flow-project/flow). 

Network:
1 x 1 traffic grid. 
Each edge has one lane. Vehicles cannot turn. 

"""
import numpy as np
import random
# set random seeds
np.random.seed(5051)
random.seed(6169)

from flow.envs.traffic_light_grid import TrafficLightGridEnv 
from flow.controllers.lane_change_controllers import SimLaneChangeController
from flow.controllers.routing_controllers import GridRouter
from stable_baselines.common.vec_env import DummyVecEnv, SubprocVecEnv
from flow.utils.registry import env_constructor
from flow.core import rewards
from flow.core.params import InFlows
from flow.controllers import GridRouter, SimCarFollowingController
from flow.envs import TrafficLightGridPOEnv
from flow.core.experiment import Experiment
from flow.core.params import VehicleParams
from flow.core.params import SumoParams, EnvParams, InitialConfig, NetParams, \
    InFlows, SumoCarFollowingParams, SumoLaneChangeParams
from flow.core.params import TrafficLightParams
from grid_network import TrafficLightGridNetwork
from flow.core.params import NetParams

from helper import gen_edges, get_outside_edges
from config import * 

# traffic light logic
tl_logic = TrafficLightParams(baseline=False)

# initialize nodes (intersections)
for node_id in nodes:
    tl_logic.add(node_id, tls_type="static", programID="1", offset=None, phases=durations)

# vehicle parameters
vehicles = VehicleParams()
vehicles.add("human",
             acceleration_controller=(SimCarFollowingController, {}),
             lane_change_controller=(SimLaneChangeController, {}),
             lane_change_params=SumoLaneChangeParams(lane_change_mode='strategic'),
             car_following_params=SumoCarFollowingParams(
                 speed_mode="right_of_way",
                 impatience="off", 
                 decel=7.5, 
                #  accel=4.0, 
                 min_gap=2.5))

initial_config = InitialConfig(
    spacing='custom')

# add vehicles to the network
inflows = InFlows()
p = .15
for edge in get_outside_edges(n, m):
    if edge[0] == 'l' or edge[0] == 'r':
        inflows.add(veh_type="human",
                    edge=edge,
                    vehs_per_hour=VEHICLE_RATE,
                    # probability=p,
                    # depart_lane="random",
                    depart_lane="best",
                    depart_speed="random",
                    color="white")
    else:
        inflows.add(veh_type="human",
                    edge=edge,
                    vehs_per_hour=VEHICLE_RATE,
                    # probability=p,
                    depart_lane="best",
                    depart_speed="random",
                    color="white")

# network, environment, and simulation parameters
net_params = NetParams(inflows=inflows, additional_params=ADDITIONAL_NET_PARAMS)
env_params = EnvParams(additional_params=ADDITIONAL_ENV_PARAMS)
sim_params = SumoParams(sim_step=0.1, render=RENDER_STATIC, restart_instance=True)

# flow parameters
flow_params = dict(
    exp_tag='static_lights',
    env_name=TrafficLightGridPOEnv,
    network=TrafficLightGridNetwork,
    simulator='traci',
    sim=sim_params,
    env=env_params,
    net=net_params,
    veh=vehicles,
    initial=initial_config,
    tls=tl_logic
)

# number of time steps
flow_params['env'].horizon = HORIZON

exp = Experiment(flow_params)

# run the sumo simulation
_ = exp.run(1, convert_to_csv=False)
