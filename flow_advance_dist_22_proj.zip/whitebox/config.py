# configurable parameters
VEHICLE_RATE = 500 # number of vehicles per hour
HORIZON = 3000 # number of training steps per iteration/simulation
ROLLOUT_SIZE = 3000 # rollout_size should be multiple of 4
STEPS_PER_TRAIN = 50000
VERBOSE = 2

# model file save path
SAVE_PATH = "./"

RENDER_TRAIN = False
RENDER_RUN = True
RENDER_STATIC = True 

# grid parameters
inner_length = 100
long_length = 100
short_length = 100
n = 1  # rows
m = 1  # columns
num_cars_left = 20
num_cars_right = 20
num_cars_top = 20
num_cars_bot = 20
tot_cars = (num_cars_left + num_cars_right) * m \
    + (num_cars_top + num_cars_bot) * n


"""
Traffic light phases
SUMO traffic lights documentation: https://sumo.dlr.de/docs/Simulation/Traffic_Lights.html#Signal_state_definitions
"""
nodes = ["center0"]
phases = ["GrGr", "yryr", "rGrG", "ryry"]
durations = [{"duration": "31", "state": "GrGr"},
             {"duration": "6", "state": "yryr"},
             {"duration": "31", "state": "rGrG"},
             {"duration": "6", "state": "ryry"}]

grid_array = {"short_length": short_length, "inner_length": inner_length,
                  "long_length": long_length, "row_num": n, "col_num": m,
                  "cars_left": num_cars_left, "cars_right": num_cars_right,
                  "cars_top": num_cars_top, "cars_bot": num_cars_bot}

# additional parameters
ADDITIONAL_NET_PARAMS = {"grid_array": grid_array, "speed_limit": 35,
                            "horizontal_lanes": 1, "vertical_lanes": 1,
                            "traffic_lights": True}
ADDITIONAL_ENV_PARAMS = {"discrete": False, "num_observed": 2, 'switch_time': .5,
                            'tl_type': 'controlled', 'target_velocity': 50, 'phase': phases}