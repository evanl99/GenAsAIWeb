"""
A reinforcement learning training script using FLOW (https://github.com/flow-project/flow). 

Model: PPO2
Agent: Single agent
Policy: MlpPolicy
Libraries (used by flow): stable-baselines, tensorflow, SUMO

Network:
2 x 2 traffic grid. 
Each edge has two lanes. Vehicles can turn and routes are random. 

"""

import numpy as np
import random
# set random seeds
np.random.seed(5051)
random.seed(6169)
training_model_seed = 7218

import sys
from grid_env import TrafficLightGridEnv, TrafficLightGridPOEnv
from grid_network import TrafficLightGridNetwork
from stable_baselines.common.vec_env import DummyVecEnv, SubprocVecEnv
from flow.utils.registry import env_constructor
from flow.core import rewards
from flow.core.params import InFlows
from flow.controllers import GridRouter, SimCarFollowingController
from flow.controllers.lane_change_controllers import SimLaneChangeController
from flow.core.experiment import Experiment
from flow.core.params import VehicleParams
from flow.core.params import SumoParams, EnvParams, InitialConfig, NetParams, \
    InFlows, SumoCarFollowingParams, SumoLaneChangeParams
from flow.core.params import TrafficLightParams
from flow.core.params import NetParams
from stable_baselines import PPO2
import warnings
from multiprocessing import Process, freeze_support
from helper import get_outside_edges, gen_edges
from config import * 

warnings.filterwarnings('ignore', category=FutureWarning)

if __name__ == '__main__':
    freeze_support()
    if len(sys.argv) < 2:
        print("need to specify train or run")
        exit(-1)
    if sys.argv[1] not in ["train", "run"]:
        print("need to specify train or run")
        exit(-1)
    train = True
    starting_step = 0
    if sys.argv[1] == "run":
        train = False
        if len(sys.argv) < 3:
            print("need to specify which model to run")
            exit(-1)
        model_file = sys.argv[2]
    if sys.argv[1] == "train":
        train = True
        if len(sys.argv) < 3:
            print("starting from an empty model")
        else:
            model_file = sys.argv[2]
            starting_step = int(model_file.strip("rl_model.zip"))
            print("starting from step", starting_step)

    # vehicle parameters
    vehicles = VehicleParams()
    vehicles.add("human",
                 acceleration_controller=(SimCarFollowingController, {}),
                 lane_change_controller=(SimLaneChangeController, {}),
                 lane_change_params=SumoLaneChangeParams(lane_change_mode='strategic'),
                 car_following_params=SumoCarFollowingParams(
                     speed_mode="right_of_way",
                     impatience="off",
                     decel=7.5,
                    #  accel=4.0,
                     min_gap=2.5))

    initial_config = InitialConfig(
        spacing='custom')

    # introducing vehicles to the network 
    inflows = InFlows()
    p = .15
    for edge in get_outside_edges(n, m):
        if edge[0] == 'l' or edge[0] == 'r':
            inflows.add(veh_type="human",
                        edge=edge,
                        vehs_per_hour=VEHICLE_RATE,
                        # probability=p,
                        depart_lane="best",
                        depart_speed="random",
                        color="white")
        else:
            inflows.add(veh_type="human",
                        edge=edge,
                        vehs_per_hour=VEHICLE_RATE,
                        # probability=p,
                        depart_lane="best",
                        depart_speed="random",
                        color="white")
    
    # network, environment, and simulation parameters
    net_params = NetParams(inflows=inflows, additional_params=ADDITIONAL_NET_PARAMS)
    env_params = EnvParams(additional_params=ADDITIONAL_ENV_PARAMS)
    sim_params = SumoParams(sim_step=.1, render=True, restart_instance=True)

    # flow parameters
    flow_params = dict(
        exp_tag='RL_lights',
        env_name=TrafficLightGridPOEnv,
        network=TrafficLightGridNetwork,
        simulator='traci',
        sim=sim_params,
        env=env_params,
        net=net_params,
        veh=vehicles,
        initial=initial_config,
    )

    flow_params['env'].horizon = HORIZON

    # number of time steps
    if train:
        # whether render simulation when training
        flow_params['sim'].render = RENDER_TRAIN

        constructor = env_constructor(params=flow_params, version=0)()
        env = DummyVecEnv([lambda: constructor])
        
        # setup training model
        train_model = PPO2('MlpPolicy', env, verbose=VERBOSE, n_steps=ROLLOUT_SIZE, seed=training_model_seed)

        steps = 0 # start with a new model

        # load an existing model 
        if starting_step != 0: 
            train_model = PPO2.load(model_file, env=env)
            print("loading: "+model_file)
            steps = starting_step
        while True:
            print("steps per training is ", STEPS_PER_TRAIN)
            train_model.learn(total_timesteps=STEPS_PER_TRAIN)
            steps += STEPS_PER_TRAIN

            # save model after each iteration
            fname = SAVE_PATH + "rl_model" + str(steps)
            train_model.save(fname)
            print("saving" + fname)

            flow_params['sim'].render = False 
            env = env_constructor(params=flow_params, version=0)()
            # The algorithms require a vectorized environment to run
            eval_env = DummyVecEnv([lambda: env])
            
            # evaluate the model 
            obs = eval_env.reset()
            reward = 0
            total = 0
            count = 0
            times = {}
        
            for i in range(flow_params['env'].horizon):
                action, _states = train_model.predict(obs)
                obs, rs, dones, info = eval_env.step(action)
                reward += rs
                
                for veh_id in eval_env.envs[0].k.vehicle.get_ids():
                    times[veh_id] = eval_env.envs[0].k.kernel_api.vehicle.getAccumulatedWaitingTime(veh_id)

                try:
                    for veh_id in eval_env.envs[0].k.vehicle.get_arrived_ids():
                        total += times[veh_id]
                        count += 1
                except TypeError as e:
                    pass
                # print(rewards.avg_delay_specified_vehicles(eval_env.envs[0],eval_env.envs[0].observed_ids))
            if count != 0:
                print("after ", steps, " steps") 
                print("average delay of arrived vehicles is: ", total / count)

    else:
        # render option 
        flow_params['sim'].render = RENDER_RUN
        # setup env 
        env = env_constructor(params=flow_params, version=0)()
        eval_env = DummyVecEnv([lambda: env])
        # load the model for evaluation 
        eval_model = PPO2.load(model_file, env=eval_env, n_steps=ROLLOUT_SIZE)
        # initialize variables for evaluation 
        obs = eval_env.reset()
        reward = 0
        total = 0
        count = 0
        times = {}
        for i in range(flow_params['env'].horizon):
            action, _states = eval_model.predict(obs)
            obs, rs, dones, info = eval_env.step(action)
            reward += rs

            for veh_id in eval_env.envs[0].k.vehicle.get_ids():
                times[veh_id] = eval_env.envs[0].k.kernel_api.vehicle.getAccumulatedWaitingTime(veh_id)                
              
            try:
                for veh_id in eval_env.envs[0].k.vehicle.get_arrived_ids():
                    total += times[veh_id]
                    count += 1
            except TypeError:
                pass
            # print(rewards.avg_delay_specified_vehicles(eval_env.envs[0],eval_env.envs[0].observed_ids))
            
        if count != 0:
            print(total / count)
            print(i, " average delay of arrived vehicles is:", total / count)
