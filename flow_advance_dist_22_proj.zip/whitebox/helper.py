def gen_edges(col_num, row_num):
    """Generate the names of the outer edges in the grid network.
    Parameters
    ----------
    col_num : int
        number of columns in the grid
    row_num : int
        number of rows in the grid
    Returns
    -------
    list of str
        names of all the outer edges
    """
    edges = []

    # build the left and then the right edges
    for i in range(col_num):
        edges += ['left' + str(row_num) + '_' + str(i)]
        edges += ['right' + '0' + '_' + str(i)]

    # build the bottom and then top edges
    for i in range(row_num):
        edges += ['bot' + str(i) + '_' + '0']
        edges += ['top' + str(i) + '_' + str(col_num)]

    return edges


def get_outside_edges(rows, cols):
    edges = []
    for i in range(rows):
        edges.append("bot{}_0".format(i))
        edges.append("top{}_{}".format(i, cols))
    for j in range(cols):
        edges.append("left{}_{}".format(rows, j))
        edges.append("right0_{}".format(j))
    return edges