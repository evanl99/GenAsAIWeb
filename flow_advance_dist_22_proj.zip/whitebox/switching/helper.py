import numpy as np
from stable_baselines import PPO2
from stable_baselines.common.vec_env import DummyVecEnv
from flow.utils.registry import env_constructor
from flow.core.params import VehicleParams
from flow.controllers import SimCarFollowingController
from flow.core import rewards
from flow.core.params import InFlows
from flow.controllers.lane_change_controllers import SimLaneChangeController
from flow.core.params import SumoParams, EnvParams, InitialConfig, NetParams, \
    InFlows, SumoCarFollowingParams, SumoLaneChangeParams
from flow.core.params import TrafficLightParams
from flow.core.params import NetParams
from grid_env import TrafficLightGridPOEnv
from grid_network import TrafficLightGridNetwork
from pickle import dump, load
from tabulate import tabulate
import numpy as np
import random
import tensorflow as tf
from datetime import datetime
import multiprocessing

# configurable parameters
ROLLOUT_SIZE = 3000 # rollout_size should be multiple of 4
VERBOSE = 2

def gen_edges(col_num, row_num):
    """Generate the names of the outer edges in the grid network.
    Parameters
    ----------
    col_num : int
        number of columns in the grid
    row_num : int
        number of rows in the grid
    Returns
    -------
    list of str
        names of all the outer edges
    """
    edges = []

    # build the left and then the right edges
    for i in range(col_num):
        edges += ['left' + str(row_num) + '_' + str(i)]
        edges += ['right' + '0' + '_' + str(i)]

    # build the bottom and then top edges
    for i in range(row_num):
        edges += ['bot' + str(i) + '_' + '0']
        edges += ['top' + str(i) + '_' + str(col_num)]

    return edges


def get_outside_edges(rows, cols):
    edges = []
    for i in range(rows):
        edges.append("bot{}_0".format(i))
        edges.append("top{}_{}".format(i, cols))
    for j in range(cols):
        edges.append("left{}_{}".format(rows, j))
        edges.append("right0_{}".format(j))
    return edges

def evaluate_model(safe, model, eval_env, horizon):
    state = eval_env.reset()
    reward = 0
    # total accumulated waiting time of all arrived vehicles
    total = 0
    # total number of arrived vehicles
    count = 0
    # a dictionary that stores accumulated waiting time for vehicles
    times = {}
    # an array of average velocities for each time step
    speed = []
    # total accumulated waiting time of vehicles in the last time step
    prev_total = 0
    # number of arrived vehicles in the last time step
    prev_count = 0
    # stores vehicles in the queue. 
    queued_vehs = []
    # maximum length of the queue
    max_queue_size = 0
    # number of vehicles which departed 
    inflow = 0

    def rl_actions(*_):
            return None

    for i in range(horizon):
        if safe:
            state, reward, done, _ = eval_env.step(rl_actions(state))
        else: 
            action, _states = model.predict(state)
            state, reward, done, _ = eval_env.step(action)
        # all vehicles currently in the network
        cur_vehs = np.array(eval_env.k.vehicle.get_ids())
        # loaded vehicles (including ones in the queue)
        loaded_vehs = eval_env.k.kernel_api.simulation.getLoadedIDList()
        # vehicles added to the system
        departed_vehs = eval_env.k.kernel_api.simulation.getDepartedIDList()
        # update inflow 
        inflow += len(departed_vehs)
        # IDs of vehicles that are currently in the queue
        cur_queued_vehs = list(set(loaded_vehs)- set(departed_vehs))
        # IDs of vehicles that leave the queue (therefore enter the network)
        poped_vehs = list(set(departed_vehs) - set(loaded_vehs))
        # current queue size
        cur_queue_size = len(cur_queued_vehs)
        if cur_queue_size != 0:
            # update maximum queue size  
            if cur_queue_size > max_queue_size:
                max_queue_size = cur_queue_size
            # add currently queued vehicles
            queued_vehs.extend(cur_queued_vehs)
        
        # remove vehicles that left the queue from the queue
        if len(poped_vehs) != 0: 
            queued_vehs = list(set(queued_vehs) - set(poped_vehs))

        # calculate average speed at this timestep 
        vel = np.append(np.array(eval_env.k.vehicle.get_speed(cur_vehs)), np.zeros(len(queued_vehs)))
        if not (any(vel < -100) or len(vel) == 0):
            speed.append(np.mean(vel))
        # reset prev total and prev count
        if len(cur_vehs) != 0:
            prev_total = 0
            prev_count = 0
        for veh_id in cur_vehs:
            times[veh_id] = eval_env.k.kernel_api.vehicle.getAccumulatedWaitingTime(veh_id)
            # get all remaining cars in the system
            prev_total += times[veh_id]
            prev_count += 1

        # update total accumulated waiting time of all arrived vehicles and update number of arrived vehicles
        try:
            for veh_id in eval_env.k.vehicle.get_arrived_ids():
                total += times[veh_id]
                count += 1
        except TypeError:
            pass

    arrived_waiting_time = total / count
    remaining_waiting_time = prev_total / prev_count
    all_waiting_time = (total + prev_total) / (prev_count + count)
    average_speed = np.mean(speed)
    remaining_queue_size = len(queued_vehs)

    print("after ", horizon, " steps") 
    print("average waiting time (s) of arrived vehicles is: ", arrived_waiting_time)
    print("average waiting time (s) of remaining vehicles is: ", remaining_waiting_time)
    print("average waiting time (s) of all vehicles is:", all_waiting_time)
    print("average speed (m/s) of all vehicles is ", average_speed)
    print("maximum queue size is ", max_queue_size)
    print("number of remaining vehicles in the queue ", remaining_queue_size)
    print("number of remaining vehicles in the network ", prev_count)
    print("inflow is ", inflow)
    print("outflow is ", count)
    return arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, prev_count, inflow, count
    

def setup_flow(num_vehs_per_hour, scenario, durations, num_observed, route, horizon, render=False, inflow_arr=None):

    # grid parameters
    inner_length = 100
    long_length = 100
    short_length = 100
    n = 2  # rows
    m = 2  # columns
    num_cars_left = 20
    num_cars_right = 20
    num_cars_top = 20
    num_cars_bot = 20
    # tot_cars = (num_cars_left + num_cars_right) * m + (num_cars_top + num_cars_bot) * n

    grid_array = {"short_length": short_length, "inner_length": inner_length,
                  "long_length": long_length, "row_num": n, "col_num": m,
                  "cars_left": num_cars_left, "cars_right": num_cars_right,
                  "cars_top": num_cars_top, "cars_bot": num_cars_bot}


    """
    Traffic light phases
    SUMO traffic lights documentation: https://sumo.dlr.de/docs/Simulation/Traffic_Lights.html#Signal_state_definitions
     
    S: straight lane, L: left-turning lane, R: right-turning lane
    
    * One lane no turning (S): 
    - static phases for safe controllers
    phases = [{"duration": "31", "state": "GGGrrrGGGrrr"},
              {"duration": "6", "state": "yyyrrryyyrrr"},
              {"duration": "31", "state": "rrrGGGrrrGGG"},
              {"duration": "6", "state": "rrryyyrrryyy"}]
    - phases required for safe controllers and RL systems        
    phases1lane = ['GGGrrrGGGrrr','yyyrrryyyrrr','rrrGGGrrrGGG','rrryyyrrryyy']

    * Two lanes with turning (L | S/R)
    - static phases for safe controllers
    durations2lanes_left_turning = [{"duration": "18", "state": "GGrrrrGGrrrr"},
                   {"duration": "3", "state": "yyrrrryyrrrr"},
                   {"duration": "5", "state": "rrGrrrrrGrrr"},
                   {"duration": "3", "state": "rryrrrrryrrr"},
                   {"duration": "18", "state": "rrrGGrrrrGGr"},
                   {"duration": "3", "state": "rrryyrrrryyr"},
                   {"duration": "5", "state": "rrrrrGrrrrrG"},
                   {"duration": "3", "state": "rrrrryrrrrry"}]
    - phases required for safe controllers and RL systems     
    phases2lanes = ["GGrrrrGGrrrr", "yyrrrryyrrrr", "rrGrrrrrGrrr", "rryrrrrryrrr", "rrrGGrrrrGGr", "rrryyrrrryyr", "rrrrrGrrrrrG", "rrrrryrrrrry"]

    * Three lanes with turning (L | S | R)
    - static phases for safe controllers
    durations3lanes = [{"duration": "12", "state": "GGGrrrrrGGGrrrrr"},
                   {"duration": "3", "state": "yyyrrrrryyyrrrrr"},
                   {"duration": "5", "state": "rrrGrrrrrrrGrrrr"},
                   {"duration": "3", "state": "rrryrrrrrrryrrrr"},
                   {"duration": "12", "state": "rrrrGGGrrrrrGGGr"},
                   {"duration": "3", "state": "rrrryyyrrrrryyyr"},
                   {"duration": "5", "state": "rrrrrrrGrrrrrrrG"},
                   {"duration": "3", "state": "rrrrrrryrrrrrrry"}]
    - phases required for safe controllers and RL systems     
    phases3lanes = ["GGGrrrrrGGGrrrrr", "yyyrrrrryyyrrrrr", "rrrGrrrrrrrGrrrr", "rrryrrrrrrryrrrr", "rrrrGGGrrrrrGGGr", "rrrryyyrrrrryyyr", "rrrrrrrGrrrrrrrG", "rrrrrrryrrrrrrry"]
    """
    phases2lanes = ["GGrrrrGGrrrr", "yyrrrryyrrrr", "rrGrrrrrGrrr", "rryrrrrryrrr", "rrrGGrrrrGGr", "rrryyrrrryyr", "rrrrrGrrrrrG", "rrrrryrrrrry"]
    nodes = ["center0", "center1", "center2", "center3"]
    yellow_time = str(durations["yellow"])
    straight_time = str(durations["straight"])
    left_time = str(durations["left"])

    durations2lanes_left_turning = [{"duration": straight_time, "state": "GGrrrrGGrrrr"},
                   {"duration": yellow_time, "state": "yyrrrryyrrrr"},
                   {"duration": left_time, "state": "rrGrrrrrGrrr"},
                   {"duration": yellow_time, "state": "rryrrrrryrrr"},
                   {"duration": straight_time, "state": "rrrGGrrrrGGr"},
                   {"duration": yellow_time, "state": "rrryyrrrryyr"},
                   {"duration": left_time, "state": "rrrrrGrrrrrG"},
                   {"duration": yellow_time, "state": "rrrrryrrrrry"}]
    # traffic light logic
    tl_logic = TrafficLightParams(baseline=False)
    # initialize nodes (intersections)
    for node_id in nodes:
        tl_logic.add(node_id, tls_type="static", programID="1", offset=None, phases=durations2lanes_left_turning)
    # vehicle parameters
    vehicles = VehicleParams()
    vehicles.add("human",
                 acceleration_controller=(SimCarFollowingController, {}),
                 lane_change_controller=(SimLaneChangeController, {}),
                 lane_change_params=SumoLaneChangeParams(lane_change_mode='strategic'),
                 car_following_params=SumoCarFollowingParams(
                     speed_mode="right_of_way",
                     impatience="off",
                     decel=7.5,
                    #  accel=4.0,
                     min_gap=2.5))

    initial_config = InitialConfig(spacing='custom')

    # introducing vehicles to the network 
    inflows = InFlows()
    p = .15
    if inflow_arr is None: 
        # 500 vehs per hour on each edge for first 300s
        for edge in get_outside_edges(n, m):
            inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=num_vehs_per_hour,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white",
                            begin=1, 
                            end=300) 

        # a scenario that trips the system for 301-600s 
        if scenario is None: # default scenario is scenario 4
            for edge in get_outside_edges(n, m):
                if edge == "top1_2":
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=700,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)
                else:
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=100,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)  
        elif scenario == 1: 
            for edge in get_outside_edges(n, m):
                if edge == "top1_2":
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=752,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)
                else:
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=464,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)
        elif scenario == 2: 
            for edge in get_outside_edges(n, m):
                if edge == "top1_2":
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=150,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)
                else:
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=550,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)
        elif scenario == 3: 
            for edge in get_outside_edges(n, m):
                if edge == "top1_2" or edge == "left2_1":
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=650,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)
                else:
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=450,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)
        elif scenario == 4: 
            for edge in get_outside_edges(n, m):
                if edge == "top1_2":
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=700,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)
                else:
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=100,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)  
        elif scenario == 5:
            for edge in get_outside_edges(n, m):
                if edge == "top1_2":
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=750,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)
                else:
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=500,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)  
        elif scenario == 6:
            for edge in get_outside_edges(n, m):
                if edge == "top1_2":
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=500,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)
                else:
                    inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=100,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)  
        elif scenario == 7: 
            for edge in get_outside_edges(n, m):
                inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=100,
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white",
                                begin=301, 
                                end=600)

        # 500 vehs per hour on each edge after 601s
        for edge in get_outside_edges(n, m):
            inflows.add(veh_type="human",
                            edge=edge,
                            vehs_per_hour=num_vehs_per_hour,
                            # probability=p,
                            depart_lane="best",
                            depart_speed="random",
                            color="white",
                            begin=601) 
    else: 
        outside_edges = get_outside_edges(n, m)
        for i in range(len(outside_edges)):
            if inflow_arr[i] != 0:
                edge = outside_edges[i]
                inflows.add(veh_type="human",
                                edge=edge,
                                vehs_per_hour=inflow_arr[i],
                                # probability=p,
                                depart_lane="best",
                                depart_speed="random",
                                color="white") 

    # additional parameters
    ADDITIONAL_NET_PARAMS = {"grid_array": grid_array, "speed_limit": 35,
                             "horizontal_lanes": 2, "vertical_lanes": 2,
                             "traffic_lights": True, "route": route}
    ADDITIONAL_ENV_PARAMS = {"discrete": True, "num_observed": num_observed, 'switch_time': 3,'switch_time_rg' : 3,
                             'tl_type': 'actuated', 'target_velocity': 50, 'phase': phases2lanes}
    
    # network, environment, and simulation parameters
    net_params = NetParams(inflows=inflows, additional_params=ADDITIONAL_NET_PARAMS)
    env_params = EnvParams(additional_params=ADDITIONAL_ENV_PARAMS)
    sim_params = SumoParams(sim_step=.1, render=render, restart_instance=True)

    # flow parameters
    flow_params = dict(
        exp_tag='RL_lights',
        env_name=TrafficLightGridPOEnv,
        network=TrafficLightGridNetwork,
        simulator='traci',
        sim=sim_params,
        env=env_params,
        net=net_params,
        veh=vehicles,
        initial=initial_config,
        tls=tl_logic
    )
    print("yellow light duration: ", yellow_time, "s")
    print("straight green light duration: ", straight_time, "s")
    print("left-turning green light duration: ", left_time, "s")

    # setting number of time steps per simulation/iteration
    flow_params['env'].horizon = horizon
    return flow_params