"""System that switches between the AI controller and the safe controller."""
from flow.core.util import emission_to_csv
from flow.utils.registry import make_create_env, env_constructor
from stable_baselines import PPO2
from stable_baselines.common.vec_env import DummyVecEnv
import copy 
import numpy as np
from helper import setup_flow, evaluate_model, get_outside_edges
import warnings
from multiprocessing import Process, freeze_support, Value, Array, Pool
import argparse
import random
import temp

"""
Since processes generated from multiprocessing Pool are daemonic and multiprocessiing 
doesn't allow daemonic processes to have childen processes, I start two processes at the beginning 
and use shared-memory values to communicate between processes. 

JobID 0: 
The main simulation process. 
Switch from AI to Safe controller: switch when the average speed of past 50 seconds is below 4 (m/s)
Switch from Safe to AI controller: after 60 seconds, run a test simulation of the AI controller for 1000 steps. 
If the average speed of the AI controller is above 5 (m/s), switch to the AI controller. 

JobID 1: 
The test simulation process. 
When temp.sim_running becomes True (non-zero), it runs a test simulation and put results in temp.results
"""

# whether the test simulation is running. 
temp.sim_running = Value("i", 0)
# results of the test simulation 
temp.results = Array("d", [0]*9)
# inflow array for test simulation
temp.inflow_arr = Array("d", [0]*8)


def mp_simulate(input_arr):
    job_id, flow_params, model_file, switch_mode, controller = input_arr 
    n = flow_params['net'].additional_params["grid_array"]["row_num"]
    m = flow_params['net'].additional_params["grid_array"]["col_num"]
    outside_edges = get_outside_edges(n, m)

    if job_id == 0: 
        env_lambda = env_constructor(params=flow_params, version=0)()
        vec_env = DummyVecEnv([lambda: env_lambda])
        env = vec_env.envs[0]
        model = PPO2.load(model_file, env=vec_env, n_steps=1)
        # total number of steps for a simulation
        num_steps = env.env_params.horizon
        
        # used for stepping safe controller
        def rl_actions(*_):
            return None

        # reset environment
        state = env.reset()
        
        # an array of average velocities for each time step
        vel = []
        # a dictionary that stores accumulated waiting time for vehicles
        cartimes={}
        # total accumulated waiting time of all arrived vehicles
        total=0
        # total number of arrived vehicles
        count=0
        # total accumulated waiting time of vehicles in the last time step
        prev_total = 0
        # number of arrived vehicles in the last time step
        prev_count = 0
        # stores vehicles in the queue. 
        queued_vehs = []
        # maximum length of the queue
        max_queue_size = 0
        # number of vehicles which departed 
        inflow = 0

        # current controller
        cur_controller = 'ai'
        # flags used to initialize safe and ai controllers
        load_safe = False
        load_ai = False

        # average speed of past <window-size> steps
        window_avg_speed = -1
        window_size = 500
        window = []
        window_count = 0

        # inflow on outside edges for the past <inflow_window-size> steps
        inflow_window = []
        # inflow of current step 
        inflow_cur = [0] * 8
        inflow_window_count = 0
        inflow_window_size = 500


        # array of timesteps at which the system switched to the safe controller
        switch_time_to_safe = []
        # array of timesteps at which the system switched to the AI controller
        switch_time_to_ai = []

        # initialize sim_running to False
        temp.sim_running.value = 0
        # check if the test simulation started 
        sim_started = False

        # display current controller on sumo-gui
        if cur_controller == 'ai':
            env.k.kernel_api.poi.add("cur-controller", 50, 250, (0,255,0))
        elif cur_controller == 'safe':
            env.k.kernel_api.poi.add("cur-controller", 50, 250, (0,0,255))

        for j in range(num_steps):
            if cur_controller == 'safe':
                # switching to safe controller
                if not load_safe: 
                    print("Initializing safe controller.")
                    # update 
                    env.k.kernel_api.poi.setColor("cur-controller", (0,0,255))
                    # reset traffic light program
                    for i in range(4):
                        env.k.kernel_api.trafficlight.setProgram("center" + str(i), "1")
                    load_safe = True
                    load_ai = False
                    # mark switch time
                    switch_time_to_safe.append(j)

                # time since last switch to safe controller 
                time_elapsed = j - switch_time_to_safe[-1]
                if switch_mode == 1: 
                    if time_elapsed > 600 and window_avg_speed > 5:
                        cur_controller = 'ai'
                elif switch_mode == 2: 
                    if sim_started: 
                        if temp.sim_running.value == 0: 
                            print("Test simulation result")
                            test_sim_avg_speed = temp.results[3]
                            print("AI controller average speed: ", test_sim_avg_speed)
                            print("Safe controller average speed: ", window_avg_speed)
                            if test_sim_avg_speed > 5:
                                print("AI controller average speed > 5 (m/s), switching to AI")
                                cur_controller = 'ai'
                            else: 
                                print("AI controller average speed <= 5 (m/s) , not switching")
                            sim_started = False
                    else: 
                        if time_elapsed > 600 and temp.sim_running.value == 0:
                            # start a simulation for the AI controller
                            # get inflow array of past 60 seconds 
                            inflow_arr = [0] * 8 
                            
                            for arr in inflow_window: 
                                for i in range(8): 
                                    inflow_arr[i] += arr[i]
                            coeff = 36000 / inflow_window_size
                            inflow_arr = [i * coeff for i in inflow_arr]
                            # print("inflow array is ", inflow_arr)
                            # pass inflow array to test simulation
                            for i in range(8): 
                                temp.inflow_arr[i] = inflow_arr[i]
                            temp.sim_running.value = 1
                            sim_started = True
                            
                state, reward, done, _ = env.step(rl_actions(state))
            elif cur_controller == 'ai': 
                # switching to AI controlloer
                if not load_ai: 
                    print("Initializing AI controller.")
                    env.k.kernel_api.poi.setColor("cur-controller", (0,255,0))
                    # model.env = vec_env
                    model = PPO2.load(model_file, env=vec_env, n_steps=1)
                    load_ai = True
                    load_safe = False
                    # mark switch time
                    switch_time_to_ai.append(j)
                action, _states = model.predict(state)
                state, reward, done, _ = env.step(action)

            # all vehicles currently in the network
            veh_ids = env.k.vehicle.get_ids()
            # loaded vehicles (including ones in the queue)
            loaded_vehs = env.k.kernel_api.simulation.getLoadedIDList()
            
            # vehicles added to the system
            departed_vehs = env.k.kernel_api.simulation.getDepartedIDList()
            
            for v_id in departed_vehs:
                edge_idx = outside_edges.index(env.k.vehicle.get_edge(v_id))
                inflow_cur[edge_idx] += 1 
            if inflow_window_count < inflow_window_size: 
                inflow_window.append(copy.copy(inflow_cur))
                inflow_cur = [0] * 8
                inflow_window_count += 1
            else: 
                inflow_window.pop(0)
                inflow_window.append(copy.copy(inflow_cur))
                inflow_cur = [0] * 8

            # update inflow 
            inflow += len(departed_vehs)
            # IDs of vehicles that are currently in the queue
            cur_queued_vehs = list(set(loaded_vehs)- set(departed_vehs))
            # IDs of vehicles that leave the queue (therefore enter the network)
            poped_vehs = list(set(departed_vehs) - set(loaded_vehs))
            # current queue size
            cur_queue_size = len(cur_queued_vehs)
            if cur_queue_size != 0:
                # update maximum queue size  
                if cur_queue_size > max_queue_size:
                    max_queue_size = cur_queue_size
                # add currently queued vehicles
                queued_vehs.extend(cur_queued_vehs)
            
            # remove vehicles that left the queue from the queue
            if len(poped_vehs) != 0: 
                queued_vehs = list(set(queued_vehs) - set(poped_vehs))

            # Compute the velocity speeds and cumulative returns.    
            veh_vel = np.append(np.array(env.k.vehicle.get_speed(veh_ids)), np.zeros(len(queued_vehs)))
            if not (any(veh_vel < -100) or len(veh_vel) == 0):
                avg_vel = np.mean(veh_vel)
                vel.append(avg_vel)
                if window_count < window_size:
                    window.append(avg_vel)
                    window_count+=1
                else:
                    window.pop(0)
                    window.append(avg_vel)
                    window_avg_speed = np.mean(window)
                    print("step: ", j, ", average speed of past ", window_size, " steps is ", window_avg_speed)
                    # switch to safe controller
                    if cur_controller == 'ai' and window_avg_speed < 4:
                        cur_controller = 'safe'

            # reset prev total and prev count
            if len(veh_ids) != 0:
                prev_total = 0
                prev_count = 0

            # print(dir(env))
            for veh_id in env.k.vehicle.get_arrived_ids():
                total += cartimes[veh_id]
                count += 1
            for veh_id in veh_ids:
                cartimes[veh_id] = env.k.kernel_api.vehicle.getAccumulatedWaitingTime(veh_id)
                # get all remaining cars in the system
                prev_total += cartimes[veh_id]
                prev_count += 1
                
            if done:
                break

        arrived_waiting_time = total / count
        remaining_waiting_time = prev_total / prev_count
        all_waiting_time = (total + prev_total) / (prev_count + count)
        average_speed = np.mean(vel)
        remaining_queue_size = len(queued_vehs)
        print("average waiting time (s) of arrived vehicles is: ", arrived_waiting_time)
        print("average waiting time (s) of remaining vehicles is: ", remaining_waiting_time)
        print("average waiting time (s) of all vehicles is:", all_waiting_time)
        print("average speed (m/s) of all vehicles is ", average_speed)
        print("maximum queue size is ", max_queue_size)
        print("number of remaining vehicles in the queue ", remaining_queue_size)
        print("number of remaining vehicles in the network ", prev_count)
        print("inflow is ", inflow)
        print("outflow is ", count)
        outflow = env.k.vehicle.get_outflow_rate(int(500))
        env.terminate()

        return [arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, prev_count, inflow, count] 
    elif job_id == 1:
        while True: 
            if temp.sim_running.value is not 0:
                print("starting test simulation: ", controller)
                sim_inflow_arr = [0] * 8
                for i in range(8): 
                    sim_inflow_arr[i] = temp.inflow_arr[i]
                print("inflow array is ", sim_inflow_arr)
                sim_flow_params = setup_flow(500, None, {"yellow": 3, "straight": 26, "left": 5}, 6, None, 1000, render=False, inflow_arr=sim_inflow_arr)
                sim_env_lambda = env_constructor(params=sim_flow_params, version=0)()
                sim_vec_env = DummyVecEnv([lambda: sim_env_lambda])
                sim_env = sim_vec_env.envs[0]
                sim_model = PPO2.load(model_file, env=sim_vec_env, n_steps=1)
                # total number of steps for a simulation
                num_steps = sim_env.env_params.horizon

                try: 
                    if controller == 'ai': 
                        #  arrived_waiting_time, remaining_waiting_time, all_waiting_time, average_speed, max_queue_size, remaining_queue_size, remaining_num_vehs, inflow, outflow
                        output_arr = evaluate_model(False, sim_model, sim_env, num_steps)
                    elif controller == 'safe':
                        output_arr = evaluate_model(True, None, sim_env, num_steps)
                except Exception as e:
                    print("Exception occurred during simulation: ", e) 
                else: 
                    for i in range(9):
                        temp.results[i] = output_arr[i]
                # test simulation completed 
                temp.sim_running.value = 0
        return []


if __name__ == '__main__':  
    warnings.filterwarnings('ignore', category=FutureWarning)
    freeze_support()

    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices =["run", "safe"] ,help="choose from [run, safe]", type=str)
    parser.add_argument("file", nargs="?", help="model file", type=str)
    parser.add_argument("--render", nargs="?", choices=["true", "false"], help="whether to render SUMO gui", type=str, default="false")
    parser.add_argument("--rate", nargs="?", help="number of vehicles per hour", type=int, default=500)
    parser.add_argument("--yellow", nargs="?", help="specify the duration of yellow lights in safe controller", type=float, default=3)
    parser.add_argument("--straight", nargs="?", help="specify the duration of straight red/green lights in safe controller", type=float, default=26)
    parser.add_argument("--left", nargs="?", help="specify the duration of left-turning red/green lights in safe controller", type=float, default=5)
    parser.add_argument("--scenario", nargs="?", help="scenarios that trip the AI system", type=int, default=None)
    parser.add_argument("--route", nargs="?", help="routes that trip the AI system", type=int, default=None)
    parser.add_argument("--num-observed", nargs="?", help="number of vehicles observed on each edge (must be even)", type=int, default=6)
    parser.add_argument("--horizon", nargs="?", help="total number of steps of a simulation", type=int, default=6000)
    parser.add_argument("--switch-mode", nargs="?", help="switch mode", type=int, default=1)
    args = parser.parse_args()


    RENDER = False
    if args.render == "true":
        RENDER = True

    switch_mode = args.switch_mode

    starting_step = 0
    model_file = args.file
    if model_file is not None: 
        starting_step = int(model_file.strip("rl_model.zip"))

    durations = {"yellow": args.yellow, "straight": args.straight, "left": args.left}
    flow_params = setup_flow(args.rate, args.scenario, durations, args.num_observed, args.route, args.horizon, render=RENDER)
    
    p = Pool(2)
    load_input_arr = []
    load_input_arr.append([0, flow_params, model_file, switch_mode, 'ai'])
    load_input_arr.append([1, flow_params, model_file, switch_mode, 'ai'])
    output_arr = p.map(mp_simulate, load_input_arr)
